"""
render_kit.py — низкоуровневые примитивы для рендера растровых дашбордов
в стиле Apple Glassmorphism + Uzum, поверх которых строится картинка,
которая затем вставляется как ОБЫЧНАЯ картинка в Excel (openpyxl не умеет
рисовать blur/прозрачность нативно, поэтому вся "стеклянность" рисуется
здесь через Pillow и уже готовым PNG вклеивается в .xlsx).

Всё в 3x supersampling: рисуем в 3 раза крупнее, потом ужимаем LANCZOS —
так скругления и тени не пилятся.
"""
from __future__ import annotations
from PIL import Image, ImageDraw, ImageFilter, ImageFont
from pathlib import Path
import math

SCALE = 3  # supersampling

# ---- фирменная палитра Uzum -------------------------------------------------
PURPLE = (112, 0, 255)
PURPLE_DARK = (75, 0, 173)
PURPLE_LIGHT = (247, 243, 255)
PURPLE_SOFT = (168, 85, 247)   # #A855F7 — вторая нота фирменного градиента (как в index.html кнопках)
TITAN_WHITE = (225, 225, 255)
WHITE = (255, 255, 255)

# ---- тёмная сцена (фон всей доски — glassmorphism живёт только на тёмном) ---
STAGE_TOP = (26, 6, 56)        # почти чёрный с фиолетовым подтоном — верх доски
STAGE_BOTTOM = (10, 2, 24)     # глубокий индиго-чёрный — низ доски
INK = (237, 233, 250)          # основной текст на тёмной сцене (было тёмным — теперь светлый)
MUTED = (175, 168, 205)        # вторичный текст на тёмной сцене

STATUS_GREEN = (52, 211, 130)
STATUS_RED = (255, 92, 92)
STATUS_YELLOW = (245, 190, 80)
STATUS_GREY = (170, 165, 195)

# ---- пастельные подложки под статус-пилюли (текст = STATUS_*, фон — приглушённый тёмный) -
STATUS_GREEN_BG = (26, 58, 46)
STATUS_RED_BG = (58, 26, 32)
STATUS_YELLOW_BG = (58, 46, 20)
STATUS_GREY_BG = (40, 36, 56)


FONTS_DIR = Path(__file__).parent / "assets" / "fonts"


_INTER_FILES = {
    "regular": "Inter-Regular.otf",
    "semibold": "Inter-SemiBold.otf",
    "bold": "Inter-Bold.otf",
    "extrabold": "Inter-ExtraBold.otf",
}
_FONT_CACHE: dict = {}


def _font(size: int, bold: bool = False, weight: str | None = None) -> ImageFont.FreeTypeFont:
    """Ищем реальный TTF/OTF-шрифт кроссплатформенно. Порядок:
    1) Inter, вложенный прямо в проект (assets/fonts/Inter-*.otf) — тот же шрифт, что
       на сайтах экосистемы (СЛА / Инвент), выглядит одинаково на любой ОС;
    2) прежний набор: системные DejaVu/Calibri/Arial и вложенный DejaVuSans —
       гарантированный фолбэк, без него на Windows Pillow тихо падал в load_default()
       (нечитаемые 6px-буквы).
    weight: regular | semibold | bold | extrabold (если не задан — bold=True -> bold).
    """
    w = weight or ("bold" if bold else "regular")
    key = (size, w)
    cached = _FONT_CACHE.get(key)
    if cached is not None:
        return cached
    candidates = [
        str(FONTS_DIR / _INTER_FILES.get(w, "Inter-Regular.otf")),
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if w != "regular" else
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "C:/Windows/Fonts/calibrib.ttf" if w != "regular" else "C:/Windows/Fonts/calibri.ttf",
        "C:/Windows/Fonts/arialbd.ttf" if w != "regular" else "C:/Windows/Fonts/arial.ttf",
        "/Library/Fonts/Arial Bold.ttf" if w != "regular" else "/Library/Fonts/Arial.ttf",
        str(FONTS_DIR / ("DejaVuSans-Bold.ttf" if w != "regular" else "DejaVuSans.ttf")),
    ]
    for path in candidates:
        try:
            f = ImageFont.truetype(path, size)
            _FONT_CACHE[key] = f
            return f
        except Exception:
            continue
    print(f"[render_kit] ВНИМАНИЕ: не нашёл ни один шрифт из {candidates}, "
          f"текст на дашборде будет нечитаемым!")
    return ImageFont.load_default()


def font(size: int, bold: bool = False, weight: str | None = None) -> ImageFont.FreeTypeFont:
    return _font(int(size * SCALE), bold, weight)


def new_canvas(w: int, h: int, bg=(0, 0, 0, 0)) -> Image.Image:
    """Логический размер (w,h) -> реальный холст в SCALE раз крупнее."""
    return Image.new("RGBA", (w * SCALE, h * SCALE), bg)


def finalize(canvas: Image.Image, w: int, h: int) -> Image.Image:
    return canvas.resize((w, h), Image.LANCZOS)


def s(v):
    return v * SCALE


def vertical_gradient(size, top, bottom) -> Image.Image:
    w, h = size
    grad = Image.new("RGB", (1, h), top)
    top_a = top
    for y in range(h):
        t = y / max(h - 1, 1)
        r = int(top_a[0] + (bottom[0] - top_a[0]) * t)
        g = int(top_a[1] + (bottom[1] - top_a[1]) * t)
        b = int(top_a[2] + (bottom[2] - top_a[2]) * t)
        grad.putpixel((0, y), (r, g, b))
    return grad.resize((w, h))


def diagonal_gradient(size, c1, c2) -> Image.Image:
    w, h = size
    base = Image.new("RGB", (w, h), c1)
    top = Image.new("RGB", (w, h), c2)
    mask = Image.new("L", (w, h))
    md = ImageDraw.Draw(mask)
    diag = w + h
    for i in range(0, diag, 2):
        val = int(255 * (i / diag))
        md.line([(0, i), (i, 0)], fill=val, width=3)
    mask = mask.resize((w, h))
    # проще и быстрее: honest linear gradient по диагонали через numpy-less loop на уменьшенной версии
    small = 64
    small_mask = Image.new("L", (small, small))
    sd = ImageDraw.Draw(small_mask)
    for y in range(small):
        for x in range(small):
            t = (x + y) / (2 * small)
            sd.point((x, y), fill=int(255 * min(max(t, 0), 1)))
    mask = small_mask.resize((w, h), Image.BILINEAR)
    return Image.composite(top, base, mask)


def rounded_mask(size, radius) -> Image.Image:
    w, h = size
    mask = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(mask)
    d.rounded_rectangle([0, 0, w - 1, h - 1], radius=radius, fill=255)
    return mask


def paste_rounded(canvas, img, xy, radius):
    mask = rounded_mask(img.size, radius)
    canvas.paste(img, xy, mask)


def stage_background(w_logical, h_logical) -> Image.Image:
    """Тёмная фирменная сцена всей доски — глубокий фиолетово-чёрный градиент
    сверху вниз (аналог фона body в index.html), поверх которого дальше
    накладываются blob-волны. Без этого тёмного холста стекло-панели не
    читаются вообще — glassmorphism существует только на тёмном/насыщенном
    фоне, на белом листе он превращается в мутное пятно."""
    w, h = w_logical * SCALE, h_logical * SCALE
    grad = vertical_gradient((w, h), STAGE_TOP, STAGE_BOTTOM)
    return grad.convert("RGBA")


def blob_glow(canvas: Image.Image, cx, cy, r, color, alpha=90):
    """Органичное радиальное пятно света — аналог #mesh .b1/.b2/.b3 в
    index.html (blob-волны фона). В отличие от _add_glare это не идеальный
    круг: слегка сплющенный эллипс с сильным блюром даёт то самое "живое"
    свечение, а не циркуль."""
    pad = int(r * 0.3)
    d = Image.new("RGBA", (r * 2 + pad * 2, int(r * 1.8) + pad * 2), (0, 0, 0, 0))
    dd = ImageDraw.Draw(d)
    dd.ellipse([pad, pad, pad + r * 2, pad + int(r * 1.8)], fill=(*color, alpha))
    d = d.filter(ImageFilter.GaussianBlur(r // 3))
    canvas.alpha_composite(d, (cx - r - pad, cy - int(r * 0.9) - pad))


def drop_shadow(canvas: Image.Image, box, radius, blur, color=(20, 0, 60), alpha=90, offset=(0, 10)):
    """Рисует мягкую размытую тень под будущей панелью box=(x,y,w,h) прямо на canvas."""
    x, y, w, h = box
    pad = blur * 3
    shadow = Image.new("RGBA", (w + pad * 2, h + pad * 2), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    sd.rounded_rectangle([pad, pad, pad + w, pad + h], radius=radius, fill=(*color, alpha))
    shadow = shadow.filter(ImageFilter.GaussianBlur(blur))
    canvas.alpha_composite(shadow, (x - pad + offset[0], y - pad + offset[1]))


def glass_panel(canvas: Image.Image, box, radius=None, *, fill=(255, 255, 255, 26),
                 border_top=(255, 255, 255, 90), border_bottom=(0, 0, 0, 130),
                 shadow=True, shadow_color=(0, 0, 0, 0), shadow_alpha=140, shadow_blur=None,
                 sheen=True, tint=None):
    """Рисует «стеклянную» карточку в языке index.html (var(--glass-bg) +
    двухцветный бордер + inset-блики): тень позади → полупрозрачная тёмная
    заливка (стекло читается ТОЛЬКО на тёмной сцене, поэтому fill почти
    прозрачен) → мягкий цветной tint по желанию → один чистый диагональный
    sheen-блик (одна полоса, не радуга) → объёмный бордер: светлый сверху,
    тёмный снизу — именно это даёт ощущение выпуклого стекла, а не плоской
    плашки."""
    x, y, w, h = box
    radius = radius if radius is not None else s(22)

    if shadow:
        drop_shadow(canvas, box, radius, shadow_blur or s(20),
                    color=(0, 0, 0), alpha=shadow_alpha, offset=(0, s(10)))

    panel = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    mask = rounded_mask((w, h), radius)

    solid = Image.new("RGBA", (w, h), fill)
    panel.paste(solid, (0, 0), mask)

    if tint is not None:
        tint_alpha = tint[3] if len(tint) > 3 else 30
        tint_rgba = Image.new("RGBA", (w, h), (tint[0], tint[1], tint[2], tint_alpha))
        panel.alpha_composite(Image.composite(tint_rgba, Image.new("RGBA", (w, h), (0, 0, 0, 0)), mask))

    if sheen:
        # один чистый диагональный блик сверху-слева -> прозрачный низ-справа,
        # ровно как cinematic-glare в index.html, но статичный (без анимации)
        sheen_layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        sd = ImageDraw.Draw(sheen_layer)
        band = int(max(w, h) * 0.9)
        for i in range(0, band, 2):
            a = int(38 * (1 - abs(i - band * 0.35) / (band * 0.5)))
            a = max(a, 0)
            if a <= 0:
                continue
            sd.line([(0, i), (i, 0)], fill=(255, 255, 255, a), width=3)
        sheen_layer = sheen_layer.filter(ImageFilter.GaussianBlur(s(6)))
        panel.alpha_composite(Image.composite(sheen_layer, Image.new("RGBA", (w, h), (0, 0, 0, 0)), mask))

    # объёмный двухцветный бордер: светлый сверху, тёмный снизу — рисуем как
    # ДВЕ полные обводки rounded_rectangle (не эллиптическую дугу по bbox —
    # на вытянутых прямоугольных карточках дуга по bbox превращается в
    # паразитный овал, торчащий внутрь), верхнюю половину маскируем под
    # верх/низ панели раздельно, поэтому угол смены цвета плавный.
    bw = max(int(s(1.6)), 2)
    full_border = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    fbd = ImageDraw.Draw(full_border)
    fbd.rounded_rectangle([bw / 2, bw / 2, w - bw / 2, h - bw / 2], radius=radius, outline=border_top, width=bw)
    top_mask = Image.new("L", (w, h), 0)
    tmd = ImageDraw.Draw(top_mask)
    tmd.polygon([(0, 0), (w, 0), (w, h * 0.5), (0, h * 0.5)], fill=255)
    panel.paste(full_border, (0, 0), Image.composite(top_mask, Image.new("L", (w, h), 0), top_mask))

    full_border2 = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    fbd2 = ImageDraw.Draw(full_border2)
    fbd2.rounded_rectangle([bw / 2, bw / 2, w - bw / 2, h - bw / 2], radius=radius, outline=border_bottom, width=bw)
    bottom_mask = Image.new("L", (w, h), 0)
    bmd = ImageDraw.Draw(bottom_mask)
    bmd.polygon([(0, h * 0.5), (w, h * 0.5), (w, h), (0, h)], fill=255)
    panel.paste(full_border2, (0, 0), Image.composite(bottom_mask, Image.new("L", (w, h), 0), bottom_mask))

    canvas.alpha_composite(panel, (x, y))


def text(canvas, xy, txt, size, color, bold=False, anchor="la", spacing=0, weight=None, alpha=255):
    d = ImageDraw.Draw(canvas)
    f = font(size, bold, weight)
    d.text((xy[0], xy[1]), txt, font=f, fill=(*color, alpha), anchor=anchor)


def text_bbox(txt, size, bold=False, weight=None):
    f = font(size, bold, weight)
    img = Image.new("RGBA", (10, 10))
    d = ImageDraw.Draw(img)
    return d.textbbox((0, 0), txt, font=f)


def text_w(txt, size, bold=False, weight=None, tracking=0.0):
    """Ширина строки в px холста (SCALE-пикселях) с учётом трекинга (в логических px)."""
    f = font(size, bold, weight)
    return f.getlength(txt) + s(tracking) * max(len(txt) - 1, 0)


def tracked_text(canvas, xy, txt, size, color, tracking=1.6, weight="semibold", anchor="lm", alpha=255):
    """Капс-подписи с разрядкой, как «ВНЕСТИ ДАННЫЕ» / «ЭКОСИСТЕМА ПВЗ» на сайте.
    anchor: первая буква l|m|r — по горизонтали, вторая (m|a|s...) — по вертикали."""
    d = ImageDraw.Draw(canvas)
    f = font(size, weight=weight)
    adv = [f.getlength(ch) for ch in txt]
    total = sum(adv) + s(tracking) * max(len(txt) - 1, 0)
    x, y = xy
    h = anchor[0]
    v = anchor[1] if len(anchor) > 1 else "m"
    if h == "m":
        x -= total / 2
    elif h == "r":
        x -= total
    for ch, a in zip(txt, adv):
        d.text((x, y), ch, font=f, fill=(*color, alpha), anchor="l" + v)
        x += a + s(tracking)


# ------------------------------------------------------------------
#  ДУОТОН-ИКОНКИ (нарисованы контурами, не эмодзи — одинаковы везде)
# ------------------------------------------------------------------
def _icon_base(size):
    return Image.new("RGBA", (size, size), (0, 0, 0, 0))


def icon_check(size, color):
    img = _icon_base(size)
    d = ImageDraw.Draw(img)
    w = max(size // 11, 4)
    d.line([(size * 0.22, size * 0.55), (size * 0.42, size * 0.75), (size * 0.80, size * 0.28)],
           fill=(*color, 255), width=w, joint="curve")
    return img


def icon_cross(size, color):
    img = _icon_base(size)
    d = ImageDraw.Draw(img)
    w = max(size // 11, 4)
    m = size * 0.24
    d.line([(m, m), (size - m, size - m)], fill=(*color, 255), width=w)
    d.line([(size - m, m), (m, size - m)], fill=(*color, 255), width=w)
    return img


def icon_warning(size, color):
    img = _icon_base(size)
    d = ImageDraw.Draw(img)
    w = max(size // 12, 3)
    cx, top, bottom = size / 2, size * 0.18, size * 0.82
    d.polygon([(cx, top), (size * 0.88, bottom), (size * 0.12, bottom)], outline=(*color, 255), width=w)
    d.line([(cx, size * 0.4), (cx, size * 0.62)], fill=(*color, 255), width=w)
    r = w * 0.9
    d.ellipse([cx - r, size * 0.68 - r, cx + r, size * 0.68 + r], fill=(*color, 255))
    return img


def icon_box(size, color):
    """Излишек — контур коробки со знаком плюс сверху."""
    img = _icon_base(size)
    d = ImageDraw.Draw(img)
    w = max(size // 12, 3)
    d.rounded_rectangle([size * 0.16, size * 0.32, size * 0.84, size * 0.86], radius=size * 0.06,
                         outline=(*color, 255), width=w)
    d.line([(size * 0.16, size * 0.5), (size * 0.84, size * 0.5)], fill=(*color, 255), width=w)
    d.line([(size * 0.5, size * 0.32), (size * 0.5, size * 0.5)], fill=(*color, 255), width=w)
    return img


def icon_minus(size, color):
    """Недостача — пунктирный пустой квадрат."""
    img = _icon_base(size)
    d = ImageDraw.Draw(img)
    w = max(size // 12, 3)
    d.rounded_rectangle([size * 0.18, size * 0.18, size * 0.82, size * 0.82], radius=size * 0.14,
                         outline=(*color, 255), width=w)
    d.line([(size * 0.32, size * 0.5), (size * 0.68, size * 0.5)], fill=(*color, 255), width=w)
    return img


def icon_target(size, color):
    img = _icon_base(size)
    d = ImageDraw.Draw(img)
    w = max(size // 14, 3)
    cx = cy = size / 2
    for r in (size * 0.4, size * 0.24):
        d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(*color, 255), width=w)
    r = size * 0.08
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(*color, 255))
    return img


def icon_store(size, color):
    img = _icon_base(size)
    d = ImageDraw.Draw(img)
    w = max(size // 13, 3)
    d.rounded_rectangle([size * 0.16, size * 0.42, size * 0.84, size * 0.86], radius=size * 0.05,
                         outline=(*color, 255), width=w)
    d.line([(size * 0.16, size * 0.42), (size * 0.5, size * 0.16), (size * 0.84, size * 0.42)],
           fill=(*color, 255), width=w, joint="curve")
    d.line([(size * 0.5, size * 0.86), (size * 0.5, size * 0.6)], fill=(*color, 255), width=w)
    return img


def icon_person(size, color):
    img = _icon_base(size)
    d = ImageDraw.Draw(img)
    w = max(size // 13, 3)
    cx = size / 2
    r = size * 0.16
    d.ellipse([cx - r, size * 0.16, cx + r, size * 0.16 + 2 * r], outline=(*color, 255), width=w)
    d.arc([size * 0.18, size * 0.52, size * 0.82, size * 1.1], start=200, end=340, fill=(*color, 255), width=w)
    return img


def icon_clock(size, color):
    img = _icon_base(size)
    d = ImageDraw.Draw(img)
    w = max(size // 13, 3)
    cx = cy = size / 2
    r = size * 0.36
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(*color, 255), width=w)
    d.line([(cx, cy), (cx, cy - r * 0.6)], fill=(*color, 255), width=w)
    d.line([(cx, cy), (cx + r * 0.4, cy + r * 0.15)], fill=(*color, 255), width=w)
    return img


def icon_list(size, color):
    """Всего заказов — список/стопка строк."""
    img = _icon_base(size)
    d = ImageDraw.Draw(img)
    w = max(size // 13, 3)
    ys = [size * 0.28, size * 0.5, size * 0.72]
    for y in ys:
        r = size * 0.045
        d.ellipse([size * 0.14 - r, y - r, size * 0.14 + r, y + r], fill=(*color, 255))
        d.line([(size * 0.26, y), (size * 0.86, y)], fill=(*color, 255), width=w)
    return img


def duotone_tile(icon_fn, size, fg_color, bg_color, bg_alpha=38, radius=None, solid=False):
    """Скруглённая плашка-подложка + иконка поверх. Два режима:
    - solid=False (по умолчанию): полупрозрачная тонировка — для мест на
      тёмной сцене, где плашка должна быть лёгкой (профильные чипы);
    - solid=True: настоящий диагональный градиент + inset-тень сверху/снизу,
      как у .icon-btn / кнопок в index.html (box-shadow: inset 0 2px 4px
      rgba(255,255,255,.6), inset 0 -4px 10px rgba(0,0,0,.3)) — для KPI-плиток,
      где иконка должна выглядеть "нажимаемо" объёмной, а не плоским значком."""
    radius = radius or int(size * 0.28)
    tile = _icon_base(size)
    mask = rounded_mask((size, size), radius)

    if solid:
        light = tuple(min(255, int(c * 1.35 + 40)) for c in bg_color)
        grad = diagonal_gradient((size, size), light, bg_color).convert("RGBA")
        tile.paste(grad, (0, 0), mask)
        # inset-блик сверху (светлый) и тень снизу (тёмная) — объём как у CSS box-shadow inset
        inset = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        idr = ImageDraw.Draw(inset)
        idr.ellipse([-size * 0.3, -size * 0.5, size * 1.3, size * 0.7], fill=(255, 255, 255, 90))
        inset = inset.filter(ImageFilter.GaussianBlur(size // 8))
        tile.alpha_composite(Image.composite(inset, Image.new("RGBA", (size, size), (0, 0, 0, 0)), mask))
        shadow_in = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        sdr = ImageDraw.Draw(shadow_in)
        sdr.ellipse([-size * 0.3, size * 0.4, size * 1.3, size * 1.5], fill=(0, 0, 0, 70))
        shadow_in = shadow_in.filter(ImageFilter.GaussianBlur(size // 8))
        tile.alpha_composite(Image.composite(shadow_in, Image.new("RGBA", (size, size), (0, 0, 0, 0)), mask))
        icon = icon_fn(int(size * 0.54), WHITE)
    else:
        bg = Image.new("RGBA", (size, size), (*bg_color, bg_alpha))
        tile.paste(bg, (0, 0), mask)
        icon = icon_fn(int(size * 0.56), fg_color)

    off = (size - icon.width) // 2
    tile.alpha_composite(icon, (off, off))
    return tile


# ------------------------------------------------------------------
#  СТАТУС-ПИЛЮЛИ (бейджи) — для вставки картинкой В ОДНУ ЯЧЕЙКУ вместо
#  заливки PatternFill на весь ряд. Каждая рисуется один раз в статике
#  (см. excel_report/assets/pill_*.png) и переиспользуется как обычная
#  картинка — это дешевле, чем перерисовывать сотни строк на каждый отчёт.
# ------------------------------------------------------------------
def status_pill_img(label: str, fg_color, bg_color, w_logical=118, h_logical=30) -> Image.Image:
    """Скруглённая капсула-бейдж: бледный фон + насыщенный текст, без резких
    светофорных цветов — читается спокойно при долгой смене."""
    w, h = w_logical, h_logical
    canvas = new_canvas(w, h)
    radius = s(h) // 2
    body = Image.new("RGBA", (s(w), s(h)), (0, 0, 0, 0))
    mask = rounded_mask((s(w), s(h)), radius)
    solid = Image.new("RGBA", (s(w), s(h)), (*bg_color, 255))
    body.paste(solid, (0, 0), mask)
    canvas.alpha_composite(body)
    text(canvas, (s(w) // 2, s(h) // 2 + s(1)), label, 11.2, fg_color, bold=True, anchor="mm")
    return finalize(canvas, w, h)


def donut_chart(size_logical: int, pct: float, ring_color, track_color=TITAN_WHITE,
                 thickness_ratio=0.14) -> Image.Image:
    """Кольцевая диаграмма в стиле Apple Watch activity ring: тонкий блёклый
    трек-круг фон + яркая дуга заполнения поверх, с мягко скруглённым концом
    дуги (стартовый колпачок не рисуем — на коротких дугах он визуально
    сливается со вторым в кляксу; конечный колпачок один и его достаточно,
    чтобы дуга читалась как «капсула», а не обрубок). pct в диапазоне 0..100."""
    size = size_logical
    canvas = new_canvas(size, size)
    ss = s(size)
    th = max(int(ss * thickness_ratio), s(5))
    pad = th // 2 + s(2)
    box = [pad, pad, ss - pad, ss - pad]

    track_rgba = track_color if len(track_color) == 4 else (*track_color, 255)
    d = ImageDraw.Draw(canvas)
    d.arc(box, start=0, end=360, fill=track_rgba, width=th)

    pct = max(0.0, min(100.0, pct))
    if pct > 0:
        sweep = 360 * (pct / 100.0)
        end_angle = -90 + sweep
        d.arc(box, start=-90, end=end_angle, fill=(*ring_color, 255), width=th)
        # скруглённый «колпачок» только на конце дуги (не на старте) —
        # так у полосы всегда опрятный капсульный кончик без риска, что два
        # колпачка налезут друг на друга при малых pct.
        r = th / 2
        ring_radius = ss / 2 - pad
        rad = math.radians(end_angle)
        cx = ss / 2 + ring_radius * math.cos(rad)
        cy = ss / 2 + ring_radius * math.sin(rad)
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(*ring_color, 255))

    return finalize(canvas, size, size)

# ==================================================================
#  НЕОНОВЫЙ СТИЛЬ СЛА-САЙТА (Uzum Design System): пилюли, иконки, «глаза»
# ==================================================================
BG_BASE = (3, 0, 8)            # --bg-base #030008
NEON = (157, 77, 255)          # --purple-light #9D4DFF
NEON_SOFT = (199, 166, 255)
TEXT_DIM = (139, 127, 170)     # --text-dim #8B7FAA
TEXT_MUTED = (184, 174, 224)   # --text-muted #B8AEE0
TEXT_HINT = (215, 205, 242)    # --text-hint #D7CDF2

C_GREEN = (52, 199, 123)       # --green #34C77B
C_RED = (255, 59, 48)          # --red-alert #FF3B30
C_AMBER = (255, 176, 32)       # --amber #FFB020
C_PINK = (255, 92, 168)
C_GREY = (160, 150, 195)

# статус (как в db.STATUS_LABELS / "Недостача") -> цвет
STATUS_COLOR = {
    "Верная ячейка": C_GREEN,
    "Неверная ячейка": C_RED,
    "Излишек": C_PINK,
    "Задвоенный": C_AMBER,
    "Недостача": C_GREY,
}


def mix(c1, c2, k):
    """Смешивает два цвета: k=0 -> c1, k=1 -> c2."""
    return tuple(int(c1[i] * (1 - k) + c2[i] * k) for i in range(3))


def lighten(c, k=0.35):
    return mix(c, (255, 255, 255), k)


def neon_pill_img(label: str, color, w_logical=140, h_logical=30) -> Image.Image:
    """Тёмная «стеклянная» капсула статуса с неоновой обводкой и светящейся точкой —
    для вставки в ячейку на тёмной таблице (прозрачный фон PNG)."""
    w, h = w_logical, h_logical
    W_, H_ = s(w), s(h)
    canvas = Image.new("RGBA", (W_, H_), (0, 0, 0, 0))
    inset = s(2.5)
    box = [inset, inset, W_ - inset, H_ - inset]
    radius = (H_ - 2 * inset) // 2

    glow = Image.new("RGBA", (W_, H_), (0, 0, 0, 0))
    ImageDraw.Draw(glow).rounded_rectangle(box, radius=radius, outline=(*color, 150), width=s(2))
    canvas.alpha_composite(glow.filter(ImageFilter.GaussianBlur(s(2.2))))

    body = Image.new("RGBA", (W_, H_), (0, 0, 0, 0))
    bd = ImageDraw.Draw(body)
    bd.rounded_rectangle(box, radius=radius, fill=(*mix((16, 7, 34), color, 0.17), 255),
                         outline=(*color, 235), width=max(int(s(1.3)), 2))
    # верхний блик стекла
    hl = Image.new("RGBA", (W_, H_), (0, 0, 0, 0))
    ImageDraw.Draw(hl).rounded_rectangle([inset + s(3), inset + s(2), W_ - inset - s(3), H_ // 2],
                                         radius=radius, fill=(255, 255, 255, 20))
    body.alpha_composite(hl)
    canvas.alpha_composite(body)

    # светящаяся точка слева
    dot_cx, dot_cy = s(17), H_ // 2
    dg = Image.new("RGBA", (W_, H_), (0, 0, 0, 0))
    ImageDraw.Draw(dg).ellipse([dot_cx - s(5), dot_cy - s(5), dot_cx + s(5), dot_cy + s(5)], fill=(*color, 170))
    canvas.alpha_composite(dg.filter(ImageFilter.GaussianBlur(s(3))))
    ImageDraw.Draw(canvas).ellipse([dot_cx - s(3.2), dot_cy - s(3.2), dot_cx + s(3.2), dot_cy + s(3.2)],
                                   fill=(*lighten(color, 0.25), 255))

    text(canvas, (W_ // 2 + s(7), H_ // 2 + s(0.5)), label, 11, lighten(color, 0.4),
         weight="semibold", anchor="mm")
    return finalize(canvas, w, h)


def status_icon_img(icon_fn, color, size_logical=34) -> Image.Image:
    """Круглая неоновая плашка с иконкой статуса (для легенды на тёмной таблице)."""
    size = size_logical
    S_ = s(size)
    canvas = Image.new("RGBA", (S_, S_), (0, 0, 0, 0))
    glow = Image.new("RGBA", (S_, S_), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse([s(3), s(3), S_ - s(3), S_ - s(3)], outline=(*color, 160), width=s(2))
    canvas.alpha_composite(glow.filter(ImageFilter.GaussianBlur(s(2.2))))
    d = ImageDraw.Draw(canvas)
    d.ellipse([s(3), s(3), S_ - s(3), S_ - s(3)], fill=(*mix((16, 7, 34), color, 0.2), 255),
              outline=(*color, 235), width=max(int(s(1.3)), 2))
    icon = icon_fn(int(S_ * 0.5), lighten(color, 0.3))
    off = (S_ - icon.width) // 2
    canvas.alpha_composite(icon, (off, off))
    return finalize(canvas, size, size)


def radial_disc(draw_canvas: Image.Image, cx, cy, r, inner, outer):
    """Закрашенный круг с радиальным градиентом inner(центр) -> outer(край)."""
    d = ImageDraw.Draw(draw_canvas)
    steps = max(int(r), 8)
    for i in range(steps):
        t = i / (steps - 1)
        rr = r * (1 - t)
        col = mix(outer, inner, t)
        d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], fill=(*col, 255))


def eye(canvas: Image.Image, cx, cy, r, look=(0.4, 0.3)):
    """Глаз-талисман как на СЛА-сайте: белая склера, фиолетовый зрачок с градиентом и бликом.
    cx, cy, r — в пикселях холста; look — куда смотрит (-1..1, -1..1)."""
    # мягкое неоновое свечение за глазом
    blob_glow(canvas, int(cx), int(cy), int(r * 1.7), NEON, 70)
    pad = int(r * 0.3)
    size = int(r * 2 + pad * 2)
    layer = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    lc = size / 2
    # склера: белая, чуть теплее к низу
    sc = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    radial_disc(sc, lc, lc - r * 0.08, r, (255, 255, 255), (222, 212, 245))
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).ellipse([lc - r, lc - r, lc + r, lc + r], fill=255)
    layer.paste(sc, (0, 0), mask)
    # внутренняя тень по краю склеры
    edge = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    ImageDraw.Draw(edge).ellipse([lc - r, lc - r, lc + r, lc + r], outline=(90, 40, 160, 120), width=max(int(r * 0.08), 2))
    layer.alpha_composite(edge.filter(ImageFilter.GaussianBlur(max(int(r * 0.05), 1))))
    # зрачок
    pr = r * 0.52
    px = lc + look[0] * (r - pr) * 0.85
    py = lc + look[1] * (r - pr) * 0.85
    pup = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    radial_disc(pup, px, py, pr, (150, 70, 255), (48, 8, 110))
    ImageDraw.Draw(pup).ellipse([px - pr * 0.5, py - pr * 0.5, px + pr * 0.5, py + pr * 0.5], fill=(14, 2, 34, 255))
    # зрачок кладём alpha_composite (paste с маской стирал бы склеру прозрачными пикселями слоя)
    pup_clip = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    pup_clip.paste(pup, (0, 0), mask)
    layer.alpha_composite(pup_clip)
    # блики
    g = ImageDraw.Draw(layer)
    g.ellipse([px - pr * 0.62, py - pr * 0.7, px - pr * 0.18, py - pr * 0.26], fill=(255, 255, 255, 255))
    g.ellipse([px + pr * 0.18, py + pr * 0.2, px + pr * 0.36, py + pr * 0.38], fill=(255, 255, 255, 190))
    canvas.alpha_composite(layer, (int(cx - lc), int(cy - lc)))


def equalizer_icon(canvas: Image.Image, cx, cy, h, color=NEON_SOFT):
    """Три вертикальные скруглённые полоски — иконка эквалайзера как на сайте."""
    d = ImageDraw.Draw(canvas)
    bw = h * 0.16
    gap = h * 0.13
    heights = (0.55, 1.0, 0.75)
    total = bw * 3 + gap * 2
    x = cx - total / 2
    for k in heights:
        bh = h * k
        d.rounded_rectangle([x, cy - bh / 2, x + bw, cy + bh / 2], radius=bw / 2, fill=(*color, 255))
        x += bw + gap


# ============================================================
#  НАСТРОЕНИЕ ТАЛИСМАНА: брови над глазами (статичная замена анимации)
# ============================================================
def eye_brows(canvas: Image.Image, ecx, ey, er, spread, mood):
    """Брови над двумя глазами. ecx, ey — центр пары; er — радиус глаза; spread — полусмещение глаз
    по X (все значения — в пикселях холста). mood: 'happy' (дуги), 'worried' (домиком),
    'angry' (сдвинуты к носу вниз), 'ok' — без бровей."""
    if mood not in ("happy", "worried", "angry"):
        return
    thick = max(int(er * 0.17), 3)
    pad = int(er * 1.2)
    layer = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    col = (*NEON_SOFT, 255)
    for side in (-1, 1):                       # -1 = левый глаз, +1 = правый
        cx = ecx + side * spread
        base = ey - er * (1.42 if mood == "happy" else 1.30)
        pts = []
        for i in range(17):
            t = i / 16.0                       # 0 = наружный край, 1 = внутренний (к носу)
            x = cx + side * (er * 0.95) * (1 - 2 * t)   # от внешнего к внутреннему краю
            if mood == "happy":
                y = base - er * 0.30 * math.sin(math.pi * t)
            elif mood == "worried":            # внутренний край выше
                y = base + er * 0.22 * (1 - t) - er * 0.22 * t
            else:                              # angry: внутренний край ниже
                y = base - er * 0.22 * (1 - t) + er * 0.26 * t
            pts.append((x, y))
        d.line(pts, fill=col, width=thick, joint="curve")
        for (x, y) in (pts[0], pts[-1]):
            d.ellipse([x - thick / 2, y - thick / 2, x + thick / 2, y + thick / 2], fill=col)
    x0, y0 = max(int(ecx - spread - er * 2), 0), max(int(ey - er * 3), 0)
    x1, y1 = min(int(ecx + spread + er * 2), canvas.width), min(int(ey), canvas.height)
    glow = layer.crop((x0, y0, x1, y1)).filter(ImageFilter.GaussianBlur(max(int(er * 0.18), 2)))
    canvas.alpha_composite(glow, (x0, y0))
    canvas.alpha_composite(layer.crop((x0, y0, x1, y1)), (x0, y0))
