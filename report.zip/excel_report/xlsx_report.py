"""
Сборка Excel-отчёта UZUM INVENT — тёмная неоновая тема СЛА-сайта (Uzum Design System).

Три листа:
  «Сводка»         — PNG-панель-дашборд (Pillow, dashboard_render.py): ранг, талисман с настроением,
                     кольцо точности, KPI, «эквалайзер» ритма сканирования, достижения, карта ячеек,
                     проблемные ячейки. Сверху — ссылки-кнопки на другие листы.
  «Инвентаризация» — нативная таблица: № | Номер заказа | Ячейка WMS | PU-код (как в скане Telegram) |
                     Найден в ячейке | Время | Статус | (отступ) | ID | Ячейка.
                     Цвет статусов, акценты и зебра сделаны УСЛОВНЫМ ФОРМАТИРОВАНИЕМ, а не картинками
                     поверх ячеек: сортировка и фильтр не «отрывают» цвета от строк. Автофильтр охватывает
                     ВСЕ колонки таблицы, легенда — в закреплённой шапке (не прячется при фильтре).
  «Проблемы»       — подробный разбор: по каждому типу (недостача, излишек, неверная ячейка, задвоенный) —
                     что это значит, что делать и список заказов с PU-кодом, ячейкой, временем и ссылкой на строку.

Ресурсы (logo_solid.png, logo_watermark.png, status_*.png, fonts/Inter-*.otf) лежат в assets/.
"""
import io
import re
import zipfile
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

from openpyxl import Workbook
from openpyxl.formatting.rule import Rule
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.styles.differential import DifferentialStyle
from openpyxl.drawing.image import Image as XLImage
from openpyxl.drawing.spreadsheet_drawing import OneCellAnchor, AnchorMarker, SpreadsheetDrawing
from openpyxl.drawing.xdr import XDRPositiveSize2D
from openpyxl.utils.units import pixels_to_EMU, points_to_pixels
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.dimensions import ColumnDimension
from openpyxl.worksheet.hyperlink import Hyperlink
from openpyxl.worksheet.datavalidation import DataValidation

try:  # rich text (подсветка PU внутри кода) есть в openpyxl >= 3.1
    from openpyxl.cell.rich_text import CellRichText, TextBlock
    from openpyxl.cell.text import InlineFont
    _RICH_OK = True
except Exception:  # pragma: no cover
    _RICH_OK = False

from . import dashboard_render
from . import render_kit as rk


# ============================================================
#  ПАЛИТРА (Uzum Design System / СЛА-сайт)
# ============================================================
def _hex(rgb):
    return "%02X%02X%02X" % tuple(int(v) for v in rgb)


def _rgb(hex_):
    return tuple(int(hex_[i:i + 2], 16) for i in (0, 2, 4))


BG = "030008"            # --bg-base
ROW_A = "0C0518"
ROW_B = "130A28"
HEAD_BG = "1E0B3F"
LINE = "21113F"
NEON = "9D4DFF"
NEON_SOFT = "C7A6FF"
TEXT = "EDE9FA"
TEXT_SOFT = "B8AEE0"
TEXT_DIM = "8B7FAA"

FONT_NAME = "Segoe UI"

STATUS_ACCENT = {
    "Верная ячейка": _hex(rk.C_GREEN),
    "Неверная ячейка": _hex(rk.C_RED),
    "Излишек": _hex(rk.C_PINK),
    "Задвоенный": _hex(rk.C_AMBER),
    "Недостача": _hex(rk.C_GREY),
}
STATUS_KEY = {"Верная ячейка": "ok", "Неверная ячейка": "wrong", "Излишек": "surplus",
              "Задвоенный": "dup", "Недостача": "missing"}
STATUS_ICON_FILES = {"ok": "status_ok.png", "wrong": "status_wrong.png", "surplus": "status_surplus.png",
                     "dup": "status_dup.png", "missing": "status_missing.png"}
OK_STATUS = "Верная ячейка"


def _mixhex(a_hex, b_hex, k):
    return _hex(rk.mix(_rgb(a_hex), _rgb(b_hex), k))


def _fill(hex_):
    return PatternFill(start_color=hex_, end_color=hex_, fill_type="solid")


FILL_BG = _fill(BG)
FILL_HEAD = _fill(HEAD_BG)
FILL_A = _fill(ROW_A)
FILL_B = _fill(ROW_B)

ASSETS_DIR = Path(__file__).parent / "assets"
ROW_H_PT = 24

# ---- лист «Инвентаризация»
COL_WIDTHS = {'A': 2, 'B': 6, 'C': 17, 'D': 14, 'E': 25, 'F': 16, 'G': 11, 'H': 22, 'I': 27, 'J': 3, 'K': 14, 'L': 11,
              'M': 16, 'N': 9}
COL_NUM = {name: idx for idx, name in enumerate("ABCDEFGHIJKLMNOP", start=1)}
HEADER_ROW = 6
FIRST_DATA_ROW = 7
DATA_LAST_COL = "L"
HIDDEN_COLS = ("M", "N")      # служебные: исходный статус и накопительный номер проблемы
EXTRA_ROWS = 30               # пустые строки «про запас» под таблицей (можно дописывать свои заказы)
DATA_SHEET = "Инвентаризация"
SUM_SHEET = "Сводка"
PROB_SHEET = "Проблемы"
COMMENTS_SHEET = "Комменты"

# ---- лист «Проблемы»
PCOL_WIDTHS = {'A': 2, 'B': 6, 'C': 17, 'D': 25, 'E': 13, 'F': 15, 'G': 11, 'H': 62, 'I': 14}

PU_RE = re.compile(r"PU\d+", re.I)


def _col_width_to_px(excel_width: float) -> int:
    mdw = 7
    return int(((256 * excel_width + int(128 / mdw)) / 256) * mdw)


# ============================================================
#  ТЕКСТЫ (RU / UZ)
# ============================================================
LEGEND = {
    "ru": {
        "title": "Обозначение статусов",
        "rows": [
            ("ok", "Верная ячейка", "Заказ находится в своей ячейке, всё верно."),
            ("wrong", "Неверная ячейка", "Заказ отсканирован не в той ячейке, где должен быть по списку."),
            ("surplus", "Излишек", "Такого заказа вообще нет в загруженном списке (чужой или лишний)."),
            ("dup", "Задвоенный", "Этот заказ уже был отсканирован ранее (повторное сканирование)."),
            ("missing", "Недостача", "Заказ есть в списке, но его не нашли ни в одной ячейке."),
        ]
    },
    "uz": {
        "title": "Statuslar izohi",
        "rows": [
            ("ok", "To‘g‘ri katak", "Buyurtma o‘z katagida, hammasi to‘g‘ri."),
            ("wrong", "Noto‘g‘ri katak", "Buyurtma ro‘yxat bo‘yicha boshqa katakda bo‘lishi kerak edi."),
            ("surplus", "Ortiqcha", "Bu buyurtma yuklangan ro‘yxatda umuman yo‘q (begona yoki ortiqcha)."),
            ("dup", "Ikkilangan", "Bu buyurtma avval skanerlangan (qayta skanerlash)."),
            ("missing", "Yetishmovchilik", "Buyurtma ro‘yxatda bor, lekin hech bir katakda topilmadi."),
        ]
    }
}

T = {
    "ru": {
        "hdr": {"no": "№", "order": "НОМЕР ЗАКАЗА", "wms_cell": "ЯЧЕЙКА ПО WMS", "pu": "PU-КОД (СКАН)",
                "scan_cell": "НАЙДЕН В ЯЧЕЙКЕ", "time": "ВРЕМЯ", "status": "СТАТУС", "note": "ПОМЕТКА", "id": "ID", "cell": "ЯЧЕЙКА"},
        "grp": {"wms": "ПО СПИСКУ WMS", "fact": "ФАКТ: ЧТО ОТСКАНИРОВАЛИ  (можно править)",
                "total": "ИТОГ  ·  выбери статус из списка ▾", "copy": "ЗАКАЗЫ WMS · СТАТУС ВЫДАЧИ"},
        "edit_hint": "✎ можно править",
        "note": {"was": "✎ было: ", "need": "  ⚠ впиши ячейку", "mism": "  ⚠ не совпадает с WMS"},
        "dv": {"ptitle": "Статус заказа", "prompt": "Выберите статус из списка. Нашли недостачу — поставьте «Верная ячейка» "
               "и впишите PU-код и ячейку: сводка, кольцо, глаза и лист «Проблемы» обновятся сами.",
               "etitle": "Нет такого статуса", "error": "Выберите статус из выпадающего списка."},
        "nav_table": "ОТКРЫТЬ ТАБЛИЦУ  →", "nav_problems": "РАЗБОР ПРОБЛЕМ  →", "nav_summary": "←  СВОДКА", "nav_comments": "КОММЕНТАРИИ  →",
        "prob_title": "Разбор проблем", "prob_sub": "UZUM MARKET  ·  ЧТО ИСПРАВИТЬ",
        "verdict_ok": "Всё чисто — расхождений нет",
        "verdict_bad": "Нужно разобрать расхождений: {n}",
        "verdict_hint": "Начните с ячейки {cell}: там больше всего проблем.",
        "what": "ЧТО ЭТО", "todo": "ЧТО ДЕЛАТЬ",
        "ph": {"no": "№", "order": "ЗАКАЗ", "pu": "PU-КОД", "wms": "ПО WMS", "found": "НАЙДЕН В", "time": "ВРЕМЯ",
               "what": "ЧТО ПРОИЗОШЛО", "go": "ПЕРЕЙТИ"},
        "sec": {
            "missing": ("Недостача",
                        "Заказ есть в списке WMS, но при проверке его не отсканировали.",
                        "Ещё раз загляните в указанную ячейку и соседние (заказ мог упасть за полку). "
                        "Проверьте заказ в WMS — возможно, его уже выдали или вернули. Если нигде нет — оформляйте недостачу по правилам ПВЗ."),
            "surplus": ("Излишек",
                        "Заказ отсканировали, но его номера нет в загруженном списке WMS. Так бывает, если заказ уже «выдан» "
                        "(в список «К выдаче» он не попадает), а сам заказ остался на полке, либо это ещё одно место (PU) того же заказа.",
                        "Найдите номер в WMS и посмотрите статус. «Заказ выдан» — заказ нужно проверить и оформить (возврат или лишнее место). "
                        "Если у заказа несколько мест — сверьте PU-коды. Если заказа нет совсем — это чужой заказ."),
            "wrong": ("Неверная ячейка",
                      "Заказ найден, но лежит не в той ячейке, где числится в WMS.",
                      "Переложите заказ в ячейку из колонки «По WMS» — или поправьте ячейку в WMS, если заказ должен лежать там, где нашли."),
            "dup": ("Задвоенный",
                    "Один и тот же заказ отсканирован больше раз, чем он числится в списке.",
                    "Сравните PU-коды: если они РАЗНЫЕ (PU01, PU02…) — это разные места одного заказа, а не повтор; проверьте, сколько мест числится в WMS. "
                    "Если код один и тот же — заказ просто отсканировали дважды, ничего исправлять не нужно."),
        },
        "row": {
            "missing": "Должен быть в ячейке {exp}, но при проверке не найден{places}",
            "wrong": "Лежит в ячейке {scan}, а по WMS должен быть в {exp} — переложить",
            "surplus": "Отсканирован в ячейке {scan}, но в списке WMS его нет",
            "dup": "Отсканирован повторно в ячейке {scan}{other}",
        },
        "places": " (мест по списку: {n})",
        "other": " · у заказа есть другое место ({pus}) — возможно, это не повтор",
        "link": "→ №{n}",
        "no_time": "—",
    },
    "uz": {
        "hdr": {"no": "№", "order": "BUYURTMA RAQAMI", "wms_cell": "WMS KATAGI", "pu": "PU-KOD (SKAN)",
                "scan_cell": "TOPILGAN KATAK", "time": "VAQT", "status": "STATUS", "note": "IZOH", "id": "ID", "cell": "KATAK"},
        "grp": {"wms": "WMS RO‘YXATI BO‘YICHA", "fact": "FAKT: NIMA SKANERLANDI  (tahrirlash mumkin)",
                "total": "NATIJA  ·  statusni tanlang ▾", "copy": "WMS BUYURTMALARI · BERISH STATUSI"},
        "edit_hint": "✎ tahrirlash mumkin",
        "note": {"was": "✎ edi: ", "need": "  ⚠ katakni kiriting", "mism": "  ⚠ WMS bilan mos emas"},
        "dv": {"ptitle": "Buyurtma statusi", "prompt": "Ro‘yxatdan statusni tanlang. Yetishmovchilik topilsa — «Верная ячейка» ni tanlab, "
               "PU-kod va katakni kiriting: xulosa, halqa, ko‘zlar va «Проблемы» varag‘i o‘zi yangilanadi.",
               "etitle": "Bunday status yo‘q", "error": "Statusni ochiladigan ro‘yxatdan tanlang."},
        "nav_table": "JADVALNI OCHISH  →", "nav_problems": "MUAMMOLAR TAHLILI  →", "nav_summary": "←  XULOSA", "nav_comments": "IZOHLAR  →",
        "prob_title": "Muammolar tahlili", "prob_sub": "UZUM MARKET  ·  NIMANI TUZATISH KERAK",
        "verdict_ok": "Hammasi toza — farqlar yo‘q",
        "verdict_bad": "Ko‘rib chiqiladigan farqlar: {n}",
        "verdict_hint": "{cell}-katakdan boshlang: eng ko‘p muammo shu yerda.",
        "what": "BU NIMA", "todo": "NIMA QILISH KERAK",
        "ph": {"no": "№", "order": "BUYURTMA", "pu": "PU-KOD", "wms": "WMS BO‘YICHA", "found": "TOPILGAN", "time": "VAQT",
               "what": "NIMA BO‘LDI", "go": "O‘TISH"},
        "sec": {
            "missing": ("Yetishmovchilik",
                        "Buyurtma WMS ro‘yxatida bor, lekin tekshiruvda skanerlanmadi.",
                        "Ko‘rsatilgan va qo‘shni kataklarni yana bir bor tekshiring (buyurtma javon orqasiga tushib ketgan bo‘lishi mumkin). "
                        "Buyurtmani WMS’da tekshiring — balki berilgan yoki qaytarilgan. Hech qayerda yo‘q bo‘lsa, PYZ qoidasiga ko‘ra rasmiylashtiring."),
            "surplus": ("Ortiqcha",
                        "Buyurtma skanerlandi, lekin bu raqam yuklangan WMS ro‘yxatida yo‘q. Buyurtma allaqachon «berilgan» bo‘lsa "
                        "(«Berishga tayyor» ro‘yxatiga tushmaydi), u javonda qolgan yoki bu o‘sha buyurtmaning yana bir joyi (PU) bo‘lishi mumkin.",
                        "Raqamni WMS’da toping va statusini ko‘ring. «Buyurtma berilgan» bo‘lsa — buyurtmani tekshirib rasmiylashtiring. "
                        "Buyurtmaning bir necha joyi bo‘lsa — PU-kodlarni solishtiring. Buyurtma umuman yo‘q bo‘lsa — begona buyurtma."),
            "wrong": ("Noto‘g‘ri katak",
                      "Buyurtma topildi, lekin WMS’da ko‘rsatilgan katakda emas.",
                      "Buyurtmani «WMS bo‘yicha» ustunidagi katakka ko‘chiring yoki u haqiqatan shu yerda turishi kerak bo‘lsa, WMS’da katakni to‘g‘rilang."),
            "dup": ("Ikkilangan",
                    "Bir xil buyurtma ro‘yxatdagidan ko‘p marta skanerlandi.",
                    "PU-kodlarni solishtiring: ular TURLICHA bo‘lsa (PU01, PU02…) — bu bir buyurtmaning turli joylari, takror emas; WMS’da nechta joy borligini tekshiring. "
                    "Kod bir xil bo‘lsa — buyurtma shunchaki ikki marta skanerlangan, hech narsa qilish shart emas."),
        },
        "row": {
            "missing": "{exp}-katakda bo‘lishi kerak, lekin tekshiruvda topilmadi{places}",
            "wrong": "{scan}-katakda turibdi, WMS bo‘yicha {exp}-katakda bo‘lishi kerak — ko‘chiring",
            "surplus": "{scan}-katakda skanerlandi, lekin WMS ro‘yxatida yo‘q",
            "dup": "{scan}-katakda qayta skanerlandi{other}",
        },
        "places": " (ro‘yxatdagi joylar: {n})",
        "other": " · buyurtmaning boshqa joyi bor ({pus}) — takror bo‘lmasligi mumkin",
        "link": "→ №{n}",
        "no_time": "—",
    },
}
SEC_ORDER = ["Недостача", "Излишек", "Неверная ячейка", "Задвоенный"]
SEC_KEY = {"Недостача": "missing", "Излишек": "surplus", "Неверная ячейка": "wrong", "Задвоенный": "dup"}


# ============================================================
#  ХЕЛПЕРЫ
# ============================================================
_ASSET_CACHE: dict[str, bytes] = {}


def _asset_bytes(fname: str) -> bytes:
    cached = _ASSET_CACHE.get(fname)
    if cached is None:
        cached = (ASSETS_DIR / fname).read_bytes()
        _ASSET_CACHE[fname] = cached
    return cached


def _place_image(ws, png_bytes, col_idx, row_idx, w_px, h_px, off_x=0, off_y=0, alt=""):
    """Картинка w_px×h_px, прижатая к ячейке с пиксельным смещением; alt — описание для скринридеров."""
    img = XLImage(io.BytesIO(png_bytes))
    img.width, img.height = int(w_px), int(h_px)
    marker = AnchorMarker(col=col_idx - 1, colOff=pixels_to_EMU(off_x), row=row_idx - 1, rowOff=pixels_to_EMU(off_y))
    anchor = OneCellAnchor(_from=marker, ext=XDRPositiveSize2D(pixels_to_EMU(int(w_px)), pixels_to_EMU(int(h_px))))
    pic = SpreadsheetDrawing()._picture_frame(len(ws._images) + 1)
    pic.nvPicPr.cNvPr.descr = alt
    anchor.pic = pic
    img.anchor = anchor
    ws.add_image(img)


def _style_column(ws, letter: str, width: float | None = None):
    cd = ws.column_dimensions[letter]
    if width is not None:
        cd.width = width
    cd.fill = FILL_BG


def _dark_sheet(ws, first_free_col: int, used_widths: dict | None = None):
    """Красит весь лист в фон #030008: колонки A..last (с шириной) + хвост до XFD — белого поля нет."""
    for letter, width in (used_widths or {}).items():
        _style_column(ws, letter, width)
    tail = ColumnDimension(ws, index=get_column_letter(first_free_col), min=first_free_col, max=16384, width=9)
    tail.fill = FILL_BG
    ws.column_dimensions[get_column_letter(first_free_col)] = tail


def _merge(ws, r1, c1, r2, c2, value=None, *, font=None, fill=None, align=None, border=None):
    # Объединение ОДНОЙ ячейки (ref вида "H5") — недопустимо для Excel и вызывает окно «восстановить файл».
    if (r1, c1) != (r2, c2):
        ws.merge_cells(start_row=r1, start_column=c1, end_row=r2, end_column=c2)
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            cell = ws.cell(row=r, column=c)
            if fill:
                cell.fill = fill
            if border:
                cell.border = border
    tl = ws.cell(row=r1, column=c1)
    if value is not None:
        tl.value = value
    if font:
        tl.font = font
    if align:
        tl.alignment = align
    return tl


def _page_setup(ws):
    ws.sheet_view.showGridLines = False
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins.left = ws.page_margins.right = 0.3
    ws.page_margins.top = ws.page_margins.bottom = 0.3
    ws.oddFooter.center.text = "UZUM INVENT  ·  by DAMIR"
    ws.oddFooter.center.size = 8


def _link(cell, sheet, ref, text, *, size=9, color=NEON_SOFT, bold=True):
    cell.value = text
    cell.hyperlink = Hyperlink(ref="", location=f"'{sheet}'!{ref}", display=text)
    cell.font = Font(name=FONT_NAME, size=size, bold=bold, color=color, underline="single")


def _nav_chip(ws, row, c1, c2, text, sheet, ref):
    tl = _merge(ws, row, c1, row, c2, None, fill=FILL_HEAD,
                border=Border(top=Side(style='thin', color=NEON), bottom=Side(style='thin', color=NEON),
                              left=Side(style='thin', color=NEON), right=Side(style='thin', color=NEON)),
                align=Alignment(horizontal='center', vertical='center'))
    _link(tl, sheet, ref, text, size=9)


def _pu_split(code):
    m = PU_RE.search(code or "")
    return (code[:m.start()], m.group(0).upper(), code[m.end():]) if m else None


def _pu_value(code):
    """Код скана; PU-часть подсвечена (rich text), остальное приглушено."""
    sp = _pu_split(code)
    if not sp or not _RICH_OK:
        return code
    pre, pu, post = sp
    blocks = []
    if pre:
        blocks.append(TextBlock(InlineFont(rFont=FONT_NAME, sz=10, color=TEXT_DIM), pre))
    blocks.append(TextBlock(InlineFont(rFont=FONT_NAME, sz=10.5, b=True, color=NEON_SOFT), pu))
    if post:
        blocks.append(TextBlock(InlineFont(rFont=FONT_NAME, sz=10, color=TEXT_DIM), post))
    return CellRichText(*blocks)


def _parse_dt(v):
    if not v:
        return None
    if isinstance(v, datetime):
        return v
    try:
        return datetime.fromisoformat(str(v))
    except ValueError:
        return None


def _cell_key(c):
    c = str(c)
    return (0, int(c), c) if c.isdigit() else (1, 0, c)


def _is_scanned(row):
    return row.get("status") != "Недостача"


def _cell_map(full_rows):
    """{ячейка: Counter({статус: n})}: на какую ячейку «ложится» каждая строка.
    неверная — и ожидаемая, и фактическая; излишек/задвоенный — где отсканирован; недостача — ожидаемая."""
    agg: dict[str, Counter] = {}

    def add(cell, st):
        if cell:
            agg.setdefault(str(cell), Counter())[st] += 1

    for r in full_rows:
        st, exp, sc = r["status"], r.get("expected_cell"), r.get("scanned_cell")
        if st == "Неверная ячейка":
            add(exp, st)
            add(sc, st)
        elif st in ("Излишек", "Задвоенный"):
            add(sc or exp, st)
        else:
            add(exp or sc, st)
    return sorted(agg.items(), key=lambda kv: _cell_key(kv[0]))


def _problem_cells(full_rows, limit: int = 6):
    """Топ ячеек по числу расхождений: [(ячейка, Counter({статус: n})), ...]."""
    ranked = []
    for cell, cnt in _cell_map(full_rows):
        probs = Counter({k: v for k, v in cnt.items() if k != OK_STATUS})
        if probs:
            ranked.append((cell, probs))
    ranked.sort(key=lambda kv: (-sum(kv[1].values()), _cell_key(kv[0])))
    return ranked[:limit]


def _rhythm(full_rows):
    """Данные для «эквалайзера»: сканы по минутам (по реальному времени каждого скана)."""
    times = sorted(dt for dt in (_parse_dt(r.get("scanned_at")) for r in full_rows if _is_scanned(r)) if dt)
    if not times:
        return None
    first, last = times[0], times[-1]
    f_min = first.replace(second=0, microsecond=0)
    n_min = int((last.replace(second=0, microsecond=0) - f_min).total_seconds() // 60) + 1
    g = -(-n_min // 48) if n_min > 48 else 1
    nb = -(-n_min // g)
    counts = [0] * nb
    for dt in times:
        m = int((dt.replace(second=0, microsecond=0) - f_min).total_seconds() // 60)
        counts[m // g] += 1
    span_min = (last - first).total_seconds() / 60.0
    first_batch = sum(1 for dt in times if dt == first)
    speed = ((len(times) - first_batch) / span_min) if span_min >= 1 and len(times) > first_batch else None
    mins = int(round(span_min))
    dur = "< 1 мин" if mins < 1 else (f"{mins} мин" if mins < 60 else f"{mins // 60} ч {mins % 60} мин")
    peak_i = counts.index(max(counts))
    peak_dt = datetime.fromtimestamp(f_min.timestamp() + peak_i * g * 60)
    return {
        "counts": counts, "start": first.strftime("%H:%M"), "end": last.strftime("%H:%M"),
        "duration": dur, "speed": (f"≈{speed:.1f}".replace(".", ",") + " скан/мин") if speed else "—",
        "speed_val": speed, "total": len(times), "peak_time": peak_dt.strftime("%H:%M"),
    }


def _achievements(kpis, rhythm):
    total = kpis["total"]
    acc = (kpis["correct"] / total * 100) if total else 0.0
    has = total > 0
    sp = (rhythm or {}).get("speed_val")
    return [
        ("Ноль излишков", has and kpis["surplus"] == 0),
        ("Ничего не потеряно", has and kpis["shortage"] == 0),
        ("Ячейки без путаницы", has and kpis["wrong"] == 0),
        ("Без повторных сканов", has and kpis["dup"] == 0),
        ("Точность 95% и выше", has and round(acc, 1) >= 95),
        ("Турбо-темп: 10+ скан/мин", bool(sp and sp >= 10)),
    ]


def _inject_ignored_errors(xlsx_bytes: bytes, specs: dict[int, str]) -> bytes:
    """Убирает зелёные треугольники «число хранится как текст» (номера заказов — текст намеренно).
    specs: {номер листа (1..): 'B7:K300'}. Если что-то пошло не так — возвращаем файл как был."""
    try:
        src = zipfile.ZipFile(io.BytesIO(xlsx_bytes))
        out = io.BytesIO()
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as dst:
            for item in src.infolist():
                data = src.read(item.filename)
                m = re.fullmatch(r"xl/worksheets/sheet(\d+)\.xml", item.filename)
                if m and int(m.group(1)) in specs:
                    xml = data.decode("utf-8")
                    tag = f'<ignoredErrors><ignoredError sqref="{specs[int(m.group(1))]}" numberStoredAsText="1"/></ignoredErrors>'
                    for anchor in ("<drawing ", "<legacyDrawing", "<tableParts", "</worksheet>"):
                        if anchor in xml:
                            xml = xml.replace(anchor, tag + anchor, 1)
                            break
                    data = xml.encode("utf-8")
                dst.writestr(item, data)
        return out.getvalue()
    except Exception:
        return xlsx_bytes


# ============================================================
#  УСЛОВНОЕ ФОРМАТИРОВАНИЕ (цвета следуют за данными при сортировке/фильтре/правке статуса)
# ============================================================
def _cf(ws, rng, formula, *, font=None, fill=None, border=None):
    ws.conditional_formatting.add(rng, Rule(type="expression", formula=[formula],
                                            dxf=DifferentialStyle(font=font, fill=fill, border=border)))


def _status_formatting(ws, first, last):
    for status, accent in STATUS_ACCENT.items():
        light = _mixhex(accent, "FFFFFF", 0.25)
        cond = f'$H{first}="{status}"'
        # чип статуса
        side = Side(style="thin", color=accent)
        _cf(ws, f"H{first}:H{last}", cond, font=Font(color=light, bold=True),
            fill=_fill(_mixhex(ROW_A, accent, 0.24)), border=Border(left=side, right=side, top=side, bottom=side))
        # цветная плашка с номером строки слева (вместо картинки/толстой границы)
        calm = 0.30 if status == OK_STATUS else 0.62
        _cf(ws, f"B{first}:B{last}", cond, font=Font(color="FFFFFF", bold=True), fill=_fill(_mixhex(ROW_A, accent, calm)))
        if status != OK_STATUS:
            _cf(ws, f"C{first}:C{last}", cond, font=Font(color=light, bold=True))
            if status != "Недостача":
                _cf(ws, f"F{first}:F{last}", cond, font=Font(color=light, bold=True))
    # пометка: предупреждение — янтарным, «исправлено вручную» — зелёным
    _cf(ws, f"I{first}:I{last}", f'ISNUMBER(SEARCH("⚠",$I{first}))',
        font=Font(color=_hex(rk.C_AMBER), bold=True))
    _cf(ws, f"I{first}:I{last}", f'$I{first}<>""', font=Font(color=_hex(rk.C_GREEN), bold=True))
    # зебра — последним (самый низкий приоритет); колонки B и H красятся статусом
    _cf(ws, f"C{first}:G{last} I{first}:I{last} K{first}:L{last}", "MOD(ROW(),2)=0", fill=_fill(ROW_B))


def note_text(tx, status, orig, wms_cell, found_cell, order_id):
    """Пометка строки (зеркало формулы колонки I — нужно для кэшированных значений)."""
    if not order_id:
        return ""
    n = tx["note"]
    s = ""
    if orig and status != orig:
        s += n["was"] + orig
    if status == OK_STATUS and found_cell in ("", "—"):
        s += n["need"]
    if status == OK_STATUS and found_cell not in ("", "—") and wms_cell != "—" and str(found_cell) != str(wms_cell):
        s += n["mism"]
    return " ".join(s.split())


# ============================================================
#  ЛИСТ «ИНВЕНТАРИЗАЦИЯ» (редактируемый)
# ============================================================
def _build_data_sheet(ws, tx, rows, ident, timestamp, language, cache):
    _dark_sheet(ws, len(COL_WIDTHS) + 1, COL_WIDTHS)
    for letter in HIDDEN_COLS:
        ws.column_dimensions[letter].hidden = True
    cn = COL_NUM

    banner_w = sum(_col_width_to_px(COL_WIDTHS[c]) for c in "BCDEFGHIJKL")
    banner_png, bw, bh = dashboard_render.render_banner(ident, timestamp, banner_w, ASSETS_DIR, lang=language,
                                                        title="PYZ inventarizatsiyasi" if language == "uz" else "Инвентаризация ПВЗ")
    for r in (1, 2, 3):
        ws.row_dimensions[r].height = 20
    _place_image(ws, banner_png, cn['B'], 1, bw, bh, alt="Шапка отчёта: инвентаризация ПВЗ")

    # --- строка 4: закреплённая мини-легенда (не прячется при фильтре) ---
    ws.row_dimensions[4].height = 20
    legend = LEGEND.get(language, LEGEND['ru'])["rows"]
    spans = {"ok": ("C", "D"), "wrong": ("E", "E"), "surplus": ("F", "G"), "dup": ("H", "H"), "missing": ("I", "I")}
    key_color = {STATUS_KEY[k]: v for k, v in STATUS_ACCENT.items()}
    for key, name, _expl in legend:
        a, b = spans[key]
        _merge(ws, 4, cn[a], 4, cn[b], f"●  {name}", fill=FILL_BG,
               font=Font(name=FONT_NAME, size=8.5, bold=True, color=key_color[key]),
               align=Alignment(horizontal='left', vertical='center', indent=1))
    _merge(ws, 4, cn['K'], 4, cn['L'], tx["edit_hint"], fill=FILL_BG,
           font=Font(name=FONT_NAME, size=8, italic=True, color=TEXT_DIM),
           align=Alignment(horizontal='left', vertical='center', wrap_text=True))

    # --- строка 5: подписи групп колонок ---
    ws.row_dimensions[5].height = 16
    cap_font = Font(name=FONT_NAME, size=8, bold=True, color=TEXT_DIM)
    cap_align = Alignment(horizontal='left', vertical='center', indent=1)
    g = tx["grp"]
    _merge(ws, 5, cn['C'], 5, cn['D'], g["wms"], font=cap_font, fill=FILL_BG, align=cap_align)
    _merge(ws, 5, cn['E'], 5, cn['G'], g["fact"], font=cap_font, fill=FILL_BG, align=cap_align)
    _merge(ws, 5, cn['H'], 5, cn['I'], g["total"], font=cap_font, fill=FILL_BG, align=cap_align)
    _merge(ws, 5, cn['K'], 5, cn['L'], g["copy"], font=cap_font, fill=FILL_BG, align=cap_align)

    # --- строка 6: заголовки колонок ---
    ws.row_dimensions[HEADER_ROW].height = 30
    head_font = Font(name=FONT_NAME, size=9, bold=True, color=TEXT_SOFT)
    head_border = Border(bottom=Side(style='medium', color=NEON))
    h = tx["hdr"]
    headers = {"B": h["no"], "C": h["order"], "D": h["wms_cell"], "E": h["pu"], "F": h["scan_cell"],
               "G": h["time"], "H": h["status"], "I": h["note"], "K": h["id"], "L": h["cell"],
               "M": "ИСХОДНЫЙ СТАТУС", "N": "№ ПРОБЛЕМЫ"}
    for letter, text in headers.items():
        c = ws.cell(row=HEADER_ROW, column=cn[letter], value=text)
        c.font, c.fill, c.border = head_font, FILL_HEAD, head_border
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    # --- данные + пустые строки «про запас» (можно дописывать свои заказы) ---
    base_border = Border(bottom=Side(style='thin', color=LINE))
    center = Alignment(horizontal="center", vertical="center")
    n = len(rows)
    last_row = FIRST_DATA_ROW + n - 1
    end_row = last_row + EXTRA_ROWS
    written = []
    for i in range(1, n + EXTRA_ROWS + 1):
        r = FIRST_DATA_ROW + i - 1
        ws.row_dimensions[r].height = ROW_H_PT
        row = rows[i - 1] if i <= n else None
        values = {}
        w = None
        if row:
            scanned = _is_scanned(row)
            dt = _parse_dt(row.get("scanned_at")) if scanned else None
            tsec = (dt.hour * 3600 + dt.minute * 60 + dt.second) if dt else None
            w = {"b": i, "c": str(row["wms_id"]), "d": str(row.get("expected_cell") or "—"),
                 "f": str((row.get("scanned_cell") or "—") if scanned else "—"), "t": tsec,
                 "h": row["status"], "m": row["status"], "full": row.get("full_code") or "", "scanned": scanned}
            written.append(w)
            values = {
                "B": i, "C": w["c"], "D": w["d"],
                "E": _pu_value(w["full"]) if scanned and w["full"] else "—",
                "F": w["f"],
                "G": dt.replace(microsecond=0).time() if dt else "—",
                "H": row["status"], "K": w["c"], "L": row.get("expected_cell") or "", "M": row["status"],
            }
        for letter in "BCDEFGHIKLM":
            c = ws.cell(row=r, column=cn[letter], value=values.get(letter))
            c.fill = FILL_A
            c.border = base_border
            c.alignment = center
            val = values.get(letter)
            if letter == "B":
                c.font = Font(name=FONT_NAME, size=9, color=TEXT_DIM)
            elif letter in ("C", "K"):
                c.font = Font(name=FONT_NAME, size=10, color=TEXT, bold=True)
            elif letter == "H":
                c.font = Font(name=FONT_NAME, size=9.5, color=STATUS_ACCENT.get(row["status"], TEXT_SOFT) if row else TEXT_SOFT, bold=True)
            elif letter in ("D", "L"):
                c.font = Font(name=FONT_NAME, size=10, color=TEXT)
            elif letter == "E" and val not in (None, "—") and not isinstance(val, str):
                c.font = Font(name=FONT_NAME, size=10, color=TEXT_DIM)
            elif letter == "F" and val not in (None, "—"):
                c.font = Font(name=FONT_NAME, size=10, color=TEXT)
            elif letter == "M":
                c.font = Font(name=FONT_NAME, size=8, color=TEXT_DIM)
            else:
                c.font = Font(name=FONT_NAME, size=9.5, color=TEXT_DIM if val in (None, "—") else TEXT_SOFT)
            if letter == "G":
                c.number_format = "hh:mm:ss"
        # формулы: пометка (I) и накопительный номер проблемы (N)
        ci = ws.cell(row=r, column=cn["I"])
        ci.value = ('=IF($C{r}="","",TRIM(IF(AND($M{r}<>"",$H{r}<>$M{r}),"{was}"&$M{r},"")'
                    '&IF(AND($H{r}="{ok}",OR($F{r}="",$F{r}="—")),"{need}","")'
                    '&IF(AND($H{r}="{ok}",$F{r}<>"",$F{r}<>"—",$D{r}<>"—",""&$F{r}<>""&$D{r}),"{mism}","")))'
                    ).format(r=r, ok=OK_STATUS, was=tx["note"]["was"], need=tx["note"]["need"], mism=tx["note"]["mism"])
        ci.fill, ci.border, ci.alignment = FILL_A, base_border, Alignment(horizontal="left", vertical="center", indent=1)
        ci.font = Font(name=FONT_NAME, size=9, color=TEXT_SOFT)
        cn_ = ws.cell(row=r, column=cn["N"])
        cn_.value = (f'=IF(AND($C{r}<>"",$H{r}<>"{OK_STATUS}"),1,0)+N(N{r - 1})')
        cn_.font, cn_.fill = Font(name=FONT_NAME, size=8, color=TEXT_DIM), FILL_A
        if w:
            cache[(ws.title, f"I{r}")] = note_text(tx, w["h"], w["m"], w["d"], w["f"], w["c"])
            w["_r"] = r
        else:
            cache[(ws.title, f"I{r}")] = ""
    # накопительный номер проблемы — зеркало
    cum = 0
    for i in range(1, n + EXTRA_ROWS + 1):
        r = FIRST_DATA_ROW + i - 1
        if i <= n and written[i - 1]["h"] != OK_STATUS:
            cum += 1
        cache[(ws.title, f"N{r}")] = cum

    _status_formatting(ws, FIRST_DATA_ROW, end_row)
    # выпадающий список статусов — главный инструмент «живого» отчёта
    dv = DataValidation(type="list", formula1='"' + ",".join(STATUS_ACCENT) + '"', allow_blank=True)
    dv.showDropDown = False
    dv.showInputMessage = True
    dv.promptTitle, dv.prompt = tx["dv"]["ptitle"], tx["dv"]["prompt"]
    dv.showErrorMessage = True
    dv.errorTitle, dv.error = tx["dv"]["etitle"], tx["dv"]["error"]
    ws.add_data_validation(dv)
    dv.add(f"H{FIRST_DATA_ROW}:H{end_row}")
    ws.auto_filter.ref = f"B{HEADER_ROW}:N{end_row}"
    ws.freeze_panes = f"A{FIRST_DATA_ROW}"
    ws.print_area = f"A1:{DATA_LAST_COL}{end_row}"
    ws.print_title_rows = f"{HEADER_ROW}:{HEADER_ROW}"
    return last_row, end_row, written



# ============================================================
#  УЗБЕКСКАЯ ВЕРСИЯ ФАЙЛА
# ============================================================
# Отчёт целиком собирается на русском (формулы, статусы и названия листов связаны между собой), а для
# узбекского профиля в самом конце ВСЕ русские слова одним проходом заменяются узбекскими — в ячейках,
# формулах, списке статусов, диаграммах и названиях листов. Раз замена одна и та же везде, формулы
# остаются согласованными: выбор статуса из списка и пересчёт работают как в русском файле.
_UZ_SHEETS = {"Сводка": "Xulosa", "Инвентаризация": "Inventarizatsiya", "Проблемы": "Muammolar", "Комменты": "Izohlar",
              "_данные": "_malumot", "_глаза": "_kozlar"}
_UZ_MOODS = {
    # имя настроения
    "Звёздные глаза": "Yulduzli ko‘zlar", "Влюблён в порядок": "Tartibga oshiq", "В полном восторге": "Behad xursand",
    "Сияет": "Porlayapti", "Подмигивает": "Ko‘z qisyapti", "Довольный": "Mamnun", "Радуется": "Quvonyapti",
    "Улыбается": "Jilmayapti", "Доволен": "Rozi", "Спокоен": "Xotirjam", "Расслаблен": "Bemalol",
    "Задумался": "O‘ylanib qoldi", "Нейтральный": "Neytral", "Смотрит в упор": "Tikilib turibdi",
    "Скучает": "Zerikyapti", "Нервничает": "Asabiylashyapti", "Косится": "Ko‘z qirida qarayapti",
    "Напряжён": "Tarang", "Грустит": "Xafa", "Расстроен": "Ko‘ngli cho‘kkan", "Переживает": "Xavotirda",
    "Плачет": "Yig‘layapti", "Злится": "Jahli chiqyapti", "В шоке": "Shokda", "В ярости": "G‘azabda",
    "Сломался": "Buzilib qoldi", "Голова кружится": "Boshi aylanyapti", "Спит": "Uxlayapti",
    "Дремлет": "Mudrayapti", "Клюёт носом": "Uyqusirayapti",
    # подпись под глазами
    "ИДЕАЛЬНО! Все заказы на своих местах": "MUKAMMAL! Hamma buyurtmalar o‘z joyida",
    "Ни одной ошибки — это любовь!": "Birorta xato yo‘q — bu sevgi!",
    "Легенда ПВЗ! Хоть в рамку вешай": "PYZ afsonasi! Ramkaga solib osib qo‘ysa bo‘ladi",
    "Почти идеал — красавчик!": "Deyarli mukammal — barakalla!",
    "Чётко сработано, так держать!": "Aniq ishlandi, shunday davom eting!",
    "Огонь! Заказы на своих местах": "Zo‘r! Buyurtmalar o‘z joyida",
    "Отличный результат!": "Ajoyib natija!",
    "Хорошая работа, остались мелочи": "Yaxshi ish, mayda-chuydalar qoldi",
    "Почти всё сошлось": "Deyarli hammasi mos tushdi",
    "Нормально, но можно лучше": "Yomon emas, lekin yaxshiroq bo‘lishi mumkin",
    "Неплохо — перепроверь пару заказов": "Yomon emas — bir-ikki buyurtmani qayta tekshiring",
    "Хм… есть что поправить": "Hm… tuzatadigan joylar bor",
    "Среднячок… можно и лучше": "O‘rtacha… yaxshiroq bo‘lishi mumkin",
    "Ни рыба ни мясо": "Na baliq, na go‘sht",
    "Ну такое себе…": "Unchalik emas…",
    "Что-то тут не так…": "Nimadir noto‘g‘ri…",
    "Пахнет перепроверкой": "Qayta tekshirish hidi kelyapti",
    "Хмм, подозрительно много расхождений": "Hmm, farqlar shubhali ko‘p",
    "Грустно… часть заказов потерялась": "Afsus… ba’zi buyurtmalar yo‘qolgan",
    "Эх, надо искать заказы": "Eh, buyurtmalarni qidirish kerak",
    "Много расхождений — проверь ячейки": "Farqlar ko‘p — kataklarni tekshiring",
    "Ууу… столько косяков": "Uuu… xatolar juda ko‘p",
    "Злюсь! Где заказы?!": "Jahlim chiqdi! Buyurtmalar qani?!",
    "Аааа! Сколько расхождений?!": "Aaaa! Qancha farq?!",
    "ЧТО ЗА ХАОС?!": "BU NIMA CHALKASHLIK?!",
    "Это провал… (х_х)": "Bu muvaffaqiyatsizlik… (x_x)",
    "Полный разгром — всё заново": "To‘liq mag‘lubiyat — hammasini qaytadan",
    "Жду данные… zzz": "Ma’lumot kutyapman… zzz",
    "Загрузи список — разбужу": "Ro‘yxatni yuklang — uyg‘otaman",
    "Пусто… zzz": "Bo‘m-bo‘sh… zzz",
}
_UZ_MISC = {
    "Шапка отчёта: инвентаризация ПВЗ": "Hisobot sarlavhasi: PYZ inventarizatsiyasi",
    "Инвентаризация ПВЗ": "PYZ inventarizatsiyasi",
    "ИСХОДНЫЙ СТАТУС": "ASL STATUS", "№ ПРОБЛЕМЫ": "MUAMMO №",
    "ВКЛ": "YOQ", "ВЫКЛ": "O‘CHIQ",
    "ячейка": "katak", "минута": "daqiqa",
}
_UZ_MAP_CACHE = None


def _uz_map() -> dict:
    """Русское слово -> узбекское. Статусы берутся из LEGEND (одно место правды с подписями в отчёте)."""
    global _UZ_MAP_CACHE
    if _UZ_MAP_CACHE is None:
        m = {}
        for (_, ru_name, _), (_, uz_name, _) in zip(LEGEND["ru"]["rows"], LEGEND["uz"]["rows"]):
            m[ru_name] = uz_name
        m.update(_UZ_SHEETS)
        m.update(_UZ_MOODS)
        m.update(_UZ_MISC)
        for k, v in list(_UZ_MOODS.items()):       # в формуле UPPER(...) настроение попадает в кэш заглавными
            m[k.upper()] = v.upper()
        _UZ_MAP_CACHE = sorted(m.items(), key=lambda kv: -len(kv[0]))     # длинные фразы раньше коротких
    return _UZ_MAP_CACHE


def _xml_charrefs(s: str) -> str:
    """Не-ASCII символы -> десятичные XML-коды (&#1053;), как их пишет lxml."""
    return "".join(ch if ord(ch) < 128 else f"&#{ord(ch)};" for ch in s)


def localize_xlsx(data: bytes, language: str) -> bytes:
    """Для language='uz' заменяет русские слова узбекскими во всех частях xlsx. Для остальных — не трогает.
    Любая неудача -> возвращаем исходный файл (лучше русский отчёт, чем никакого)."""
    if language != "uz":
        return data
    try:
        pairs = _uz_map()
        out = io.BytesIO()
        with zipfile.ZipFile(io.BytesIO(data)) as zin, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                raw = zin.read(item.filename)
                if item.filename.endswith((".xml", ".rels")):
                    text = raw.decode("utf-8")
                    for ru, uz in pairs:
                        if ru in text:
                            text = text.replace(ru, uz)
                        # ФИКС: если на ПК установлен lxml, openpyxl пишет кириллицу XML-кодами (&#1053;&#1077;…), и
                        # простая замена текста их не видела — в узбекском отчёте оставались «Недостача», «Излишек»,
                        # «Верная ячейка» (так и было в FRtash247_08.11.2026). Меняем и закодированную форму —
                        # тоже кодами, чтобы файл оставался валидным при любой кодировке в заголовке XML.
                        ru_ent = _xml_charrefs(ru)
                        if ru_ent != ru and ru_ent in text:
                            text = text.replace(ru_ent, _xml_charrefs(uz))
                    raw = text.encode("utf-8")
                zout.writestr(item, raw)
        res = out.getvalue()
        with zipfile.ZipFile(io.BytesIO(res)) as chk:
            if chk.testzip() is not None or "xl/workbook.xml" not in chk.namelist():
                return data
        return res
    except Exception:
        return data


# ============================================================
#  ГЛАВНАЯ ФУНКЦИЯ
# ============================================================
def build_report_xlsx(profile: dict, report: dict, full_rows: list[dict], timestamp: str, language: str = 'ru',
                      _cache: bool = True) -> bytes:
    """Живой отчёт: «Сводка», «Инвентаризация», «Проблемы» (+ скрытый служебный «_данные»).
    Всё считается формулами от листа «Инвентаризация»; значения формул дополнительно кэшируются в файле."""
    from openpyxl.workbook.properties import CalcProperties
    from . import live_report

    language = language if language in T else 'ru'
    tx = T[language]
    wb = Workbook()
    wb.properties.title = "Uzum Market — Инвентаризация ПВЗ"
    wb.properties.creator = "UZUM INVENT · by DAMIR"

    ws_sum = wb.active
    ws_sum.title = SUM_SHEET
    ws_data = wb.create_sheet(DATA_SHEET)
    ws_prob = wb.create_sheet(PROB_SHEET)
    ws_com = wb.create_sheet(COMMENTS_SHEET)
    ws_calc = wb.create_sheet(live_report.CALC)
    for ws in (ws_sum, ws_data, ws_prob):
        ws.sheet_properties.tabColor = NEON
        _page_setup(ws)
    ws_prob.sheet_properties.tabColor = _hex(rk.C_PINK)
    ws_com.sheet_properties.tabColor = _hex(rk.C_AMBER)
    _page_setup(ws_com)

    ident = {"pvz": profile.get('pvz', '—'), "admin_name": profile.get('admin_name', '—'),
             "tabel_number": profile.get('tabel_number', '—')}
    cache: dict = {}
    data_last, data_end, written = _build_data_sheet(ws_data, tx, full_rows, ident, timestamp, language, cache)
    ctx = {"rows": full_rows, "tx": tx, "language": language, "cache": cache, "written": written,
           "first": FIRST_DATA_ROW, "end": data_end, "ident": ident, "timestamp": timestamp, "ws_calc": ws_calc}
    live_report.build_live_sheets(wb, ws_sum, ws_prob, ws_calc, ctx)
    com_last = None
    try:
        from . import comments_sheet
        com_last = comments_sheet.build(
            ws_com, full_rows, ident, timestamp, language, cache,
            nav={"summary": (SUM_SHEET, "A1"), "problems": (PROB_SHEET, "A1"), "table": (DATA_SHEET, f"B{FIRST_DATA_ROW}")})
    except Exception:
        import logging
        logging.getLogger(__name__).exception("Лист «Комменты» не собрался — отчёт отправится без него")
        wb.remove(ws_com)
    wb.calculation = CalcProperties(fullCalcOnLoad=True)     # Excel пересчитает всё при открытии

    buf = io.BytesIO()
    wb.save(buf)
    names = wb.sheetnames
    data = _inject_ignored_errors(buf.getvalue(), {
        names.index(DATA_SHEET) + 1: f"B{FIRST_DATA_ROW}:N{data_end}",
        names.index(PROB_SHEET) + 1: f"B1:J{ctx['prob_last']}",
        **({names.index(COMMENTS_SHEET) + 1: f"B1:H{com_last}"} if com_last else {}),
    })
    if _cache:
        data = live_report.inject_caches(data, names, cache)
    return localize_xlsx(data, language)


def build_report_xlsx_simple(profile: dict, report: dict, full_rows: list[dict], timestamp: str, language: str = 'ru') -> bytes:
    """Запасной простой отчёт без картинок и шрифтов: бот шлёт его, если красивая версия не собралась,
    чтобы сотрудник в любом случае получил таблицу."""
    tx = T.get(language, T['ru'])
    wb = Workbook()
    ws = wb.active
    ws.title = "Инвентаризация"
    h = tx["hdr"]
    ws.append([h["no"], h["order"], h["wms_cell"], h["pu"], h["scan_cell"], h["time"], h["status"]])
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for i, r in enumerate(full_rows, start=1):
        scanned = _is_scanned(r)
        dt = _parse_dt(r.get("scanned_at")) if scanned else None
        ws.append([i, r["wms_id"], r.get("expected_cell") or "", (r.get("full_code") or "") if scanned else "",
                   (r.get("scanned_cell") or "") if scanned else "", dt.strftime("%H:%M:%S") if dt else "", r["status"]])
    for letter, w in zip("ABCDEFG", (6, 16, 14, 24, 16, 10, 20)):
        ws.column_dimensions[letter].width = w
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:G{max(len(full_rows) + 1, 2)}"
    buf = io.BytesIO()
    wb.save(buf)
    return localize_xlsx(buf.getvalue(), language)
