"""
Глаза-талисман для «живой» Сводки: круглые, с блеском, бровями и «шторками» — как на карточке-талисмане старой сводки.

Рисуются ВЕКТОРНОЙ диаграммой Excel (scatter): маркеры-круги (белок, радужка, зрачок, блик), «шторки» цвета карточки
(квадрат/круг-маркер закрывает верх или низ глаза — злые, сонные, грустные глаза), брови — ряд точек-кружков,
толстые линии с округлыми концами — только закрытые глаза-дуги и слёзы. Все координаты берутся ФОРМУЛАМИ из таблицы
кадров, поэтому мимика меняется вместе с результатами инвентаризации и «оживает» при каждом пересчёте.

Настроение: 10 диапазонов «чистоты» × 3 варианта = 30 выражений; у каждого 6 кадров:
взгляд прямо / влево / вправо / вверх / вниз и моргание.
"""
import math

XMAX, YMAX = 100.0, 50.0                 # система координат диаграммы (аспект 2:1)
CENTERS = ((32.0, 22.0), (68.0, 22.0))   # левый и правый глаз
R = 11.4                                 # радиус белка (маркер 72 pt при диаграмме 420×210 px)
LOOKS = [(0, 0), (-1, 0), (1, 0), (0, 1), (0, -1), None]     # None = моргание

CARD_BG = "0C0518"
LAV = "C7A6FF"
WHITE = "F4F0FF"

NB = 11                                  # точек в брови (кружки-маркеры, перекрываются в плавный штрих)

# имя серии, число точек, вид: m — маркеры, l — линия
# ВАЖНО: всё, что должно перекрывать другое (радужка, «шторки», брови), — МАРКЕРЫ: Excel рисует ряды-маркеры по порядку
# рядов, а линии — отдельным слоем под ними, поэтому линиями сделаны только закрытые глаза-дуги и слёзы (ничего не перекрывают).
SERIES = [
    ("sclera", 2, "m"), ("ring1", 2, "m"), ("ring1b", 2, "m"), ("ring2", 2, "m"), ("ring2b", 2, "m"), ("ringdot", 2, "m"),
    ("iris_s", 2, "m"), ("iris_m", 2, "m"), ("iris_l", 2, "m"),
    ("pupil_s", 2, "m"), ("pupil_m", 2, "m"), ("pupil_l", 2, "m"), ("hi", 2, "m"), ("hi2", 2, "m"),
    ("cov_sq", 2, "m"), ("cov_c", 2, "m"),
    ("closed_0", 5, "l"), ("closed_1", 5, "l"),
    ("star", 2, "m"), ("starhi", 2, "m"), ("heart_lobe", 4, "m"), ("heart_tip", 2, "m"), ("xmark", 2, "m"),
    ("brow_0", NB, "m"), ("brow_1", NB, "m"), ("browr_0", NB, "m"), ("browr_1", NB, "m"),
    ("tear_0", 2, "l"), ("tear_1", 2, "l"), ("sweat_c", 1, "m"), ("sweat_t", 1, "m"), ("blush", 2, "m"),
    ("steam", 1, "m"), ("sparkle", 3, "m"),
    ("conf_star", 3, "m"), ("conf_dia", 3, "m"), ("conf_circ", 3, "m"), ("conf_tri", 3, "m"),
    ("z1", 1, "m"), ("z2", 1, "m"), ("z3", 1, "m"),
]
# оформление серий (диаметры маркеров — в пунктах, толщины линий — в пунктах)
STYLE = {
    "sclera": dict(sym="circle", size=72, fill=WHITE, line="D9CCFF", lw=1),
    "ring1": dict(sym="circle", size=58, fill="9D4DFF", line="9D4DFF", lw=1),
    "ring1b": dict(sym="circle", size=47, fill=WHITE, line=WHITE, lw=1),
    "ring2": dict(sym="circle", size=36, fill="9D4DFF", line="9D4DFF", lw=1),
    "ring2b": dict(sym="circle", size=24, fill=WHITE, line=WHITE, lw=1),
    "ringdot": dict(sym="circle", size=11, fill="9D4DFF", line="9D4DFF", lw=1),
    "iris_s": dict(sym="circle", size=27, fill="5A25C8", line="9D4DFF", lw=1.5),
    "iris_m": dict(sym="circle", size=41, fill="5A25C8", line="9D4DFF", lw=1.5),
    "iris_l": dict(sym="circle", size=52, fill="5A25C8", line="9D4DFF", lw=1.5),
    "pupil_s": dict(sym="circle", size=11, fill="140832", line="140832", lw=1),
    "pupil_m": dict(sym="circle", size=23, fill="140832", line="140832", lw=1),
    "pupil_l": dict(sym="circle", size=33, fill="140832", line="140832", lw=1),
    "hi": dict(sym="circle", size=10, fill="FFFFFF", line="FFFFFF", lw=0.5),
    "hi2": dict(sym="circle", size=5, fill="FFFFFF", line="FFFFFF", lw=0.5),
    "cov_sq": dict(sym="square", size=72, fill=CARD_BG, line=CARD_BG, lw=0.5),
    "cov_c": dict(sym="circle", size=72, fill=CARD_BG, line=CARD_BG, lw=0.5),
    "closed_0": dict(w=7, color=WHITE, cap="rnd", smooth=True), "closed_1": dict(w=7, color=WHITE, cap="rnd", smooth=True),
    "star": dict(sym="star", size=58, fill="FFD23F", line="FFF1A8", lw=1.5),
    "starhi": dict(sym="circle", size=9, fill="FFFFFF", line="FFFFFF", lw=0.5),
    "heart_lobe": dict(sym="circle", size=36, fill="FF5CA8", line="FF5CA8", lw=1),
    "heart_tip": dict(sym="diamond", size=46, fill="FF5CA8", line="FF5CA8", lw=1),
    "xmark": dict(sym="x", size=46, fill=None, line="FF3B30", lw=7),
    "brow_0": dict(sym="circle", size=9, fill=LAV, line=LAV, lw=0.5), "brow_1": dict(sym="circle", size=9, fill=LAV, line=LAV, lw=0.5),
    "browr_0": dict(sym="circle", size=9, fill="FF3B30", line="FF3B30", lw=0.5),
    "browr_1": dict(sym="circle", size=9, fill="FF3B30", line="FF3B30", lw=0.5),
    "tear_0": dict(w=10, color="5CC8FF", cap="rnd"), "tear_1": dict(w=10, color="5CC8FF", cap="rnd"),
    "sweat_c": dict(sym="circle", size=15, fill="5CC8FF", line="5CC8FF", lw=1),
    "sweat_t": dict(sym="triangle", size=11, fill="5CC8FF", line="5CC8FF", lw=1),
    "blush": dict(sym="circle", size=32, fill="B83A74", line="B83A74", lw=1),
    "steam": dict(sym="x", size=24, fill=None, line="FF3B30", lw=4.5),
    "sparkle": dict(sym="star", size=19, fill="FFD23F", line="FFD23F", lw=1),
    "conf_star": dict(sym="star", size=13, fill="FFD23F", line="FFD23F", lw=1),
    "conf_dia": dict(sym="diamond", size=10, fill="FF5CA8", line="FF5CA8", lw=1),
    "conf_circ": dict(sym="circle", size=8, fill="34C77B", line="34C77B", lw=1),
    "conf_tri": dict(sym="triangle", size=10, fill="5CC8FF", line="5CC8FF", lw=1),
    "z1": dict(label="z", lsize=13), "z2": dict(label="Z", lsize=17), "z3": dict(label="Z", lsize=22),
}
SERIES_INDEX = {n: i for i, (n, _k, _m) in enumerate(SERIES)}

# (название, фраза, описание рисунка)
def _mk(kl, kr=None, size="m", lid=None, bl=None, br="=", ex=(), bk="line", off=(0.0, 0.0)):
    return dict(kl=kl, kr=kr or kl, size=size, lid=lid, bl=bl, br=bl if br == "=" else br, ex=ex, bk=bk, off=off)


BANDS = [
    ("чисто, без ошибок", [
        ("Звёздные глаза", "ИДЕАЛЬНО! Все заказы на своих местах", _mk("star", ex=("sparkle", "confetti"), bk="arc_up")),
        ("Влюблён в порядок", "Ни одной ошибки — это любовь!", _mk("heart", ex=("blush", "confetti"), bk="arc_up")),
        ("В полном восторге", "Легенда ПВЗ! Хоть в рамку вешай", _mk("arc_up", bl="high", ex=("sparkle", "confetti"), bk="arc_up")),
    ]),
    ("чистота ≥ 98%", [
        ("Сияет", "Почти идеал — красавчик!", _mk("open", size="l", bl="high", ex=("blush",), bk="arc_up")),
        ("Подмигивает", "Чётко сработано, так держать!", _mk("open", kr="arc_up", bl="high", br="high", ex=("blush",), bk="arc_dn")),
        ("Довольный", "Огонь! Заказы на своих местах", _mk("open", lid="cheek", bl="high", ex=("blush",), bk="arc_up")),
    ]),
    ("чистота ≥ 95%", [
        ("Радуется", "Отличный результат!", _mk("open", bl="high", bk="arc_dn")),
        ("Улыбается", "Хорошая работа, остались мелочи", _mk("arc_dn", bl="flat", ex=("blush",), bk="arc_dn")),
        ("Доволен", "Почти всё сошлось", _mk("open", lid="cheek", bk="arc_dn")),
    ]),
    ("чистота ≥ 90%", [
        ("Спокоен", "Нормально, но можно лучше", _mk("open", bl="flat")),
        ("Расслаблен", "Неплохо — перепроверь пару заказов", _mk("open", lid="half", bl="flat", bk="line")),
        ("Задумался", "Хм… есть что поправить", _mk("open", bl="high", br="flat", off=(1.5, 0.8))),
    ]),
    ("чистота ≥ 85% (нейтрально)", [
        ("Нейтральный", "Среднячок… можно и лучше", _mk("open", bl="flat")),
        ("Смотрит в упор", "Ни рыба ни мясо", _mk("open", size="s")),
        ("Скучает", "Ну такое себе…", _mk("open", lid="half", bl="flat", off=(0.0, -0.8))),
    ]),
    ("чистота ≥ 80%", [
        ("Нервничает", "Что-то тут не так…", _mk("open", bl="sad", ex=("sweat",), off=(-1.5, -0.8))),
        ("Косится", "Пахнет перепроверкой", _mk("open", lid="half", bl="high", br="flat", off=(2.5, 0.0))),
        ("Напряжён", "Хмм, подозрительно много расхождений", _mk("open", size="s", bl="sad", ex=("sweat",))),
    ]),
    ("чистота ≥ 70%", [
        ("Грустит", "Грустно… часть заказов потерялась", _mk("open", size="l", lid="sad", bl="sad", ex=("tear_one",), off=(0.0, -1.0))),
        ("Расстроен", "Эх, надо искать заказы", _mk("open", size="l", bl="sad", ex=("tear_o",), off=(0.0, -1.2))),
        ("Переживает", "Много расхождений — проверь ячейки", _mk("open", lid="sad", bl="sad", ex=("sweat",), off=(-1.0, -1.0))),
    ]),
    ("чистота ≥ 55%", [
        ("Плачет", "Ууу… столько косяков", _mk("open", size="l", lid="sad", bl="sad", ex=("tear_o",), bk="line", off=(0.0, -1.2))),
        ("Злится", "Злюсь! Где заказы?!", _mk("open", lid="angry", bl="angry", ex=("steam",), off=(0.0, -1.2))),
        ("В шоке", "Аааа! Сколько расхождений?!", _mk("open", size="s", bl="high", ex=("sweat",))),
    ]),
    ("чистота < 55%", [
        ("В ярости", "ЧТО ЗА ХАОС?!", _mk("open", size="s", lid="angry", bl="angry", ex=("steam", "sweat"), off=(0.0, -1.5))),
        ("Сломался", "Это провал… (х_х)", _mk("x", ex=("steam",), bk="x")),
        ("Голова кружится", "Полный разгром — всё заново", _mk("ring", ex=("sweat",), bk="ring")),
    ]),
    ("данных ещё нет", [
        ("Спит", "Жду данные… zzz", _mk("arc_dn", ex=("zzz",), bk="line")),
        ("Дремлет", "Загрузи список — разбужу", _mk("open", lid="half", ex=("zzz",), bk="line", off=(0.0, -1.0))),
        ("Клюёт носом", "Пусто… zzz", _mk("line", ex=("zzz",), bk="line")),
    ]),
]


def band_of(total, clean, effr):
    """Номер диапазона 1..10 (effr — «чистота» в процентах, округлённая до 0,1; то же правило, что формула в Excel)."""
    if total <= 0:
        return 10
    if clean:
        return 1
    for b, lim in ((2, 98), (3, 95), (4, 90), (5, 85), (6, 80), (7, 70), (8, 55)):
        if effr >= lim:
            return b
    return 9


# ------------------------------------------------------------------ геометрия кадров
_IRIS_R = {"s": 4.15, "m": 6.35, "l": 7.9}
COV_R = 11.45                            # половина стороны/радиус «шторки» (маркер 72 pt)


def _brow_pts(kind, side, cx, cy):
    yb = cy + R + 5.0
    us = tuple(round(-1.0 + 2.0 * i / (NB - 1), 3) for i in range(NB))
    pts = []
    for u in us:
        x = cx + (8.2 * u if side == 0 else -8.2 * u)
        arch = 1.0 - u * u
        if kind == "flat":
            y = yb + 0.9 * arch
        elif kind == "high":
            y = yb + 2.3 + 2.0 * arch
        elif kind in ("sad", "worry"):
            y = yb + 1.2 + 2.9 * u + 0.5 * arch
        elif kind == "angry":
            y = yb - 1.6 - 2.9 * u + 0.5 * arch
        else:
            y = yb
        pts.append((round(x, 2), round(y, 2)))
    return pts


def _closed_pts(kind, cx, cy):
    xs = (-9.0, -4.5, 0.0, 4.5, 9.0)
    if kind == "arc_up":
        ys = (-3.2, 2.0, 4.0, 2.0, -3.2)
    elif kind == "arc_dn":
        ys = (2.6, -1.6, -3.4, -1.6, 2.6)
    else:
        ys = (0.0, 0.0, 0.0, 0.0, 0.0)
    return [(round(cx + x, 2), round(cy + y, 2)) for x, y in zip(xs, ys)]


def frame(spec, look):
    """Кадр: {имя серии: [точки (x, y) или None]}."""
    pts = {n: [None] * k for n, k, _m in SERIES}
    blink = look is None
    for side, (cx, cy) in enumerate(CENTERS):
        kind = spec["bk"] if blink else (spec["kl"] if side == 0 else spec["kr"])
        if kind == "open":
            pts["sclera"][side] = (cx, cy)
            sz = spec["size"]
            r_i = _IRIS_R[sz]
            maxd = min(R - r_i - 0.7, 4.6)
            lx, ly = look if look else (0, 0)
            ox, oy = spec["off"]
            ix = max(-maxd, min(maxd, ox + lx * maxd))
            iy = max(-maxd, min(maxd, oy + ly * maxd * 0.75))
            ix, iy = round(cx + ix, 2), round(cy + iy, 2)
            pts[f"iris_{sz}"][side] = (ix, iy)
            pts[f"pupil_{sz}"][side] = (ix, iy)
            k = r_i / 6.35
            pts["hi"][side] = (round(ix - 2.0 * k, 2), round(iy + 2.4 * k, 2))
            pts["hi2"][side] = (round(ix + 1.9 * k, 2), round(iy - 2.0 * k, 2))
            lid = spec["lid"]
            inner = 1.0 if side == 0 else -1.0           # куда смотрит переносица: левый глаз — вправо, правый — влево
            if lid == "half":
                pts["cov_sq"][side] = (cx, round(cy + 1.2 + COV_R, 2))
            elif lid == "angry":
                pts["cov_c"][side] = (round(cx + inner * 7.0, 2), round(cy + 12.6, 2))
            elif lid == "sad":
                pts["cov_c"][side] = (round(cx - inner * 7.0, 2), round(cy + 12.6, 2))
            elif lid == "cheek":
                pts["cov_sq"][side] = (cx, round(cy - 5.2 - COV_R, 2))
        elif kind in ("arc_up", "arc_dn", "line"):
            pts[f"closed_{side}"] = _closed_pts(kind, cx, cy)
        elif kind == "star":
            pts["star"][side] = (cx, cy)
            pts["starhi"][side] = (cx, cy)
        elif kind == "heart":
            pts["heart_lobe"][2 * side] = (cx - 4.4, cy + 2.6)
            pts["heart_lobe"][2 * side + 1] = (cx + 4.4, cy + 2.6)
            pts["heart_tip"][side] = (cx, cy - 1.2)
        elif kind == "x":
            pts["xmark"][side] = (cx, cy)
        elif kind == "ring":
            pts["sclera"][side] = (cx, cy)
            pts["ring1"][side] = (cx, cy)
            pts["ring1b"][side] = (cx, cy)
            pts["ring2"][side] = (cx, cy)
            pts["ring2b"][side] = (cx, cy)
            pts["ringdot"][side] = (cx, cy)
        # брови
        bt = spec["bl"] if side == 0 else spec["br"]
        if bt:
            name = ("browr_" if bt == "angry" else "brow_") + str(side)
            pts[name] = _brow_pts(bt, side, cx, cy)
    ex = spec["ex"]
    if "tear_o" in ex or "tear_one" in ex:
        for side, (cx, cy) in enumerate(CENTERS):
            if side == 1 and "tear_one" in ex:
                continue
            x = cx - 5.4 if side == 0 else cx + 5.4
            pts[f"tear_{side}"] = [(round(x, 2), round(cy - R - 0.6, 2)), (round(x, 2), round(cy - R - 7.0, 2))]
    if "sweat" in ex:
        pts["sweat_c"][0] = (91.0, 36.5)
        pts["sweat_t"][0] = (91.0, 41.6)
    if "blush" in ex:
        pts["blush"][0] = (CENTERS[0][0] - 14.0, CENTERS[0][1] - 9.0)
        pts["blush"][1] = (CENTERS[1][0] + 14.0, CENTERS[1][1] - 9.0)
    if "steam" in ex:
        pts["steam"][0] = (50.0, 38.0)
    if "sparkle" in ex:
        pts["sparkle"] = [(8.0, 40.0), (92.0, 41.0), (50.0, 44.0)]
    if "confetti" in ex:
        pts["conf_star"] = [(15.0, 46.0), (85.0, 47.0), (24.0, 5.0)]
        pts["conf_dia"] = [(5.0, 24.0), (95.0, 25.0), (62.0, 5.0)]
        pts["conf_circ"] = [(38.0, 47.5), (80.0, 5.0), (12.0, 9.0)]
        pts["conf_tri"] = [(94.0, 12.0), (31.0, 45.0), (50.0, 2.5)]
    if "zzz" in ex:
        pts["z1"][0], pts["z2"][0], pts["z3"][0] = (76.0, 37.0), (83.0, 42.0), (91.0, 47.0)
    return pts


def build_frames():
    """-> (frames, fmap, names, phrases)
    frames[i] — кадр (см. frame); fmap[pattern-1][look-1] — номер кадра (с 1); pattern = (диапазон-1)*3 + вариант."""
    frames, seen, fmap, names, phrases = [], {}, [], [], []
    for _label, variants in BANDS:
        for name, phrase, spec in variants:
            names.append(name)
            phrases.append(phrase)
            row = []
            for look in LOOKS:
                fr = frame(spec, look)
                key = tuple((n, tuple(p)) for n, p in fr.items())
                if key not in seen:
                    frames.append(fr)
                    seen[key] = len(frames)
                row.append(seen[key])
            fmap.append(row)
    return frames, fmap, names, phrases


def layout():
    """Колонки строки-кадра: {серия: смещение}; у серии сначала n значений X, затем n значений Y."""
    off, pos = {}, 0
    for n, k, _m in SERIES:
        off[n] = pos
        pos += 2 * k
    return off, pos
