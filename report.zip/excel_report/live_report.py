"""
«Живые» листы отчёта: «Сводка», «Проблемы» и служебный «_данные».

Всё считается ФОРМУЛАМИ от листа «Инвентаризация»: поменял статус строки (выпадающий список), вписал PU-код и
ячейку — сводка, кольцо-диаграмма, график ритма, ранг, достижения, карта ячеек, глаза и список проблем
пересчитываются сами. Никаких картинок-«скринов»: числа — ячейки, кольцо и ритм — настоящие диаграммы Excel,
цвета — условное форматирование, глаза — пиксель-арт из ячеек (кадр выбирает формула, при каждом пересчёте
глаза «оживают»: смотрят в стороны и моргают; выключатель — в правом верхнем углу «Сводки»).

Для просмотрщиков без пересчёта (защищённый просмотр, превью) в файл дополнительно записываются
КЭШИРОВАННЫЕ значения всех формул (их считает зеркальная Python-модель, тесты сверяют её с пересчётом LibreOffice).
"""
import io
import math
import re
import zipfile
from collections import Counter

from openpyxl.cell.rich_text import CellRichText, TextBlock
from openpyxl.cell.text import InlineFont
from openpyxl.chart import BarChart, DoughnutChart, Reference, ScatterChart, Series
from openpyxl.chart.label import DataLabelList
from openpyxl.chart.marker import Marker
from openpyxl.chart.layout import Layout, ManualLayout
from openpyxl.chart.series import DataPoint
from openpyxl.chart.shapes import GraphicalProperties
from openpyxl.chart.text import RichText
from openpyxl.drawing.line import LineProperties
from openpyxl.drawing.spreadsheet_drawing import AnchorMarker, OneCellAnchor
from openpyxl.drawing.text import CharacterProperties, Paragraph, ParagraphProperties
from openpyxl.drawing.text import Font as DFont
from openpyxl.drawing.xdr import XDRPositiveSize2D
from openpyxl.formatting.rule import CellIsRule, Rule
from openpyxl.styles import Alignment, Border, Font, Side
from openpyxl.styles.differential import DifferentialStyle
from openpyxl.utils import get_column_letter as CL
from openpyxl.utils.units import pixels_to_EMU
from openpyxl.worksheet.datavalidation import DataValidation

from . import dashboard_render, eyes
from . import render_kit as rk
from .xlsx_report import (
    ASSETS_DIR, BG, DATA_SHEET, EXTRA_ROWS, FILL_A, FILL_B, FILL_BG, FILL_HEAD, FIRST_DATA_ROW, FONT_NAME, HEAD_BG,
    LEGEND, LINE, NEON, NEON_SOFT, OK_STATUS, PROB_SHEET, ROW_A, ROW_B, SEC_KEY, SEC_ORDER, STATUS_ACCENT,
    STATUS_KEY, SUM_SHEET, TEXT, TEXT_DIM, TEXT_SOFT, T, _asset_bytes, _cell_key, _cell_map, _col_width_to_px,
    _dark_sheet, _fill, _hex, _merge, _mixhex, _nav_chip, _parse_dt, _place_image, _problem_cells, _pu_value,
    note_text,
)

CALC = "_данные"
EYES_SHEET = "_глаза"
EYES_REVERSE = False                                          # тест: LibreOffice рисует ряды в обратном порядке
SWITCH_DEFAULT = "ВКЛ"                                       # в тестах ставим «ВЫКЛ» — детерминированные глаза
ST_OK, ST_WRONG, ST_SUR, ST_DUP, ST_SHORT = "Верная ячейка", "Неверная ячейка", "Излишек", "Задвоенный", "Недостача"
ORDER5 = [ST_OK, ST_WRONG, ST_SUR, ST_DUP, ST_SHORT]       # порядок в кольце / таблице / полосе
G = 59                                                       # ширина сетки «Сводки» в клетках
UNIT_PX = 21
MAX_MAP = 140                                                # максимум плиток на карте ячеек
MAX_CELLS = 400                                              # ячеек в служебной таблице (для топа/карты)
BANDS_COLOR = {"good": "34C77B", "neutral": NEON_SOFT, "warn": "FFB020", "bad": "FF3B30", "none": TEXT_DIM}

LT = {
    "ru": {
        "title": "Инвентаризация ПВЗ",
        "eyes_sw": "ЖИВЫЕ ГЛАЗА", "mood": "НАСТРОЕНИЕ", "ring": "ТОЧНОСТЬ ИНВЕНТАРИЗАЦИИ", "ring_cap": "ТОЧНОСТЬ",
        "found_of": "заказов найдено в верной ячейке", "rank": "РАНГ", "purity": "чистота сканов ",
        "legend": ["Верная", "Неверная", "Излишек", "Задвоенный", "Недостача"],
        "kpi": ["ВСЕГО В СПИСКЕ", "ВЕРНО НАЙДЕНО", "ТРЕБУЮТ ВНИМАНИЯ", "ИСПРАВЛЕНО ВРУЧНУЮ"],
        "kpi_cap": ["заказов по WMS", "от списка", "расхождений", "было недостач: {a} → осталось: {b}"],
        "kpi_cap_ok": "всё сошлось", "of_list": "% от списка",
        "detail": "ПО СТАТУСАМ", "cols": ["СТАТУС", "БЫЛО", "СЕЙЧАС", "ДОЛЯ"], "total_row": "ИТОГО",
        "rhythm": "РИТМ СКАНИРОВАНИЯ", "r_start": "начало ", "no_data": "—", "min": " мин", "hour": " ч ",
        "lt1": "< 1 мин", "spm": " скан/мин",
        "ach": "ДОСТИЖЕНИЯ",
        "ach_names": ["Ноль излишков", "Ничего не потеряно", "Ячейки без путаницы", "Без повторных сканов",
                      "Точность 95% и выше", "Исправлено вручную"],
        "map": "КАРТА ЯЧЕЕК", "map_legend": "зелёная — чисто · жёлтая — 1–2 проблемы · красная — 3 и больше",
        "map_more": "…и ещё {n} ячеек — смотрите таблицу.",
        "footer": "Отчёт живой: меняйте статусы на листе «Инвентаризация» — всё здесь пересчитается само.",
        "k_short": "недостача", "k_wrong": "неверная", "k_sur": "излишек", "k_dup": "задвоенный",
        "cheat": "ШПАРГАЛКА · ЧТО ДЕЛАТЬ С КАЖДЫМ ТИПОМ",
    },
    "uz": {
        "title": "PYZ inventarizatsiyasi",
        "eyes_sw": "JONLI KO‘ZLAR", "mood": "KAYFIYAT", "ring": "INVENTARIZATSIYA ANIQLIGI", "ring_cap": "ANIQLIK",
        "found_of": "ta buyurtma to‘g‘ri katakda topildi", "rank": "DARAJA", "purity": "skanlar tozaligi ",
        "legend": ["To‘g‘ri", "Noto‘g‘ri", "Ortiqcha", "Ikkilangan", "Yetishmovchilik"],
        "kpi": ["RO‘YXATDA JAMI", "TO‘G‘RI TOPILDI", "E’TIBOR TALAB", "QO‘LDA TUZATILDI"],
        "kpi_cap": ["WMS bo‘yicha buyurtma", "ro‘yxatdan", "farqlar", "yetishmovchilik edi: {a} → qoldi: {b}"],
        "kpi_cap_ok": "hammasi mos", "of_list": "% ro‘yxatdan",
        "detail": "STATUSLAR BO‘YICHA", "cols": ["STATUS", "EDI", "HOZIR", "ULUSH"], "total_row": "JAMI",
        "rhythm": "SKANERLASH RITMI", "r_start": "boshlanish ", "no_data": "—", "min": " daq", "hour": " soat ",
        "lt1": "< 1 daq", "spm": " skan/daq",
        "ach": "YUTUQLAR",
        "ach_names": ["Ortiqcha yo‘q", "Hech narsa yo‘qolmadi", "Kataklar chalkashmagan", "Takroriy skan yo‘q",
                      "Aniqlik 95% va undan yuqori", "Qo‘lda tuzatildi"],
        "map": "KATAKLAR XARITASI", "map_legend": "yashil — toza · sariq — 1–2 muammo · qizil — 3 va undan ko‘p",
        "map_more": "…yana {n} ta katak — jadvalga qarang.",
        "footer": "Hisobot jonli: «Инвентаризация» varag‘ida statuslarni o‘zgartiring — bu yerda hammasi o‘zi qayta hisoblanadi.",
        "k_short": "yetishmovchilik", "k_wrong": "noto‘g‘ri", "k_sur": "ortiqcha", "k_dup": "ikkilangan",
        "cheat": "YO‘RIQNOMA · HAR BIR TURI BILAN NIMA QILISH",
    },
}


# ============================================================
#  ХЕЛПЕРЫ
# ============================================================
class XlError(str):
    """Значение-ошибка Excel (#N/A) для кэша формул."""


def xl_round(x, n=0):
    f = 10 ** n
    return math.floor(abs(x) * f + 0.5) / f * (1 if x >= 0 else -1)


def num_text(x):
    """Как Excel превращает число в текст при склейке (без локали): 97.8 -> '97.8', 100.0 -> '100'."""
    if isinstance(x, float) and x == int(x):
        x = int(x)
    return str(x)


def F(size=10, color=TEXT, bold=False, italic=False):
    return Font(name=FONT_NAME, size=size, bold=bold, italic=italic, color=color)


def AL(h="center", v="center", wrap=False, indent=0):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap, indent=indent)


def gc(g):
    """Номер колонки листа для клетки сетки g (1..G); колонка A — служебное поле."""
    return g + 1


def DR(col, first, end):
    return f"'{DATA_SHEET}'!${col}${first}:${col}${end}"


def esc(s):
    return s.replace('"', '""')


def tmpl_formula(template, mapping):
    """'Должен быть в {exp}, но…{places}' -> '"Должен быть в "&$E5&", но…"&expr' (литералы с экранированием)."""
    parts = re.split(r"\{(\w+)\}", template)
    out = []
    for i, p in enumerate(parts):
        if i % 2 == 0:
            if p:
                out.append(f'"{esc(p)}"')
        else:
            out.append(mapping[p])
    return "&".join(out) if out else '""'


def tmpl_value(template, mapping):
    return template.format(**mapping)


class Calc:
    """Служебный лист: имя -> ячейка с формулой + значение для кэша."""

    def __init__(self, ws, cache):
        self.ws, self.cache = ws, cache
        self.row = 1
        self.loc, self.abs, self.val = {}, {}, {}

    def put(self, name, formula, value):
        r = self.row
        self.row += 1
        self.ws.cell(row=r, column=23, value=name)
        self.ws.cell(row=r, column=24, value="=" + formula)
        self.cache[(self.ws.title, f"X{r}")] = value
        self.loc[name], self.abs[name], self.val[name] = f"$X${r}", f"'{self.ws.title}'!$X${r}", value
        return self.abs[name]


def fx(ws, cache, r, c, formula, value, fmt=None):
    cell = ws.cell(row=r, column=c)
    cell.value = "=" + formula
    cache[(ws.title, cell.coordinate)] = value
    if fmt:
        cell.number_format = fmt
    return cell


def cf_expr(ws, rng, formula, *, font=None, fill=None, border=None):
    ws.conditional_formatting.add(rng, Rule(type="expression", formula=[formula],
                                            dxf=DifferentialStyle(font=font, fill=fill, border=border)))


def box(ws, r1, g1, r2, g2, value=None, *, font=None, fill=FILL_A, align=None, border=None, fmt=None):
    tl = _merge(ws, r1, gc(g1), r2, gc(g2), value, font=font, fill=fill, align=align, border=border)
    if fmt:
        tl.number_format = fmt
    return tl


def outline(ws, r1, g1, r2, g2, color, style="thin"):
    side = Side(style=style, color=color)
    for r in range(r1, r2 + 1):
        for g in range(g1, g2 + 1):
            cell = ws.cell(row=r, column=gc(g))
            b = cell.border
            cell.border = Border(left=side if g == g1 else b.left, right=side if g == g2 else b.right,
                                 top=side if r == r1 else b.top, bottom=side if r == r2 else b.bottom)


def fill_area(ws, r1, g1, r2, g2, fill):
    for r in range(r1, r2 + 1):
        for g in range(g1, g2 + 1):
            ws.cell(row=r, column=gc(g)).fill = fill


def txt_props(size, color, bold=False):
    cp = CharacterProperties(sz=int(size * 100), b=bold, solidFill=color, latin=DFont(typeface=FONT_NAME))
    return RichText(p=[Paragraph(pPr=ParagraphProperties(defRPr=cp), endParaRPr=cp)])


def one_cell_anchor(col, row, w_px, h_px, col_off=0, row_off=0):
    return OneCellAnchor(_from=AnchorMarker(col=col - 1, colOff=pixels_to_EMU(col_off), row=row - 1,
                                            rowOff=pixels_to_EMU(row_off)),
                         ext=XDRPositiveSize2D(pixels_to_EMU(int(w_px)), pixels_to_EMU(int(h_px))))


# ============================================================
#  МОДЕЛЬ (Python-зеркало формул — для кэшированных значений и тестов)
# ============================================================
def build_model(written, full_rows):
    cnt = Counter(w["h"] for w in written)
    m = {st: cnt.get(st, 0) for st in ORDER5}
    m["total"] = m[ST_OK] + m[ST_WRONG] + m[ST_SHORT]
    m["allscan"] = m["total"] + m[ST_SUR] + m[ST_DUP]
    m["acc"] = m[ST_OK] / m["total"] if m["total"] else 0.0
    m["accr"] = xl_round(m["acc"] * 100, 1)
    m["prob"] = m[ST_WRONG] + m[ST_SHORT] + m[ST_SUR] + m[ST_DUP]
    m["eff"] = m[ST_OK] / m["allscan"] if m["allscan"] else 0.0
    m["effr"] = xl_round(m["eff"] * 100, 1)
    m["clean"] = 1 if (m["total"] > 0 and m["prob"] == 0) else 0
    if m["total"] == 0:
        m["rank"] = "–"
    elif m["clean"]:
        m["rank"] = "S"
    else:
        a = m["accr"]
        m["rank"] = "A" if a >= 95 else "B" if a >= 90 else "C" if a >= 80 else "D"
    m["band"] = eyes.band_of(m["total"], m["clean"], m["effr"])
    m["was"] = Counter(w["m"] for w in written)
    m["manual"] = sum(1 for w in written if w["m"] and w["h"] != w["m"])
    m["probtotal"] = sum(1 for w in written if w["h"] != OK_STATUS)
    ts = [w["t"] for w in written if w["t"] is not None]
    m["ts"] = ts
    m["tcount"] = len(ts)
    m["tmin"] = min(ts) / 86400 if ts else ""
    m["tmax"] = max(ts) / 86400 if ts else ""
    m["span"] = (max(ts) - min(ts)) / 60 if len(ts) >= 2 else 0
    m["speed"] = xl_round((len(ts) - 1) / m["span"], 1) if (len(ts) >= 2 and m["span"] >= 1) else ""
    # карта/горячие ячейки
    cells = [c for c, _ in _cell_map(full_rows)][:MAX_CELLS]
    m["cells"] = cells

    def count(col, cell, st):
        return sum(1 for w in written if w[col] == cell and w["h"] == st)

    pl, okl = [], []
    for cell in cells:
        pl.append(count("d", cell, ST_SHORT) + count("d", cell, ST_WRONG) + count("f", cell, ST_WRONG) +
                  count("f", cell, ST_SUR) + count("f", cell, ST_DUP))
        okl.append(count("d", cell, ST_OK))
    m["p"], m["okc"] = pl, okl
    m["score"] = [p * 1000 + (1000 - (i + 1)) for i, p in enumerate(pl)]
    m["count_fn"] = count
    return m


# ============================================================
#  ПОСТРОЕНИЕ
# ============================================================
def build_live_sheets(wb, ws_sum, ws_prob, ws_calc, ctx):
    tx, lt = ctx["tx"], LT.get(ctx["language"], LT["ru"])
    cache, written, first, end = ctx["cache"], ctx["written"], ctx["first"], ctx["end"]
    m = build_model(written, ctx["rows"])
    ws_calc.sheet_state = "hidden"
    ws_eyes = wb.create_sheet(EYES_SHEET)
    ws_eyes.sheet_state = "hidden"
    ctx["ws_eyes"] = ws_eyes
    ctx["of_word"] = "/" if ctx["language"] == "uz" else "из"
    c = _build_calc(ws_calc, cache, written, m, ctx)
    _build_summary(ws_sum, c, m, tx, lt, ctx)
    _build_problems(ws_prob, c, m, tx, lt, ctx)


# ---------------- служебный лист ----------------
def _build_eyes_sheet(ws, cache, frames, fid_ref, fid, ctx):
    """Скрытый лист: строка = кадр (координаты всех фигур глаз); под таблицей — «текущий кадр» (его рисует диаграмма)."""
    off, ncol = eyes.layout()
    nf = len(frames)
    for fi, fr in enumerate(frames, start=1):
        for name, k, _kind in eyes.SERIES:
            o = off[name]
            for j, pt in enumerate(fr[name]):
                if pt is None:
                    continue
                ws.cell(row=fi, column=o + j + 1, value=pt[0])
                ws.cell(row=fi, column=o + k + j + 1, value=pt[1])
    ft = f"'{EYES_SHEET}'!$A$1:${CL(ncol)}${nf}"
    br = nf + 3
    cur = {}
    for i, (name, k, _kind) in enumerate(eyes.SERIES):
        cx = 2 * i + 1
        cur[name] = (cx, br)
        for j in range(k):
            r = br + j
            ix = f"INDEX({ft},{fid_ref},{off[name] + j + 1})"
            iy = f"INDEX({ft},{fid_ref},{off[name] + k + j + 1})"
            pt = frames[fid - 1][name][j]
            fx(ws, cache, r, cx, f'IF({iy}="",0,{ix})', 0 if pt is None else pt[0])
            fx(ws, cache, r, cx + 1, f'IF({iy}="",NA(),{iy})', XlError("#N/A") if pt is None else pt[1])
    ctx["eye_cur"] = cur


def _build_calc(ws, cache, written, m, ctx):
    first, end = ctx["first"], ctx["end"]
    c = Calc(ws, cache)
    H, Cc, D, Fc, Gc, M, N = (DR(x, first, end) for x in "HCDFGMN")
    sw = f"'{SUM_SHEET}'!${CL(gc(48))}$1"
    ctx["switch_ref"] = sw

    for st, nm in ((ST_OK, "ok"), (ST_WRONG, "wrong"), (ST_SHORT, "short"), (ST_SUR, "surplus"), (ST_DUP, "dup")):
        c.put(nm, f'COUNTIF({H},"{st}")', m[st])
    L = c.loc
    c.put("total", f"{L['ok']}+{L['wrong']}+{L['short']}", m["total"])
    c.put("allscan", f"{L['total']}+{L['surplus']}+{L['dup']}", m["allscan"])
    c.put("acc", f"IF({L['total']}=0,0,{L['ok']}/{L['total']})", m["acc"])
    c.put("accr", f"ROUND({L['acc']}*100,1)", m["accr"])
    c.put("prob", f"{L['wrong']}+{L['short']}+{L['surplus']}+{L['dup']}", m["prob"])
    c.put("eff", f"IF({L['allscan']}=0,0,{L['ok']}/{L['allscan']})", m["eff"])
    c.put("effr", f"ROUND({L['eff']}*100,1)", m["effr"])
    c.put("clean", f"IF(AND({L['total']}>0,{L['prob']}=0),1,0)", m["clean"])
    c.put("rank", f'IF({L["total"]}=0,"–",IF({L["clean"]}=1,"S",IF({L["accr"]}>=95,"A",IF({L["accr"]}>=90,"B",'
                  f'IF({L["accr"]}>=80,"C","D")))))', m["rank"])
    e = L["effr"]
    c.put("band", f'IF({L["total"]}=0,10,IF({L["clean"]}=1,1,IF({e}>=98,2,IF({e}>=95,3,IF({e}>=90,4,IF({e}>=85,5,'
                  f'IF({e}>=80,6,IF({e}>=70,7,IF({e}>=55,8,9)))))))))', m["band"])
    c.put("live", f'IF({sw}="ВЫКЛ",0,1)', 0 if SWITCH_DEFAULT == "ВЫКЛ" else 1)
    c.put("variant", f'IF({L["live"]}=1,RANDBETWEEN(1,3),1)', 1)
    c.put("look", f'IF({L["live"]}=1,CHOOSE(RANDBETWEEN(1,9),1,1,1,2,3,4,5,6,6),1)', 1)
    c.put("pattern", f'({L["band"]}-1)*3+{L["variant"]}', (m["band"] - 1) * 3 + 1)

    # --- кадры глаз: таблица кадров и «текущий кадр» лежат на скрытом листе _глаза ---
    frames, fmap, names, phrases = eyes.build_frames()
    FM0 = 46
    for pi, row in enumerate(fmap):
        for li, fid_ in enumerate(row):
            ws.cell(row=pi + 1, column=FM0 + li, value=fid_)
        ws.cell(row=pi + 1, column=52, value=phrases[pi])
        ws.cell(row=pi + 1, column=53, value=names[pi])
    fm_rng = f"'{CALC}'!${CL(FM0)}$1:${CL(FM0 + 5)}$30"
    pattern = (m["band"] - 1) * 3 + 1
    fid = fmap[pattern - 1][0]
    c.put("fid", f"INDEX({fm_rng},{L['pattern']},{L['look']})", fid)
    c.put("phrase", f"INDEX('{CALC}'!$AZ$1:$AZ$30,{L['pattern']})", phrases[pattern - 1])
    c.put("moodname", f"INDEX('{CALC}'!$BA$1:$BA$30,{L['pattern']})", names[pattern - 1])
    _build_eyes_sheet(ctx["ws_eyes"], cache, frames, c.abs["fid"], fid, ctx)

    # --- ручные правки ---
    c.put("manual", f'SUMPRODUCT(({Cc}<>"")*({M}<>"")*({H}<>{M}))', m["manual"])
    for st, nm in ((ST_SHORT, "was_short"), (ST_WRONG, "was_wrong"), (ST_SUR, "was_sur"), (ST_DUP, "was_dup"),
                   (ST_OK, "was_ok")):
        c.put(nm, f'COUNTIF({M},"{st}")', m["was"].get(st, 0))
    c.put("probtotal", f"MAX({N})", m["probtotal"])

    # --- время ---
    c.put("tcount", f"COUNT({Gc})", m["tcount"])
    c.put("tmin", f'IF({L["tcount"]}=0,"",MIN({Gc}))', m["tmin"])
    c.put("tmax", f'IF({L["tcount"]}=0,"",MAX({Gc}))', m["tmax"])
    c.put("span", f'IF({L["tcount"]}<2,0,({L["tmax"]}-{L["tmin"]})*1440)', m["span"])
    c.put("speed", f'IF(OR({L["tcount"]}<2,{L["span"]}<1),"",ROUND(({L["tcount"]}-1)/{L["span"]},1))', m["speed"])
    lt = LT.get(ctx["language"], LT["ru"])
    span = m["span"]
    sp_r = int(xl_round(span, 0))
    if m["tcount"] < 2:
        dur = lt["no_data"]
    elif span < 1:
        dur = lt["lt1"]
    elif span < 60:
        dur = f"{sp_r}{lt['min']}"
    else:
        dur = f"{sp_r // 60}{lt['hour']}{sp_r % 60}{lt['min']}"
    c.put("dur", f'IF({L["tcount"]}<2,"{lt["no_data"]}",IF({L["span"]}<1,"{lt["lt1"]}",IF({L["span"]}<60,'
                 f'ROUND({L["span"]},0)&"{lt["min"]}",INT(ROUND({L["span"]},0)/60)&"{lt["hour"]}"&'
                 f'MOD(ROUND({L["span"]},0),60)&"{lt["min"]}")))', dur)
    sp_txt = lt["no_data"] if m["speed"] == "" else "≈" + num_text(m["speed"]) + lt["spm"]
    c.put("speed_txt", f'IF({L["speed"]}="","{lt["no_data"]}","≈"&{L["speed"]}&"{lt["spm"]}")', sp_txt)
    if m["tcount"] < 2:
        rl = lt["no_data"]
    else:
        t0 = int(min(m["ts"]))
        rl = f'{lt["r_start"]}{(t0 // 3600) % 24:02d}:{(t0 // 60) % 60:02d}  ·  {dur}  ·  {sp_txt}'
    c.put("rhythm_line", f'IF({L["tcount"]}<2,"{lt["no_data"]}","{lt["r_start"]}"&RIGHT("0"&HOUR({L["tmin"]}),2)&":"&'
                         f'RIGHT("0"&MINUTE({L["tmin"]}),2)&"  ·  "&{L["dur"]}&"  ·  "&{L["speed_txt"]})', rl)

    # --- достижения ---
    sp = m["speed"]
    ach = [m["total"] > 0 and m[ST_SUR] == 0, m["total"] > 0 and m[ST_SHORT] == 0, m["total"] > 0 and m[ST_WRONG] == 0,
           m["total"] > 0 and m[ST_DUP] == 0, m["total"] > 0 and m["accr"] >= 95, sp != "" and sp >= 10,
           m["manual"] >= 1, m["was"].get(ST_SHORT, 0) > 0 and m[ST_SHORT] == 0]
    af = [f'IF(AND({L["total"]}>0,{L["surplus"]}=0),1,0)', f'IF(AND({L["total"]}>0,{L["short"]}=0),1,0)',
          f'IF(AND({L["total"]}>0,{L["wrong"]}=0),1,0)', f'IF(AND({L["total"]}>0,{L["dup"]}=0),1,0)',
          f'IF(AND({L["total"]}>0,{L["accr"]}>=95),1,0)', f'IF({L["speed"]}="",0,IF({L["speed"]}>=10,1,0))',
          f'IF({L["manual"]}>=1,1,0)', f'IF(AND({L["was_short"]}>0,{L["short"]}=0),1,0)']
    for i, (f_, v_) in enumerate(zip(af, ach), start=1):
        c.put(f"ach{i}", f_, 1 if v_ else 0)

    # --- таблица ячеек (карта + топ) ---
    cells = m["cells"]
    ws.cell(row=1, column=26, value="№")
    ws.cell(row=1, column=27, value="ячейка")
    for i, cell in enumerate(cells):
        r = i + 2
        cr = f"$AA{r}"
        ws.cell(row=r, column=26, value=i + 1)
        ws.cell(row=r, column=27, value=cell)

        def cnt(col, st):
            return f'COUNTIFS({col},{cr},{H},"{st}")'
        pf = "+".join([cnt(D, ST_SHORT), cnt(D, ST_WRONG), cnt(Fc, ST_WRONG), cnt(Fc, ST_SUR), cnt(Fc, ST_DUP)])
        fx(ws, cache, r, 28, pf, m["p"][i])
        fx(ws, cache, r, 29, cnt(D, ST_OK), m["okc"][i])
        fx(ws, cache, r, 30, f"AB{r}*1000+(1000-Z{r})", m["score"][i])
    last_c = max(len(cells), 1) + 1
    sc_rng = f"$AD$2:$AD${last_c}"
    names_rng = f"$AA$2:$AA${last_c}"
    ctx["cell_rows"] = {cell: i + 2 for i, cell in enumerate(cells)}
    ranked = sorted(range(len(cells)), key=lambda i: -m["score"][i])
    top = []
    for k in range(1, 6):
        r = k + 1
        ws.cell(row=r, column=32, value=k)
        idx = ranked[k - 1] if k <= len(ranked) else None
        p = m["p"][idx] if idx is not None else 0
        sc = m["score"][idx] if idx is not None else 0
        nm = cells[idx] if (idx is not None and p > 0) else ""
        fx(ws, cache, r, 33, f'IF(AH{r}=0,"",INDEX({names_rng},1000-MOD(IFERROR(LARGE({sc_rng},AF{r}),0),1000)))', nm)
        fx(ws, cache, r, 34, f'INT(IFERROR(LARGE({sc_rng},AF{r}),0)/1000)', p)
        parts = {}
        for col, key, fml, val in (
                (35, "ks", f'COUNTIFS({D},$AG{r},{H},"{ST_SHORT}")', None),
                (36, "kw", f'COUNTIFS({D},$AG{r},{H},"{ST_WRONG}")+COUNTIFS({Fc},$AG{r},{H},"{ST_WRONG}")', None),
                (37, "ku", f'COUNTIFS({Fc},$AG{r},{H},"{ST_SUR}")', None),
                (38, "kd", f'COUNTIFS({Fc},$AG{r},{H},"{ST_DUP}")', None)):
            if nm:
                cf_ = m["count_fn"]
                v = {"ks": cf_("d", nm, ST_SHORT), "kw": cf_("d", nm, ST_WRONG) + cf_("f", nm, ST_WRONG),
                     "ku": cf_("f", nm, ST_SUR), "kd": cf_("f", nm, ST_DUP)}[key]
            else:
                v = 0
            parts[key] = v
            fx(ws, cache, r, col, f'IF($AG{r}="",0,{fml})', v)
        lt_ = LT.get(ctx["language"], LT["ru"])
        pieces = []
        for key, lab in (("ks", "k_short"), ("kw", "k_wrong"), ("ku", "k_sur"), ("kd", "k_dup")):
            if parts[key]:
                pieces.append(f"{lt_[lab]} {parts[key]}")
        fml = "MID(" + "&".join(
            f'IF({col}{r}>0," · {lt_[lab]} "&{col}{r},"")' for col, lab in
            (("AI", "k_short"), ("AJ", "k_wrong"), ("AK", "k_sur"), ("AL", "k_dup"))) + ",4,200)"
        fx(ws, cache, r, 39, fml, " · ".join(pieces) if nm else "")
        top.append((nm, p, parts))
    m["top"] = top
    ctx["top_refs"] = {k: {"name": f"'{CALC}'!$AG${k + 1}", "p": f"'{CALC}'!$AH${k + 1}", "txt": f"'{CALC}'!$AM${k + 1}"}
                       for k in range(1, 6)}

    # --- «эквалайзер»: сканы по минутам ---
    ts = m["ts"]
    if ts:
        fm = min(ts) // 60
        n_min = max(ts) // 60 - fm + 1
        step = -(-n_min // 48) if n_min > 48 else 1
        nb = -(-n_min // step)
    else:
        fm, step, nb = 0, 1, 1
    ws.cell(row=1, column=41, value="минута")
    for j in range(nb):
        r = j + 2
        s_sec = (fm + j * step) * 60
        e_sec = s_sec + step * 60
        ws.cell(row=r, column=41, value=("—" if not ts else f"{(s_sec // 3600) % 24:02d}:{(s_sec // 60) % 60:02d}"))
        ws.cell(row=r, column=42, value=s_sec / 86400)
        ws.cell(row=r, column=43, value=e_sec / 86400)
        val = sum(1 for t in ts if s_sec <= t < e_sec)
        fx(ws, cache, r, 44, f"SUMPRODUCT(--ISNUMBER({Gc}),--({Gc}>=AP{r}-1/172800),--({Gc}<AQ{r}-1/172800))", val)
    ctx["eq"] = {"first": 2, "last": nb + 1, "n": nb}
    return c


# ---------------- «Сводка» ----------------
def _build_summary(ws, c, m, tx, lt, ctx):
    cache, first, end = ctx["cache"], ctx["first"], ctx["end"]
    ident, timestamp, language = ctx["ident"], ctx["timestamp"], ctx["language"]
    A = c.abs
    legend = {k: n for k, n, _e in LEGEND.get(language, LEGEND["ru"])["rows"]}
    st_name = {ST_OK: legend["ok"], ST_WRONG: legend["wrong"], ST_SUR: legend["surplus"], ST_DUP: legend["dup"],
               ST_SHORT: legend["missing"]}
    rank_colors = {k: _hex(v) for k, v in dashboard_render.GRADE_COLORS.items()}
    rank_colors["–"] = TEXT_DIM
    green, amber = _hex(rk.C_GREEN), _hex(rk.C_AMBER)

    widths = {"A": 1.5}
    for g in range(1, G + 1):
        widths[CL(gc(g))] = 3.0
    widths[CL(gc(G) + 1)] = 1.5
    _dark_sheet(ws, gc(G) + 2, widths)
    ws.sheet_format.defaultRowHeight = 15.75
    ws.sheet_format.customHeight = True
    RH = {}

    def setrow(r, h):
        ws.row_dimensions[r].height = h
        RH[r] = h

    def rowpx(r1, r2):
        return int(sum(round(RH.get(r, 15.75) * 96 / 72) for r in range(r1, r2 + 1)))

    def put(r, g, formula, value, font, align, fmt=None):
        cell = fx(ws, cache, r, gc(g), formula, value, fmt)
        cell.font, cell.alignment = font, align
        return cell

    # эхо-значения в служебной колонке A — для условного форматирования (не видны)
    for r, name, val in ((7, "band", m["band"]), (8, "rank", m["rank"]), (9, "prob", m["prob"])):
        cell = fx(ws, cache, r, 1, A[name], val)
        cell.font, cell.number_format = Font(name=FONT_NAME, size=1, color=BG), ";;;"

    # ---------- строка 1: навигация + переключатель глаз ----------
    setrow(1, 26)
    _nav_chip(ws, 1, gc(1), gc(14), tx["nav_table"], DATA_SHEET, f"B{first}")
    _nav_chip(ws, 1, gc(16), gc(29), tx["nav_problems"], PROB_SHEET, "A1")
    box(ws, 1, 38, 1, 47, lt["eyes_sw"], font=F(8, TEXT_DIM, True), fill=FILL_BG, align=AL("right", "center"))
    side_n = Side(style="thin", color=NEON)
    sw = box(ws, 1, 48, 1, 52, SWITCH_DEFAULT, font=F(9, NEON_SOFT, True), fill=FILL_HEAD,
             border=Border(top=side_n, bottom=side_n, left=side_n, right=side_n), align=AL("center", "center"))
    dv = DataValidation(type="list", formula1='"ВКЛ,ВЫКЛ"', allow_blank=False)
    dv.showDropDown = False
    ws.add_data_validation(dv)
    dv.add(sw.coordinate)
    setrow(2, 6)

    # ---------- шапка (статичная картинка-декор: название, ПВЗ, админ, дата, подпись автора) ----------
    banner, bw, bh = dashboard_render.render_banner(ident, timestamp, G * UNIT_PX, ASSETS_DIR, title=lt["title"], lang=ctx["language"])
    _place_image(ws, banner, gc(1), 3, bw, bh, alt="UZUM INVENT · by DAMIR")
    for r in (3, 4, 5, 6):
        setrow(r, 15.75)
    setrow(7, 8)

    # ---------- HERO: глаза ----------
    fill_area(ws, 8, 1, 23, 22, FILL_A)
    box(ws, 8, 1, 8, 22, None, fill=FILL_HEAD, font=F(9.5, TEXT, True), align=AL("center", "center"))
    put(8, 1, f'"{lt["mood"]}  ·  "&UPPER({A["moodname"]})', f'{lt["mood"]}  ·  {c.val["moodname"].upper()}',
        F(9.5, TEXT, True), AL("center", "center"))
    mood_rules = (("$A$7<=3", BANDS_COLOR["good"]), ("AND($A$7>=4,$A$7<=5)", BANDS_COLOR["neutral"]),
                  ("AND($A$7>=6,$A$7<=7)", BANDS_COLOR["warn"]), ("AND($A$7>=8,$A$7<=9)", BANDS_COLOR["bad"]),
                  ("$A$7=10", BANDS_COLOR["none"]))
    for cond, col in mood_rules:
        cf_expr(ws, f"{CL(gc(1))}8:{CL(gc(22))}8", cond, font=Font(color="FFFFFF", bold=True),
                fill=_fill(_mixhex(HEAD_BG, col, 0.5)))
    ctx["eyes_anchor"] = one_cell_anchor(gc(2), 9, 420, 210, 0, 6)
    box(ws, 20, 2, 21, 21, None, fill=FILL_A, font=F(14, NEON_SOFT, True), align=AL("center", "center", wrap=True))
    put(20, 2, A["phrase"], c.val["phrase"], F(14, NEON_SOFT, True), AL("center", "center", wrap=True))
    for cond, col in mood_rules:
        cf_expr(ws, f"{CL(gc(2))}20:{CL(gc(21))}21", cond, font=Font(color=_mixhex(col, "FFFFFF", 0.12), bold=True))
    box(ws, 22, 2, 22, 21, None, fill=FILL_A, font=F(9, TEXT_DIM), align=AL("center", "center"))
    put(22, 2, f'"{lt["purity"]}"&{A["effr"]}&"%"', f'{lt["purity"]}{num_text(m["effr"])}%', F(9, TEXT_DIM), AL("center", "center"))
    outline(ws, 8, 1, 23, 22, NEON)

    # ---------- HERO: точность ----------
    fill_area(ws, 8, 24, 23, 59, FILL_A)
    box(ws, 8, 24, 8, 59, lt["ring"], fill=FILL_HEAD, font=F(9.5, TEXT, True), align=AL("left", "center", indent=1))
    ctx["ring_anchor"] = one_cell_anchor(gc(25), 10, 12 * UNIT_PX, 12 * UNIT_PX)
    box(ws, 14, 28, 14, 33, lt["ring_cap"], fill=FILL_A, font=F(8, TEXT_DIM, True), align=AL("center", "bottom"))
    box(ws, 15, 28, 16, 33, None, fill=FILL_A, font=F(22, "FFFFFF", True), align=AL("center", "center"), fmt='0.0"%"')
    put(15, 28, A["accr"], m["accr"], F(22, "FFFFFF", True), AL("center", "center"), '0.0"%"')
    box(ws, 17, 28, 17, 33, None, fill=FILL_A, font=F(9, TEXT_SOFT), align=AL("center", "top"))
    put(17, 28, f'{A["ok"]}&" / "&{A["total"]}', f'{m[ST_OK]} / {m["total"]}', F(9, TEXT_SOFT), AL("center", "top"))
    box(ws, 10, 38, 11, 52, None, fill=FILL_A, font=F(30, "FFFFFF", True), align=AL("left", "center"))
    put(10, 38, f'{A["ok"]}&" {ctx["of_word"]} "&{A["total"]}', f'{m[ST_OK]} {ctx["of_word"]} {m["total"]}',
        F(30, "FFFFFF", True), AL("left", "center"))
    box(ws, 12, 38, 12, 52, lt["found_of"], fill=FILL_A, font=F(10, TEXT_SOFT), align=AL("left", "center"))
    badge = box(ws, 10, 54, 13, 58, None, fill=FILL_B, font=F(38, "FFFFFF", True), align=AL("center", "center"))
    put(10, 54, A["rank"], m["rank"], F(38, "FFFFFF", True), AL("center", "center"))
    box(ws, 14, 54, 14, 58, lt["rank"], fill=FILL_B, font=F(7, "FFFFFF", True), align=AL("center", "center"))
    for k, col in rank_colors.items():
        cf_expr(ws, f"{CL(gc(54))}10:{CL(gc(58))}14", f'$A$8="{k}"', fill=_fill(_mixhex(ROW_A, col, 0.8)))
    ctx["bar_anchor"] = one_cell_anchor(gc(38), 16, 21 * UNIT_PX, 20, 0, 1)
    for i, st in enumerate(ORDER5):
        g0 = 38 + i * 4
        col = STATUS_ACCENT[st]
        box(ws, 18, g0, 18, g0 + 3, lt["legend"][i], fill=FILL_A, font=F(7.5, col, True), align=AL("left", "center", indent=0))
        box(ws, 19, g0, 20, g0 + 3, None, fill=FILL_A, font=F(20, "FFFFFF", True), align=AL("left", "center"), fmt="0")
        put(19, g0, A[{ST_OK: "ok", ST_WRONG: "wrong", ST_SUR: "surplus", ST_DUP: "dup", ST_SHORT: "short"}[st]], m[st],
            F(20, _mixhex(col, "FFFFFF", 0.2), True), AL("left", "center"), "0")
        box(ws, 21, g0, 21, g0 + 3, None, fill=FILL_A, font=F(8, TEXT_DIM), align=AL("left", "center"))
        shv = lt["no_data"] if m["total"] == 0 else f'{num_text(xl_round(m[st] / m["total"] * 100, 1))}%'
        put(21, g0, f'IF({A["total"]}=0,"{lt["no_data"]}",ROUND({A[{ST_OK: "ok", ST_WRONG: "wrong", ST_SUR: "surplus", ST_DUP: "dup", ST_SHORT: "short"}[st]]}/{A["total"]}*100,1)&"%")',
            shv, F(8, TEXT_DIM), AL("left", "center"))
    outline(ws, 8, 24, 23, 59, NEON)
    setrow(24, 8)

    # ---------- KPI-плитки ----------
    tiles = [(NEON, A["total"], m["total"]), (green, A["ok"], m[ST_OK]), (amber, A["prob"], m["prob"]),
             (_hex(rk.C_GREEN), A["manual"], m["manual"])]
    for k, (col, ref, val) in enumerate(tiles):
        g0 = 1 + k * 15
        g1 = g0 + 13
        fill_area(ws, 25, g0, 29, g1, FILL_A)
        box(ws, 25, g0, 25, g1, lt["kpi"][k], font=F(8.5, TEXT_DIM, True), fill=FILL_A, align=AL("left", "center", indent=1),
            border=Border(top=Side(style="medium", color=col)))
        box(ws, 26, g0, 28, g1, None, font=F(30, "FFFFFF", True), fill=FILL_A, align=AL("left", "center", indent=1), fmt="0")
        put(26, g0, ref, val, F(30, "FFFFFF", True), AL("left", "center", indent=1), "0")
        if k == 1:
            cap_v = lt["no_data"] if m["total"] == 0 else f'{num_text(xl_round(val / m["total"] * 100, 1))}{lt["of_list"]}'
            cap_f = f'IF({A["total"]}=0,"{lt["no_data"]}",ROUND({ref}/{A["total"]}*100,1)&"{lt["of_list"]}")'
        elif k == 3:
            cap_t = lt["kpi_cap"][3]
            cap_f = '"' + cap_t.replace("{a}", '"&' + A["was_short"] + '&"').replace("{b}", '"&' + A["short"] + '&"') + '"'
            cap_v = cap_t.format(a=m["was"].get(ST_SHORT, 0), b=m[ST_SHORT])
        elif k == 2:
            cap_f = f'IF({A["prob"]}=0,"{lt["kpi_cap_ok"]}","{lt["kpi_cap"][2]}")'
            cap_v = lt["kpi_cap_ok"] if m["prob"] == 0 else lt["kpi_cap"][2]
        else:
            cap_f, cap_v = f'"{lt["kpi_cap"][0]}"', lt["kpi_cap"][0]
        box(ws, 29, g0, 29, g1, None, font=F(8.5, TEXT_DIM), fill=FILL_A, align=AL("left", "center", indent=1))
        put(29, g0, cap_f, cap_v, F(8.5, TEXT_DIM), AL("left", "center", indent=1))
        outline(ws, 25, g0, 29, g1, LINE)
        if k == 2:
            cf_expr(ws, f"{CL(gc(g0))}26:{CL(gc(g1))}28", "$A$9=0", font=Font(color=green, bold=True))
            cf_expr(ws, f"{CL(gc(g0))}26:{CL(gc(g1))}28", "$A$9>0", font=Font(color=amber, bold=True))
    setrow(30, 8)

    # ---------- «по статусам» ----------
    box(ws, 31, 1, 31, 30, lt["detail"], font=F(10, NEON_SOFT, True), fill=FILL_HEAD, align=AL("left", "center", indent=1))
    outline(ws, 31, 1, 31, 30, NEON)
    spans = [(1, 10), (11, 15), (16, 20), (21, 25)]
    for (a, b), h in zip(spans, lt["cols"]):
        box(ws, 32, a, 32, b, h, font=F(8, TEXT_DIM, True), fill=FILL_A, align=AL("left" if a == 1 else "center", "center", indent=1 if a == 1 else 0))
    box(ws, 32, 26, 32, 30, None, fill=FILL_A)
    rngH, rngM = DR("H", first, end), DR("M", first, end)
    tile_total = f"${CL(gc(1))}$26"
    key_of = {ST_OK: "ok", ST_WRONG: "wrong", ST_SUR: "surplus", ST_DUP: "dup", ST_SHORT: "short"}
    for i, st in enumerate(ORDER5):
        r = 33 + i
        setrow(r, 26)
        col = STATUS_ACCENT[st]
        now_v, was_v = m[st], m["was"].get(st, 0)
        box(ws, r, 1, r, 10, st_name[st], font=F(10, _mixhex(col, "FFFFFF", 0.25), True), fill=_fill(_mixhex(ROW_A, col, 0.2)),
            align=AL("left", "center", indent=1), border=Border(left=Side(style="thick", color=col)))
        box(ws, r, 11, r, 15, None, font=F(10.5, TEXT_DIM), fill=FILL_A, align=AL("center", "center"))
        put(r, 11, f'COUNTIF({rngM},"{st}")', was_v, F(10.5, TEXT_DIM), AL("center", "center"), "0")
        box(ws, r, 16, r, 20, None, font=F(14, "FFFFFF", True), fill=FILL_A, align=AL("center", "center"))
        put(r, 16, f'COUNTIF({rngH},"{st}")', now_v, F(14, "FFFFFF", True), AL("center", "center"), "0")
        box(ws, r, 21, r, 25, None, font=F(10, TEXT), fill=FILL_A, align=AL("center", "center"))
        sh = lt["no_data"] if m["total"] == 0 else f'{num_text(xl_round(now_v / m["total"] * 100, 1))}%'
        put(r, 21, f'IF({A["total"]}=0,"{lt["no_data"]}",ROUND({CL(gc(16))}{r}/{A["total"]}*100,1)&"%")', sh, F(10, TEXT), AL("center", "center"))
        for g in range(26, 31):
            ws.cell(row=r, column=gc(g)).fill = _fill(_mixhex(ROW_A, col, 0.12))
        nowref = f"${CL(gc(16))}${r}"
        cf_expr(ws, f"{CL(gc(26))}{r}:{CL(gc(30))}{r}",
                f"AND({nowref}>0,COLUMN()-{gc(26)}<MAX(1,MIN(5,ROUND({nowref}/MAX(1,{tile_total})*5,0))))", fill=_fill(col))
        outline(ws, r, 1, r, 30, LINE)
    setrow(38, 21)
    box(ws, 38, 1, 38, 10, lt["total_row"], font=F(8.5, TEXT_SOFT, True), fill=FILL_HEAD, align=AL("left", "center", indent=1))
    for (a, b), src in (((11, 15), 11), ((16, 20), 16)):
        box(ws, 38, a, 38, b, None, font=F(10.5, TEXT, True), fill=FILL_HEAD, align=AL("center", "center"))
        tot_v = sum((m["was"].get(s_, 0) if src == 11 else m[s_]) for s_ in ORDER5)
        put(38, a, f"SUM({CL(gc(src))}33:{CL(gc(src))}37)", tot_v, F(10.5, TEXT, True), AL("center", "center"), "0")
    box(ws, 38, 21, 38, 30, None, fill=FILL_HEAD)
    outline(ws, 38, 1, 38, 30, NEON)
    ctx["ring_data"] = {"first_row": 33, "last_row": 37, "val_col": gc(16), "cat_col": gc(1)}

    # ---------- ритм ----------
    box(ws, 31, 32, 31, 59, lt["rhythm"], font=F(10, NEON_SOFT, True), fill=FILL_HEAD, align=AL("left", "center", indent=1))
    outline(ws, 31, 32, 31, 59, NEON)
    fill_area(ws, 32, 32, 37, 59, FILL_A)
    ctx["eq_anchor"] = one_cell_anchor(gc(32), 32, 28 * UNIT_PX, rowpx(32, 37) - 6, 0, 3)
    box(ws, 38, 32, 38, 59, None, font=F(9.5, TEXT_SOFT, True), fill=FILL_HEAD, align=AL("center", "center"))
    put(38, 32, A["rhythm_line"], c.val["rhythm_line"], F(9.5, TEXT_SOFT, True), AL("center", "center"))
    outline(ws, 32, 32, 38, 59, LINE)
    setrow(39, 8)
    setrow(40, 8)

    # ---------- достижения: спокойные плашки ----------
    box(ws, 41, 1, 41, 30, lt["ach"], font=F(8.5, TEXT_DIM, True), fill=FILL_BG, align=AL("left", "center"))
    ach_idx = [1, 2, 3, 4, 5, 7]
    for i, a_i in enumerate(ach_idx):
        g0 = 1 + i * 10
        on = c.val[f"ach{a_i}"] == 1
        nm = lt["ach_names"][i]
        box(ws, 42, g0, 43, g0 + 8, None, font=F(9.5, TEXT_DIM, True), fill=FILL_A, align=AL("center", "center", wrap=True),
            border=Border(top=Side(style="thin", color=LINE), bottom=Side(style="thin", color=LINE),
                          left=Side(style="thin", color=LINE), right=Side(style="thin", color=LINE)))
        put(42, g0, f'IF({A[f"ach{a_i}"]}=1,"✓  ","")&"{nm}"', ("✓  " if on else "") + nm, F(9.5, TEXT_DIM, True),
            AL("center", "center", wrap=True))
        ref = f"${CL(gc(g0))}$42"
        cf_expr(ws, f"{CL(gc(g0))}42:{CL(gc(g0 + 8))}43", f'LEFT({ref},1)="✓"', font=Font(color="7CE8A8", bold=True),
                fill=_fill(_mixhex(ROW_A, green, 0.18)),
                border=Border(top=Side(style="thin", color=green), bottom=Side(style="thin", color=green),
                              left=Side(style="thin", color=green), right=Side(style="thin", color=green)))
    setrow(44, 8)

    # ---------- карта ячеек ----------
    box(ws, 45, 1, 45, 24, lt["map"], font=F(10, NEON_SOFT, True), fill=FILL_HEAD, align=AL("left", "center", indent=1))
    box(ws, 45, 25, 45, G, lt["map_legend"], font=F(8, TEXT_DIM, italic=True), fill=FILL_HEAD, align=AL("right", "center", indent=1))
    outline(ws, 45, 1, 45, G, NEON)
    cells = m["cells"][:MAX_MAP]
    per_row = 14
    r_base = 46
    for i, cell in enumerate(cells):
        rr = r_base + (i // per_row) * 3
        g0 = 2 + (i % per_row) * 4
        box(ws, rr, g0, rr, g0 + 3, cell, font=F(11, "FFFFFF", True), fill=_fill(_mixhex(ROW_A, "34C77B", 0.25)), align=AL("center", "center"))
        cr = ctx["cell_rows"][cell]
        pc = box(ws, rr + 1, g0, rr + 1, g0 + 3, None, font=F(9, "FFFFFF", True), fill=_fill(_mixhex(ROW_A, "34C77B", 0.25)),
                 align=AL("center", "center"), fmt='[=0]"✓";"⚠"0')
        fx(ws, cache, rr + 1, gc(g0), f"'{CALC}'!$AB${cr}", m["p"][i], '[=0]"✓";"⚠"0')
        pc.font, pc.alignment = F(9, "FFFFFF", True), AL("center", "center")
        rng = f"{CL(gc(g0))}{rr}:{CL(gc(g0 + 3))}{rr + 1}"
        ref_p = f"${CL(gc(g0))}${rr + 1}"
        cf_expr(ws, rng, f"{ref_p}>=3", fill=_fill(_mixhex(ROW_A, "FF3B30", 0.62)))
        cf_expr(ws, rng, f"AND({ref_p}>0,{ref_p}<3)", fill=_fill(_mixhex(ROW_A, "FFB020", 0.55)))
        side = Side(style="thin", color=BG)
        for r_ in (rr, rr + 1):
            for g_ in range(g0, g0 + 4):
                ws.cell(row=r_, column=gc(g_)).border = Border(left=side, right=side, top=side, bottom=side)
        if i % per_row == 0:
            setrow(rr + 2, 6)
    last_map_row = r_base + ((len(cells) - 1) // per_row) * 3 + 2 if cells else r_base
    if len(m["cells"]) > MAX_MAP:
        box(ws, last_map_row + 1, 1, last_map_row + 1, G, lt["map_more"].format(n=len(m["cells"]) - MAX_MAP),
            font=F(9, TEXT_DIM, italic=True), fill=FILL_BG, align=AL("left", "center"))
        last_map_row += 1

    # ---------- подпись автора ----------
    fr = last_map_row + 2
    setrow(fr, 22)
    side_t = Side(style="thin", color=NEON)
    blocks = [TextBlock(InlineFont(rFont=FONT_NAME, sz=9, b=True, color=TEXT_DIM), "U Z U M   I N V E N T      ·      "),
              TextBlock(InlineFont(rFont=FONT_NAME, sz=9, i=True, color=NEON_SOFT), "by "),
              TextBlock(InlineFont(rFont=FONT_NAME, sz=10, b=True, color=NEON_SOFT), "D A M I R")]
    box(ws, fr, 1, fr, G, CellRichText(*blocks), fill=FILL_BG, align=AL("center", "center"), border=Border(top=side_t))
    box(ws, fr + 1, 1, fr + 1, G, lt["footer"], font=F(8, TEXT_DIM, italic=True), fill=FILL_BG, align=AL("center", "center"))
    ctx["sum_last_row"] = fr + 1

    # ---------- диаграммы ----------
    _eyes_chart(ws, ctx)
    _ring_chart(ws, c, ctx)
    _share_bar(ws, ctx)
    _eq_chart(ws, c, ctx)
    ws.print_area = f"A1:{CL(gc(G) + 1)}{fr + 1}"
    ws.sheet_view.zoomScale = 100
    ws.sheet_view.tabSelected = True


def _transparent(ch):
    ch.legend = None
    ch.title = None
    ch.roundedCorners = False
    ch.graphical_properties = GraphicalProperties(noFill=True)
    ch.graphical_properties.line = LineProperties(noFill=True)
    ch.plot_area.graphicalProperties = GraphicalProperties(noFill=True)
    ch.plot_area.graphicalProperties.line = LineProperties(noFill=True)
    ch.plot_area.layout = Layout(manualLayout=ManualLayout(layoutTarget="inner", xMode="edge", yMode="edge",
                                                           x=0.0, y=0.0, w=1.0, h=1.0))


def _eyes_chart(ws, ctx):
    calc = ctx["ws_eyes"]
    cur = ctx["eye_cur"]
    ch = ScatterChart()
    ch.scatterStyle = "lineMarker"
    _transparent(ch)
    ch.x_axis.delete = True
    ch.y_axis.delete = True
    ch.x_axis.majorGridlines = None
    ch.y_axis.majorGridlines = None
    ch.x_axis.scaling.min, ch.x_axis.scaling.max = 0, eyes.XMAX
    ch.y_axis.scaling.min, ch.y_axis.scaling.max = 0, eyes.YMAX
    ch.dispBlanksAs = "gap"
    for name, k, _kind in eyes.SERIES:
        cx, r0 = cur[name]
        xs = Reference(calc, min_col=cx, min_row=r0, max_row=r0 + k - 1)
        ys = Reference(calc, min_col=cx + 1, min_row=r0, max_row=r0 + k - 1)
        st = eyes.STYLE[name]
        s = Series(ys, xs, title=st.get("label", name))

        if "sym" in st:
            s.marker = Marker(symbol=st["sym"], size=st["size"])
            gp = GraphicalProperties(solidFill=st["fill"]) if st["fill"] else GraphicalProperties(noFill=True)
            gp.line = LineProperties(solidFill=st["line"], w=int(st["lw"] * 12700))
            s.marker.graphicalProperties = gp
            s.graphicalProperties = GraphicalProperties()
            s.graphicalProperties.line = LineProperties(noFill=True)
            s.smooth = False
        elif "w" in st:
            s.marker = Marker(symbol="none")
            s.graphicalProperties = GraphicalProperties()
            s.graphicalProperties.line = LineProperties(solidFill=st["color"], w=int(st["w"] * 12700), cap=st["cap"])
            s.smooth = bool(st.get("smooth"))
        else:                                   # «z-z-z»: подпись-значок на невидимой точке
            s.marker = Marker(symbol="none")
            s.graphicalProperties = GraphicalProperties()
            s.graphicalProperties.line = LineProperties(noFill=True)
            s.smooth = False
            s.dLbls = DataLabelList()
            s.dLbls.showSerName = True               # подпись = имя ряда («z» / «Z»), без числовых форматов
            s.dLbls.showVal = s.dLbls.showCatName = s.dLbls.showLegendKey = s.dLbls.showPercent = False
            s.dLbls.position = "ctr"
            s.dLbls.txPr = txt_props(st["lsize"], NEON_SOFT, True)
        ch.series.append(s)
    if EYES_REVERSE:                               # только для проверочного рендера в LibreOffice
        ch.series.reverse()
    ch.anchor = ctx["eyes_anchor"]
    ws.add_chart(ch)


def _ring_chart(ws, c, ctx):
    rd = ctx["ring_data"]
    ch = DoughnutChart()
    ch.holeSize = 80
    ch.firstSliceAng = 0
    ch.add_data(Reference(ws, min_col=rd["val_col"], min_row=rd["first_row"], max_row=rd["last_row"]), titles_from_data=False)
    ch.set_categories(Reference(ws, min_col=rd["cat_col"], min_row=rd["first_row"], max_row=rd["last_row"]))
    s = ch.series[0]
    for i, st in enumerate(ORDER5):
        pt = DataPoint(idx=i)
        pt.graphicalProperties = GraphicalProperties(solidFill=STATUS_ACCENT[st])
        pt.graphicalProperties.line = LineProperties(solidFill=ROW_A, w=19050)
        s.dPt.append(pt)
    _transparent(ch)
    ch.anchor = ctx["ring_anchor"]
    ws.add_chart(ch)


def _share_bar(ws, ctx):
    rd = ctx["ring_data"]
    ch = BarChart()
    ch.type = "bar"
    ch.grouping = "percentStacked"
    ch.overlap = 100
    ch.gapWidth = 0
    for i, st in enumerate(ORDER5):
        r = rd["first_row"] + i
        s = Series(Reference(ws, min_col=rd["val_col"], min_row=r, max_row=r), title=st)
        s.graphicalProperties = GraphicalProperties(solidFill=STATUS_ACCENT[st])
        s.graphicalProperties.line = LineProperties(solidFill=ROW_A, w=12700)
        s.invertIfNegative = False
        ch.series.append(s)
    _transparent(ch)
    ch.x_axis.delete = True
    ch.y_axis.delete = True
    ch.y_axis.majorGridlines = None
    ch.anchor = ctx["bar_anchor"]
    ws.add_chart(ch)


def _eq_chart(ws, c, ctx):
    calc = ctx["ws_calc"]
    eq = ctx["eq"]
    ch = BarChart()
    ch.type = "col"
    ch.grouping = "clustered"
    ch.gapWidth = 22
    ch.add_data(Reference(calc, min_col=44, min_row=eq["first"], max_row=eq["last"]), titles_from_data=False)
    ch.set_categories(Reference(calc, min_col=41, min_row=eq["first"], max_row=eq["last"]))
    s = ch.series[0]
    s.graphicalProperties = GraphicalProperties(solidFill=NEON)
    s.graphicalProperties.line = LineProperties(noFill=True)
    s.invertIfNegative = False
    _transparent(ch)
    ch.plot_area.layout = None
    ch.y_axis.delete = True
    ch.y_axis.majorGridlines = None
    ch.x_axis.delete = False
    ch.x_axis.txPr = txt_props(8, TEXT_DIM)
    ch.x_axis.spPr = GraphicalProperties(ln=LineProperties(solidFill=LINE))
    ch.x_axis.majorTickMark = "none"
    ch.anchor = ctx["eq_anchor"]
    ws.add_chart(ch)


# ---------------- «Проблемы» ----------------
PCOL = {'A': 2, 'B': 7, 'C': 17, 'D': 25, 'E': 13, 'F': 15, 'G': 11, 'H': 19, 'I': 58, 'J': 14, 'K': 8}
P_HDR = 15


def _build_problems(ws, c, m, tx, lt, ctx):
    cache, first, end, written = ctx["cache"], ctx["first"], ctx["end"], ctx["written"]
    ident, timestamp, language = ctx["ident"], ctx["timestamp"], ctx["language"]
    A = c.abs
    legend = {k: n for k, n, _e in LEGEND.get(language, LEGEND["ru"])["rows"]}
    name_of = {ST_OK: legend["ok"], ST_WRONG: legend["wrong"], ST_SUR: legend["surplus"], ST_DUP: legend["dup"],
               ST_SHORT: legend["missing"]}
    _dark_sheet(ws, len(PCOL) + 1, PCOL)
    ws.column_dimensions["K"].hidden = True
    cols = {k: i + 1 for i, k in enumerate("ABCDEFGHIJK")}
    banner_w = sum(_col_width_to_px(PCOL[x]) for x in "BCDEFGHIJ")
    png, bw, bh = dashboard_render.render_banner(ident, timestamp, banner_w, ASSETS_DIR, title=tx["prob_title"], subtitle=tx["prob_sub"], lang=language)
    for r in (1, 2, 3):
        ws.row_dimensions[r].height = 20
    _place_image(ws, png, cols["B"], 1, bw, bh, alt=tx["prob_title"])
    ws.row_dimensions[4].height = 24
    _nav_chip(ws, 4, cols["B"], cols["C"], tx["nav_summary"], SUM_SHEET, "A1")
    _nav_chip(ws, 4, cols["D"], cols["D"], tx["nav_table"], DATA_SHEET, f"B{first}")
    _nav_chip(ws, 4, cols["E"], cols["F"], tx["nav_comments"], "Комменты", "A1")
    ws.row_dimensions[5].height = 8

    # --- вердикт ---
    ws.row_dimensions[6].height = 34
    ws.row_dimensions[7].height = 22
    pt = A["probtotal"]
    vok, vbad = tx["verdict_ok"], tx["verdict_bad"]
    vtext = vok if m["probtotal"] == 0 else vbad.format(n=m["probtotal"])
    vf = f'IF({pt}=0,"{esc(vok)}","{esc(vbad).replace("{n}", chr(34) + "&" + pt + "&" + chr(34))}")'
    cell = _merge(ws, 6, cols["B"], 6, cols["J"], None, fill=FILL_HEAD, border=Border(left=Side(style="thick", color=NEON)),
                  align=AL("left", "center", indent=1))
    cell.value, cell.font = "=" + vf, F(15, NEON_SOFT, True)
    cache[(ws.title, "B6")] = vtext
    fx(ws, cache, 6, cols["K"], pt, m["probtotal"])
    cf_expr(ws, "B6:J6", "$K$6=0", font=Font(color=_hex(rk.C_GREEN), bold=True), border=Border(left=Side(style="thick", color=_hex(rk.C_GREEN))))
    cf_expr(ws, "B6:J6", "$K$6>0", font=Font(color=_hex(rk.C_AMBER), bold=True), border=Border(left=Side(style="thick", color=_hex(rk.C_AMBER))))
    parts_f, parts_v = [], []
    for st in (ST_SHORT, ST_SUR, ST_WRONG, ST_DUP):
        parts_f.append(f'"{esc(name_of[st])} "&{A[{ST_SHORT: "short", ST_SUR: "surplus", ST_WRONG: "wrong", ST_DUP: "dup"}[st]]}')
        parts_v.append(f"{name_of[st]} {m[st]}")
    top1 = ctx["top_refs"][1]
    hint_t = tx["verdict_hint"]
    hint_f = tmpl_formula(hint_t, {"cell": top1["name"]})
    hint_v = tmpl_value(hint_t, {"cell": m["top"][0][0]}) if m["top"][0][0] else ""
    sub_f = '&"   ·   "&'.join(parts_f) + f'&IF({top1["name"]}="","","      "&{hint_f})'
    sub_v = "   ·   ".join(parts_v) + (("      " + hint_v) if hint_v else "")
    cell = _merge(ws, 7, cols["B"], 7, cols["J"], None, fill=FILL_HEAD, border=Border(left=Side(style="thick", color=NEON)),
                  align=AL("left", "center", indent=1))
    cell.value, cell.font = "=" + sub_f, F(9.5, TEXT_SOFT)
    cache[(ws.title, "B7")] = sub_v
    ws.row_dimensions[8].height = 10

    # --- шпаргалка по типам ---
    ws.row_dimensions[9].height = 22
    _merge(ws, 9, cols["B"], 9, cols["J"], lt["cheat"] if "cheat" in lt else {"ru": "ШПАРГАЛКА · ЧТО ДЕЛАТЬ С КАЖДЫМ ТИПОМ",
           "uz": "YO‘RIQNOMA · HAR BIR TURI BILAN NIMA QILISH"}[language if language in ("ru", "uz") else "ru"],
           fill=FILL_BG, font=F(8.5, TEXT_DIM, True), align=AL("left", "center", indent=1))
    for i, st in enumerate(SEC_ORDER):
        r = 10 + i
        ws.row_dimensions[r].height = 58
        key = SEC_KEY[st]
        accent = STATUS_ACCENT[st]
        title, what, todo = tx["sec"][key]
        keyname = STATUS_KEY[st]
        shown = name_of[st]
        cnt_ref = A[{ST_SHORT: "short", ST_SUR: "surplus", ST_WRONG: "wrong", ST_DUP: "dup"}[st]]
        ch = _merge(ws, r, cols["B"], r, cols["C"], None, fill=_fill(_mixhex(ROW_A, accent, 0.22)),
                    border=Border(left=Side(style="thick", color=accent), bottom=Side(style="thin", color=LINE)),
                    align=AL("left", "center", wrap=True, indent=1))
        ch.value, ch.font = f'="{esc(shown)}  ·  "&{cnt_ref}', F(11, _mixhex(accent, "FFFFFF", 0.25), True)
        cache[(ws.title, ch.coordinate)] = f"{shown}  ·  {m[st]}"
        _merge(ws, r, cols["D"], r, cols["J"], f"{tx['what']}: {what}\n{tx['todo']}: {todo}", fill=FILL_A,
               border=Border(bottom=Side(style="thin", color=LINE)), font=F(9, TEXT),
               align=AL("left", "center", wrap=True, indent=1))
        cf_expr(ws, f"B{r}:J{r}", f'RIGHT($B{r},4)="·  0"', font=Font(color=TEXT_DIM))
    ws.row_dimensions[14].height = 12

    # --- таблица проблем ---
    cap = min(max(len(written), 20) + EXTRA_ROWS, 1200)
    ph = tx["ph"]
    ws.row_dimensions[P_HDR].height = 24
    for letter, text in (("B", ph["no"]), ("C", ph["order"]), ("D", ph["pu"]), ("E", ph["wms"]), ("F", ph["found"]),
                         ("G", ph["time"]), ("H", tx["hdr"]["status"]), ("I", ph["what"]), ("J", ph["go"])):
        cc = ws.cell(row=P_HDR, column=cols[letter], value=text)
        cc.font, cc.fill = F(8.5, TEXT_SOFT, True), FILL_HEAD
        cc.border = Border(bottom=Side(style="medium", color=NEON))
        cc.alignment = AL("center", "center")

    N, B_, C_, D_, F_, G_, H_, E_ = (DR(x, first, end) for x in "NBCDFGHE")
    pos_of = {}
    cum = 0
    for i, w in enumerate(written, start=1):
        if w["h"] != OK_STATUS:
            cum += 1
            pos_of[cum] = i
    note_places = tx["places"]
    note_other = tx["other"].replace(" ({pus})", "")
    base_font = F(10, TEXT)
    for k in range(1, cap + 1):
        r = P_HDR + k
        ws.row_dimensions[r].height = 30
        pos = pos_of.get(k)
        w = written[pos - 1] if pos else None
        fx(ws, cache, r, cols["K"], f'IF(ROW()-{P_HDR}>{pt},"",MATCH(ROW()-{P_HDR},{N},0))', pos if pos else "")
        kref = f"$K{r}"

        fx(ws, cache, r, cols["B"], f'IF({kref}="","",INDEX({B_},{kref}))', w["b"] if w else "")
        fx(ws, cache, r, cols["C"], f'IF({kref}="","",INDEX({C_},{kref}))', w["c"] if w else "")
        pu = ""
        if w:
            pu = w["full"] if (w["scanned"] and w["full"]) else "—"
        fx(ws, cache, r, cols["D"], f'IF({kref}="","",IF(INDEX({E_},{kref})="","—",INDEX({E_},{kref})))', pu)
        fx(ws, cache, r, cols["E"], f'IF({kref}="","",INDEX({D_},{kref}))', w["d"] if w else "")
        fx(ws, cache, r, cols["F"], f'IF({kref}="","",INDEX({F_},{kref}))', w["f"] if w else "")
        tcell = fx(ws, cache, r, cols["G"], f'IF({kref}="","",IF(INDEX({G_},{kref})="","—",INDEX({G_},{kref})))',
                   ("—" if (not w or w["t"] is None) else w["t"] / 86400) if w else "", "hh:mm:ss")
        fx(ws, cache, r, cols["H"], f'IF({kref}="","",INDEX({H_},{kref}))', w["h"] if w else "")
        # предложение «что произошло»
        pl_cnt = f'COUNTIFS({C_},$C{r},{D_},"<>—")'
        other_cnt = f'COUNTIF({C_},$C{r})'
        rowt = tx["row"]
        places_f = f'IF({pl_cnt}>1,{tmpl_formula(note_places, {"n": pl_cnt})},"")'
        other_f = f'IF({other_cnt}>1,"{esc(note_other)}","")'
        s_short = tmpl_formula(rowt["missing"], {"exp": f"$E{r}", "scan": f"$F{r}", "places": places_f})
        s_wrong = tmpl_formula(rowt["wrong"], {"exp": f"$E{r}", "scan": f"$F{r}"})
        s_sur = tmpl_formula(rowt["surplus"], {"exp": f"$E{r}", "scan": f"$F{r}"})
        s_dup = tmpl_formula(rowt["dup"], {"exp": f"$E{r}", "scan": f"$F{r}", "other": other_f})
        sf = (f'IF({kref}="","",IF($H{r}="{ST_SHORT}",{s_short},IF($H{r}="{ST_WRONG}",{s_wrong},'
              f'IF($H{r}="{ST_SUR}",{s_sur},IF($H{r}="{ST_DUP}",{s_dup},$H{r})))))')
        sv = ""
        if w:
            pcount = sum(1 for x in written if x["c"] == w["c"] and x["d"] != "—")
            ocount = sum(1 for x in written if x["c"] == w["c"])
            mp = {"exp": w["d"], "scan": w["f"], "places": tmpl_value(note_places, {"n": pcount}) if pcount > 1 else "",
                  "other": note_other if ocount > 1 else ""}
            key = {ST_SHORT: "missing", ST_WRONG: "wrong", ST_SUR: "surplus", ST_DUP: "dup"}.get(w["h"])
            sv = tmpl_value(rowt[key], mp) if key else w["h"]
        fx(ws, cache, r, cols["I"], sf, sv)
        lf = f'IF({kref}="","",HYPERLINK("#\'{DATA_SHEET}\'!B"&({first - 1}+{kref}),"{tx["link"].split("{n}")[0]}"&$B{r}))'
        fx(ws, cache, r, cols["J"], lf, (tx["link"].split("{n}")[0] + str(w["b"])) if w else "")
        for letter in "BCDEFGHIJ":
            cc = ws.cell(row=r, column=cols[letter])
            cc.alignment = AL("left" if letter == "I" else "center", "center", wrap=(letter == "I"), indent=1 if letter == "I" else 0)
            cc.font = base_font
        ws.cell(row=r, column=cols["B"]).font = F(9, TEXT_DIM)
        ws.cell(row=r, column=cols["C"]).font = F(10, TEXT, True)
        ws.cell(row=r, column=cols["I"]).font = F(9.5, TEXT)
        ws.cell(row=r, column=cols["J"]).font = Font(name=FONT_NAME, size=9, bold=True, color=NEON_SOFT, underline="single")
    last = P_HDR + cap
    rngp = f"B{P_HDR + 1}:J{last}"
    for status, accent in STATUS_ACCENT.items():
        light = _mixhex(accent, "FFFFFF", 0.25)
        side = Side(style="thin", color=accent)
        cf_expr(ws, f"H{P_HDR + 1}:H{last}", f'$H{P_HDR + 1}="{status}"', font=Font(color=light, bold=True),
                fill=_fill(_mixhex(ROW_A, accent, 0.24)), border=Border(left=side, right=side, top=side, bottom=side))
        bb = Border(bottom=Side(style="thin", color=LINE))
        cf_expr(ws, f"C{P_HDR + 1}:C{last}", f'AND($H{P_HDR + 1}="{status}",MOD(ROW(),2)=0)', font=Font(color=light, bold=True),
                fill=_fill(ROW_B), border=bb)
        cf_expr(ws, f"C{P_HDR + 1}:C{last}", f'$H{P_HDR + 1}="{status}"', font=Font(color=light, bold=True),
                fill=_fill(ROW_A), border=bb)
    cf_expr(ws, rngp, f'AND($K{P_HDR + 1}<>"",MOD(ROW(),2)=0)', fill=_fill(ROW_B), border=Border(bottom=Side(style="thin", color=LINE)))
    cf_expr(ws, rngp, f'$K{P_HDR + 1}<>""', fill=_fill(ROW_A), border=Border(bottom=Side(style="thin", color=LINE)))
    ws.print_area = f"A1:J{last}"
    ctx["prob_last"] = last


# ============================================================
#  КЭШ ЗНАЧЕНИЙ ФОРМУЛ (для просмотрщиков без пересчёта)
# ============================================================
def _xml_escape(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _cached_cell(ref, attrs, formula_xml, value):
    attrs = f' r="{ref}"' + re.sub(r'\s+t="[^"]*"', "", attrs)
    if isinstance(value, XlError):
        return f'<c{attrs} t="e"><f>{formula_xml}</f><v>{_xml_escape(str(value))}</v></c>'
    if isinstance(value, bool):
        return f'<c{attrs} t="b"><f>{formula_xml}</f><v>{int(value)}</v></c>'
    if isinstance(value, (int, float)):
        v = repr(float(value)) if isinstance(value, float) else str(value)
        if isinstance(value, float) and value == int(value) and abs(value) < 1e15:
            v = str(int(value))
        return f'<c{attrs}><f>{formula_xml}</f><v>{v}</v></c>'
    return f'<c{attrs} t="str"><f>{formula_xml}</f><v>{_xml_escape(str(value))}</v></c>'


def _col_to_idx(letters):
    n = 0
    for ch in letters:
        n = n * 26 + ord(ch) - 64
    return n


def _expand(ref):
    """'Sheet'!$A$2:$A$9 -> (sheet, [A2..A9])"""
    m_ = re.match(r"^'?(.*?)'?!\$?([A-Z]+)\$?(\d+)(?::\$?([A-Z]+)\$?(\d+))?$", ref)
    if not m_:
        return None, []
    sh, c1, r1, c2, r2 = m_.groups()
    c2, r2 = c2 or c1, r2 or r1
    out = []
    for r in range(int(r1), int(r2) + 1):
        for ci in range(_col_to_idx(c1), _col_to_idx(c2) + 1):
            out.append(f"{CL(ci)}{r}")
    return sh, out


def inject_caches(xlsx_bytes, titles, cache, static=None):
    """Кладёт в <v> кэшированные значения формул и в диаграммы — numCache/strCache. Любая ошибка — файл как был."""
    try:
        static = static or {}
        src = zipfile.ZipFile(io.BytesIO(xlsx_bytes))
        out = io.BytesIO()
        # Пустое значение формулы openpyxl пишет как <v/> (et_xmlfile) или как <v></v> (если на ПК установлен lxml).
        # Раньше понимали только <v/> — при lxml кэш не вставлялся вовсе, и просмотрщики без пересчёта
        # (предпросмотр Telegram, телефон) показывали «Сводку» и «Проблемы» без цифр.
        pat = re.compile(r'<c r="([A-Z]+\d+)"([^>]*)><f>(.*?)</f><v(?:\s*/>|>\s*</v>)</c>', re.S)

        def lookup(sheet, ref):
            if (sheet, ref) in cache:
                return cache[(sheet, ref)]
            return static.get((sheet, ref))

        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as dst:
            for item in src.infolist():
                data = src.read(item.filename)
                mm = re.fullmatch(r"xl/worksheets/sheet(\d+)\.xml", item.filename)
                if mm:
                    title = titles[int(mm.group(1)) - 1]
                    xml = data.decode("utf-8")

                    def rep(mo):
                        ref, attrs, f = mo.groups()
                        if (title, ref) not in cache:
                            return mo.group(0)
                        return _cached_cell(ref, attrs, f, cache[(title, ref)])
                    data = pat.sub(rep, xml).encode("utf-8")
                elif re.fullmatch(r"xl/charts/chart\d+\.xml", item.filename):
                    xml = data.decode("utf-8")
                    px = "c:" if "<c:chartSpace" in xml else ""      # openpyxl пишет без префикса (пространство имён по умолчанию)

                    def rep_num(mo):
                        ref = mo.group(1).replace("&apos;", "'")
                        sh, cells = _expand(ref)
                        vals = [lookup(sh, x) for x in cells]
                        pts = "".join(f'<{px}pt idx="{i}"><{px}v>{v}</{px}v></{px}pt>' for i, v in enumerate(vals)
                                      if isinstance(v, (int, float)) and not isinstance(v, bool))
                        return (f'<{px}numRef><{px}f>{mo.group(1)}</{px}f><{px}numCache><{px}formatCode>General</{px}formatCode>'
                                f'<{px}ptCount val="{len(vals)}"/>{pts}</{px}numCache></{px}numRef>')

                    def rep_str(mo):
                        ref = mo.group(1).replace("&apos;", "'")
                        sh, cells = _expand(ref)
                        vals = [lookup(sh, x) for x in cells]
                        pts = "".join(f'<{px}pt idx="{i}"><{px}v>{_xml_escape(str(v))}</{px}v></{px}pt>'
                                      for i, v in enumerate(vals) if v is not None)
                        return (f'<{px}strRef><{px}f>{mo.group(1)}</{px}f><{px}strCache><{px}ptCount val="{len(vals)}"/>'
                                f'{pts}</{px}strCache></{px}strRef>')
                    xml = re.sub(rf"<{px}numRef><{px}f>([^<]*)</{px}f></{px}numRef>", rep_num, xml)
                    xml = re.sub(rf"<{px}strRef><{px}f>([^<]*)</{px}f></{px}strRef>", rep_str, xml)
                    data = xml.encode("utf-8")
                dst.writestr(item, data)
        return out.getvalue()
    except Exception:
        return xlsx_bytes
