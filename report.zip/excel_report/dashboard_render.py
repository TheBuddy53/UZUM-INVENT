"""
dashboard_render.py — рисует PNG-картинки отчёта (лист «Сводка» и баннер над таблицей)
в стиле СЛА-сайта / Uzum Design System: почти чёрный фиолетовый фон (#030008) с мягкими
неоновыми «волнами», стеклянные карточки, капс-подписи с разрядкой, глаза-талисман,
неоновые акценты статусов.

Картинки вставляются в Excel как обычные картинки (openpyxl.drawing.image) — поэтому
здесь честно рисуются blur/прозрачность/градиенты через Pillow (нативные заливки ячеек
этого не умеют).

Публичные функции (сигнатуры совместимы с прежней версией):
    render_dashboard(profile, kpis, timestamp, assets_dir, problem_cells=None) -> (png_bytes, w, h)
    render_banner(profile, timestamp, width_px, assets_dir, title=..., subtitle=...) -> (png_bytes, w, h)
"""
from __future__ import annotations
from PIL import Image, ImageDraw, ImageFilter, ImageChops
from pathlib import Path
import io
import math

from . import render_kit as rk
from .render_kit import s as _s


def s(v):
    """Логические px -> px холста, всегда int (Pillow не принимает дробные размеры/координаты)."""
    return int(round(_s(v)))

W = 1280       # логическая ширина дашборда (px) — влезает в экран ноутбука без скролла
PAD = 28
GAP = 16

# цвета KPI (палитра сайта): всего / верно / недостача / неверная / задвоенные / излишки
K_TOTAL = rk.NEON
K_OK = rk.C_GREEN
K_MISSING = rk.C_GREY
K_WRONG = rk.C_RED
K_DUP = rk.C_AMBER
K_SURPLUS = rk.C_PINK

# русские подписи статусов (как в db.STATUS_LABELS) -> цвет, для панели «проблемные ячейки»
PROBLEM_COLOR = {
    "Неверная ячейка": rk.C_RED,
    "Излишек": rk.C_PINK,
    "Задвоенный": rk.C_AMBER,
    "Недостача": rk.C_GREY,
}


# ------------------------------------------------------------------ базовые блоки
def _card(canvas, x, y, w, h, *, radius=24, tint=None, glow=None, glow_alpha=45):
    """Стеклянная карточка (координаты логические). glow — цветная подсветка в углу."""
    box = (s(x), s(y), s(w), s(h))
    rk.glass_panel(canvas, box, radius=s(radius), fill=(46, 18, 90, 78),
                   tint=tint, shadow=True, shadow_alpha=170, shadow_blur=s(22),
                   border_top=(255, 255, 255, 70), border_bottom=(0, 0, 0, 150))
    if glow is not None:
        rk.blob_glow(canvas, s(x + w - 40), s(y + 30), s(min(w, 260) // 2), glow, glow_alpha)


def _fit(txt, size, max_w, weight="semibold"):
    """Обрезает строку с «…», чтобы она влезла в max_w (логических px)."""
    txt = str(txt)
    if rk.text_w(txt, size, weight=weight) <= s(max_w):
        return txt
    while len(txt) > 1 and rk.text_w(txt + "…", size, weight=weight) > s(max_w):
        txt = txt[:-1]
    return txt + "…"


def _logo(canvas, logo_path: Path, x, y, size):
    """Логотип в плитке + неоновое свечение под ним (x, y, size — логические px)."""
    rk.blob_glow(canvas, s(x + size // 2), s(y + size // 2), s(size), rk.NEON, 85)
    if logo_path.exists():
        logo = Image.open(logo_path).convert("RGBA").resize((s(size), s(size)), Image.LANCZOS)
        canvas.alpha_composite(logo, (s(x), s(y)))


def _date_pill(canvas, right_x, cy, txt):
    """Неоновая капсула с датой, как «20.10.2026» на сайте."""
    tw = rk.text_w(txt, 13, weight="semibold", tracking=0.4)
    pw, ph = int(tw) + s(40), s(36)
    x = s(right_x) - pw
    y = s(cy) - ph // 2
    rk.glass_panel(canvas, (x, y, pw, ph), radius=ph // 2, fill=(112, 0, 255, 70),
                   border_top=(*rk.NEON, 230), border_bottom=(*rk.NEON, 140),
                   shadow=False, sheen=False)
    rk.tracked_text(canvas, (x + pw // 2, y + ph // 2), txt, 13, rk.NEON_SOFT, tracking=0.4,
                    weight="semibold", anchor="mm")
    return x


def _eq_button(canvas, right_x, cy):
    size = s(40)
    x, y = s(right_x) - size, s(cy) - size // 2
    rk.glass_panel(canvas, (x, y, size, size), radius=s(13), fill=(112, 0, 255, 60),
                   border_top=(*rk.NEON, 200), border_bottom=(*rk.NEON, 120), shadow=False, sheen=False)
    rk.equalizer_icon(canvas, x + size // 2, y + size // 2, s(17))
    return x


# ------------------------------------------------------------------ секции дашборда
def _header(canvas, y, profile, timestamp, logo_path):
    h = 104
    _card(canvas, PAD, y, W - 2 * PAD, h, glow=rk.NEON, glow_alpha=40)
    _logo(canvas, logo_path, PAD + 24, y + 20, 64)
    tx = s(PAD + 24 + 64 + 20)
    rk.text(canvas, (tx, s(y + 44)), "Инвентаризация ПВЗ", 27, rk.WHITE, weight="extrabold", anchor="lm")
    rk.tracked_text(canvas, (tx, s(y + 72)), "UZUM MARKET  ·  ЭКОСИСТЕМА ПВЗ", 9.5, rk.TEXT_DIM,
                    tracking=2.2, weight="semibold", anchor="lm")
    x = _date_pill(canvas, W - PAD - 24, y + h / 2, timestamp)
    _eq_button(canvas, int(x / rk.SCALE) - 12, y + h / 2)
    return y + h


def _info_bar(canvas, y, profile, timestamp):
    h = 84
    _card(canvas, PAD, y, W - 2 * PAD, h, radius=22)
    items = [
        (rk.icon_store, "ПВЗ", profile.get("pvz", "—")),
        (rk.icon_person, "АДМИНИСТРАТОР", profile.get("admin_name", "—")),
        (rk.icon_target, "ТАБЕЛЬНЫЙ №", profile.get("tabel_number", "—")),
        (rk.icon_clock, "ЗАВЕРШЕНО", timestamp),
    ]
    inner_w = W - 2 * PAD
    cell_w = inner_w / 4
    for i, (icon_fn, label, value) in enumerate(items):
        cx = PAD + i * cell_w
        if i:
            d = ImageDraw.Draw(canvas)
            d.line([(s(cx), s(y + 18)), (s(cx), s(y + h - 18))], fill=(255, 255, 255, 28), width=s(1))
        tile = rk.duotone_tile(icon_fn, s(42), rk.WHITE, (112, 0, 255), radius=s(13), solid=True)
        canvas.alpha_composite(tile, (s(cx + 20), s(y + (h - 42) / 2)))
        tx = s(cx + 20 + 42 + 14)
        rk.tracked_text(canvas, (tx, s(y + 30)), label, 8.5, rk.TEXT_DIM, tracking=1.8, anchor="lm")
        rk.text(canvas, (tx, s(y + 54)), _fit(value, 14.5, cell_w - 20 - 42 - 14 - 18), 14.5, rk.WHITE,
                weight="semibold", anchor="lm")
    return y + h


def _donut(canvas, cx, cy, d, pct, color):
    """Кольцо точности с неоновым свечением (всё в пикселях холста)."""
    th = int(d * 0.13)
    pad = th // 2 + s(2)
    box = [cx - d // 2 + pad, cy - d // 2 + pad, cx + d // 2 - pad, cy + d // 2 - pad]
    rk.blob_glow(canvas, cx, cy, int(d * 0.8), color, 38)
    draw = ImageDraw.Draw(canvas)
    draw.arc(box, 0, 360, fill=(70, 44, 125, 120), width=th)  # тёмно-фиолетовый трек (на белом был «металлический»)
    pct = max(0.0, min(100.0, pct))
    if pct <= 0:
        return
    end = -90 + 360 * pct / 100
    glow = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    ImageDraw.Draw(glow).arc(box, -90, end, fill=(*color, 190), width=th)
    # блюр только в окрестности кольца (быстрее, чем по всему холсту)
    bx0, by0 = max(box[0] - th * 2, 0), max(box[1] - th * 2, 0)
    bx1, by1 = min(box[2] + th * 2, canvas.width), min(box[3] + th * 2, canvas.height)
    region = glow.crop((bx0, by0, bx1, by1)).filter(ImageFilter.GaussianBlur(s(7)))
    canvas.alpha_composite(region, (bx0, by0))
    draw.arc(box, -90, end, fill=(*rk.lighten(color, 0.12), 255), width=th)
    r = th / 2
    # Pillow рисует arc(width=th) ВНУТРЬ от bbox, поэтому центр кольца-линии — на радиусе (bbox/2 - th/2).
    # Раньше скруглённые «шапочки» ставились на внешний край и торчали «ушками» над кольцом.
    rr = (box[2] - box[0]) / 2 - th / 2
    ang = math.radians(end)
    ex, ey = cx + rr * math.cos(ang), cy + rr * math.sin(ang)
    draw.ellipse([ex - r, ey - r, ex + r, ey + r], fill=(*rk.lighten(color, 0.12), 255))
    sx, sy = cx, cy - rr  # скруглённый старт
    draw.ellipse([sx - r, sy - r, sx + r, sy + r], fill=(*rk.lighten(color, 0.12), 255))


def _stacked_bar(canvas, x, y, w, h, segments):
    """Горизонтальная стопка статусов: segments = [(count, color), ...] (логические px)."""
    total = sum(c for c, _ in segments)
    X, Y, Wp, Hp = s(x), s(y), s(w), s(h)
    track = Image.new("RGBA", (Wp, Hp), (0, 0, 0, 0))
    ImageDraw.Draw(track).rounded_rectangle([0, 0, Wp - 1, Hp - 1], radius=Hp // 2, fill=(255, 255, 255, 30))
    canvas.alpha_composite(track, (X, Y))
    if total <= 0:
        return
    bar = Image.new("RGBA", (Wp, Hp), (0, 0, 0, 0))
    bd = ImageDraw.Draw(bar)
    gap = s(2)
    cx = 0.0
    nz = [(c, col) for c, col in segments if c > 0]
    for i, (c, col) in enumerate(nz):
        seg_w = Wp * c / total
        x0 = cx + (gap / 2 if i else 0)
        x1 = cx + seg_w - (gap / 2 if i < len(nz) - 1 else 0)
        bd.rectangle([x0, 0, max(x1, x0 + s(3)), Hp], fill=(*col, 255))
        cx += seg_w
    mask = rk.rounded_mask((Wp, Hp), Hp // 2)
    out = Image.new("RGBA", (Wp, Hp), (0, 0, 0, 0))
    out.paste(bar, (0, 0), mask)
    glow = out.filter(ImageFilter.GaussianBlur(s(6)))
    canvas.alpha_composite(glow, (X, Y + s(3)))
    canvas.alpha_composite(out, (X, Y))


def _hero_row(canvas, y, kpis, profile):
    h = 236
    eyes_w = 360
    acc_x = PAD + eyes_w + GAP
    acc_w = W - PAD - acc_x

    # --- слева: глаза-талисман (как карточка «выбери ПВЗ…» на сайте) ---
    _card(canvas, PAD, y, eyes_w, h, glow=rk.NEON, glow_alpha=55)
    ecx = PAD + eyes_w / 2
    er = 38
    total = kpis["total"]
    acc = (kpis["correct"] / total * 100) if total else 0.0
    grade = grade_for(kpis)
    mood = MOOD[grade]
    look = MOOD_LOOK[mood]
    ey = y + 92
    rk.eye(canvas, s(ecx - 52), s(ey), s(er), look=look)
    rk.eye(canvas, s(ecx + 52), s(ey), s(er), look=look)
    rk.eye_brows(canvas, s(ecx), s(ey), s(er), s(52), mood)   # настроение вместо анимации
    rk.text(canvas, (s(ecx), s(y + 154)), PHRASE[grade], 15, rk.lighten(GRADE_COLORS[grade], 0.2),
            weight="bold", anchor="mm")
    rk.text(canvas, (s(ecx), s(y + 180)), "инвентаризация завершена", 12.5, rk.TEXT_HINT,
            weight="semibold", anchor="mm")
    rk.text(canvas, (s(ecx), s(y + 203)), _fit(profile.get("pvz", ""), 11.5, eyes_w - 50, "regular"), 11.5,
            rk.TEXT_DIM, anchor="mm")

    # --- справа: точность + разбивка ---
    _card(canvas, acc_x, y, acc_w, h)
    ring_color = rk.C_GREEN if acc >= 80 else (rk.C_AMBER if acc >= 50 else rk.C_RED)
    d = 156
    rcx, rcy = acc_x + 28 + d // 2, y + 34 + d // 2
    _donut(canvas, s(rcx), s(rcy), s(d), acc, ring_color)
    pct_txt = f"{acc:.0f}%" if acc == int(acc) else f"{acc:.1f}%"
    rk.text(canvas, (s(rcx), s(rcy - 6)), pct_txt, 25, rk.WHITE, weight="extrabold", anchor="mm")
    rk.tracked_text(canvas, (s(rcx), s(rcy + 26)), "ТОЧНОСТЬ", 8.5, rk.TEXT_DIM, tracking=1.8, anchor="mm")

    tx = acc_x + 28 + d + 34
    rk.tracked_text(canvas, (s(tx), s(y + 46)), "ТОЧНОСТЬ ИНВЕНТАРИЗАЦИИ", 10.5, rk.TEXT_DIM, tracking=2.0, anchor="lm")
    rk.text(canvas, (s(tx), s(y + 80)), f"{kpis['correct']} из {kpis['total']}", 30, ring_color,
            weight="extrabold", anchor="lm")
    rk.text(canvas, (s(tx), s(y + 112)), "заказов найдено в верной ячейке", 13.5, rk.TEXT_MUTED, anchor="lm")

    # стопка статусов + легенда
    segs = [
        ("Верно", kpis["correct"], K_OK),
        ("Недостача", kpis["shortage"], K_MISSING),
        ("Неверная ячейка", kpis["wrong"], K_WRONG),
        ("Задвоенные", kpis["dup"], K_DUP),
        ("Излишки", kpis["surplus"], K_SURPLUS),
    ]
    bar_w = acc_x + acc_w - 28 - tx
    _rank_badge(canvas, acc_x + acc_w - 28 - 78, y + 28, grade)
    _stacked_bar(canvas, tx, y + 140, bar_w, 12, [(c, col) for _, c, col in segs])
    lx, ly = tx, y + 176
    d_ = ImageDraw.Draw(canvas)
    for name, cnt, col in segs:
        label = f"{name} {cnt}"
        lw = rk.text_w(label, 11, weight="semibold") / rk.SCALE
        if lx + 16 + lw > acc_x + acc_w - 20:
            lx, ly = tx, ly + 22
        d_.ellipse([s(lx), s(ly - 4), s(lx + 8), s(ly + 4)], fill=(*col, 255))
        rk.text(canvas, (s(lx + 14), s(ly)), label, 11, rk.TEXT_HINT, weight="semibold", anchor="lm")
        lx += 14 + lw + 18
    return y + h


def _kpi_card(canvas, x, y, w, h, icon_fn, label, value, color):
    _card(canvas, x, y, w, h, radius=20, tint=(*color, 20), glow=color, glow_alpha=40)
    tile = rk.duotone_tile(icon_fn, s(44), rk.WHITE, color, radius=s(14), solid=True)
    canvas.alpha_composite(tile, (s(x + 20), s(y + (h - 44) / 2 - 2)))
    rk.tracked_text(canvas, (s(x + 20 + 44 + 16), s(y + 30)), label.upper(), 8.5, rk.TEXT_DIM, tracking=1.8, anchor="lm")
    val_color = rk.lighten(color, 0.18)
    rk.text(canvas, (s(x + 20 + 44 + 16), s(y + 66)), str(value), 34, val_color, weight="extrabold", anchor="lm")
    # неоновая полоска внизу
    bar = Image.new("RGBA", (s(w - 44), s(3)), (*color, 255))
    glow = Image.new("RGBA", (s(w - 44), s(14)), (0, 0, 0, 0))
    ImageDraw.Draw(glow).rounded_rectangle([0, s(5), s(w - 44), s(9)], radius=s(2), fill=(*color, 210))
    canvas.alpha_composite(glow.filter(ImageFilter.GaussianBlur(s(4))), (s(x + 22), s(y + h - 14)))
    canvas.paste(bar, (s(x + 22), s(y + h - 10)), rk.rounded_mask(bar.size, s(2)))


def _kpi_grid(canvas, y, kpis):
    rows = [
        [(rk.icon_list, "Всего заказов", kpis["total"], K_TOTAL),
         (rk.icon_check, "Верно найдено", kpis["correct"], K_OK),
         (rk.icon_minus, "Недостача", kpis["shortage"], K_MISSING)],
        [(rk.icon_cross, "Неверная ячейка", kpis["wrong"], K_WRONG),
         (rk.icon_warning, "Задвоенные", kpis["dup"], K_DUP),
         (rk.icon_box, "Излишки", kpis["surplus"], K_SURPLUS)],
    ]
    h = 100
    cw = (W - 2 * PAD - 2 * GAP) / 3
    for r, row in enumerate(rows):
        for c, (icon_fn, label, value, color) in enumerate(row):
            _kpi_card(canvas, PAD + c * (cw + GAP), y + r * (h + GAP), cw, h, icon_fn, label, value, color)
    return y + 2 * h + GAP


def _problem_panel(canvas, y, problem_cells):
    """Топ ячеек с проблемами: номер ячейки + цветная стопка статусов + счётчик."""
    items = list(problem_cells or [])[:6]
    rows_per_col = 3
    h = 70 + rows_per_col * 46 + 16
    _card(canvas, PAD, y, W - 2 * PAD, h)
    rk.tracked_text(canvas, (s(PAD + 28), s(y + 34)), "ПРОБЛЕМНЫЕ ЯЧЕЙКИ", 10.5, rk.TEXT_DIM, tracking=2.0, anchor="lm")
    rk.text(canvas, (s(W - PAD - 28), s(y + 34)), "где больше всего расхождений", 11.5, rk.TEXT_DIM, anchor="rm")
    if not items:
        tile = rk.duotone_tile(rk.icon_check, s(54), rk.WHITE, rk.C_GREEN, radius=s(17), solid=True)
        rk.blob_glow(canvas, s(PAD + 28 + 27), s(y + 120), s(60), rk.C_GREEN, 70)
        canvas.alpha_composite(tile, (s(PAD + 28), s(y + 93)))
        rk.text(canvas, (s(PAD + 28 + 54 + 18), s(y + 112)), "Проблемных ячеек нет", 17, rk.WHITE, weight="bold", anchor="lm")
        rk.text(canvas, (s(PAD + 28 + 54 + 18), s(y + 138)), "Все заказы лежат там, где им положено.", 12.5,
                rk.TEXT_MUTED, anchor="lm")
        return y + h
    col_w = (W - 2 * PAD - 56 - 40) / 2
    max_total = max(sum(c.values()) for _, c in items) or 1
    for i, (cell, counter) in enumerate(items):
        col, row = divmod(i, rows_per_col)
        x0 = PAD + 28 + col * (col_w + 40)
        y0 = y + 62 + row * 46
        # чип с номером ячейки
        cw_ = 58
        rk.glass_panel(canvas, (s(x0), s(y0), s(cw_), s(32)), radius=s(11), fill=(112, 0, 255, 70),
                       border_top=(*rk.NEON, 160), border_bottom=(*rk.NEON, 90), shadow=False, sheen=False)
        rk.text(canvas, (s(x0 + cw_ / 2), s(y0 + 16)), _fit(cell, 14, cw_ - 10, "bold"), 14, rk.NEON_SOFT,
                weight="bold", anchor="mm")
        total = sum(counter.values())
        bar_x = x0 + cw_ + 16
        bar_w = col_w - cw_ - 16 - 44
        segs = [(counter.get(name, 0), color) for name, color in PROBLEM_COLOR.items()]
        _stacked_bar(canvas, bar_x, y0 + 11, bar_w * total / max_total, 10, segs)
        rk.text(canvas, (s(x0 + col_w), s(y0 + 16)), str(total), 16, rk.WHITE, weight="extrabold", anchor="rm")
    # легенда
    lx, ly = PAD + 28, y + h - 24
    d_ = ImageDraw.Draw(canvas)
    for name, color in PROBLEM_COLOR.items():
        lw = rk.text_w(name, 10.5, weight="semibold") / rk.SCALE
        d_.ellipse([s(lx), s(ly - 3.5), s(lx + 7), s(ly + 3.5)], fill=(*color, 255))
        rk.text(canvas, (s(lx + 12), s(ly)), name, 10.5, rk.TEXT_MUTED, weight="semibold", anchor="lm")
        lx += 12 + lw + 20
    return y + h


# ------------------------------------------------------------------ ранг, настроение, плюшки
GRADE_COLORS = {"S": rk.C_PINK, "A": rk.C_GREEN, "B": rk.NEON, "C": rk.C_AMBER, "D": rk.C_RED}
MOOD = {"S": "happy", "A": "happy", "B": "ok", "C": "worried", "D": "angry"}
MOOD_LOOK = {"happy": (0.0, -0.05), "ok": (0.0, 0.25), "worried": (-0.30, 0.45), "angry": (0.10, 0.10)}
PHRASE = {
    "S": "Идеально! Всё сошлось",
    "A": "Отличный результат!",
    "B": "Хорошо, но есть что поправить",
    "C": "Нужна перепроверка",
    "D": "Много расхождений — проверь!",
}


def grade_for(kpis: dict) -> str:
    """Ранг инвентаризации: S — всё чисто; A ≥95%; B ≥90%; C ≥80%; D — ниже."""
    total = kpis.get("total", 0)
    acc = (kpis.get("correct", 0) / total * 100) if total else 0.0
    clean = not (kpis.get("surplus") or kpis.get("dup") or kpis.get("wrong") or kpis.get("shortage"))
    acc = round(acc, 1)   # как показано на кольце: 94,97% -> «95,0%» -> ранг A, а не B
    if total and clean:
        return "S"
    if acc >= 95:
        return "A"
    if acc >= 90:
        return "B"
    if acc >= 80:
        return "C"
    return "D"


def _rank_badge(canvas, x, y, grade):
    size = 78
    col = GRADE_COLORS[grade]
    rk.blob_glow(canvas, s(x + size / 2), s(y + size / 2), s(size * 0.95), col, 85)
    c2 = rk.NEON if grade == "S" else rk.mix(col, (112, 0, 255), 0.35)
    tile = rk.diagonal_gradient((s(size), s(size)), rk.lighten(col, 0.15), c2).convert("RGBA")
    canvas.paste(tile, (s(x), s(y)), rk.rounded_mask((s(size), s(size)), s(22)))
    rk.text(canvas, (s(x + size / 2), s(y + size / 2 - 1)), grade, 44, rk.WHITE, weight="extrabold", anchor="mm")
    rk.tracked_text(canvas, (s(x + size / 2), s(y + size + 14)), "РАНГ", 8.5, rk.TEXT_DIM, tracking=1.8, anchor="mm")


MID_H = 250


def _rhythm_panel(canvas, x, y, w, h, rh):
    """«Эквалайзер» активности: столбики = сколько сканов закрыто за минуту (как эквалайзер на СЛА-сайте)."""
    _card(canvas, x, y, w, h, glow=rk.NEON, glow_alpha=30)
    rk.tracked_text(canvas, (s(x + 28), s(y + 34)), "РИТМ СКАНИРОВАНИЯ", 10.5, rk.TEXT_DIM, tracking=2.0, anchor="lm")
    rk.text(canvas, (s(x + w - 28), s(y + 34)), "сканов в минуту", 11.5, rk.TEXT_DIM, anchor="rm")
    if not rh or not rh.get("counts"):
        rk.text(canvas, (s(x + w / 2), s(y + h / 2 + 6)), "Нет данных о времени сканирования", 13, rk.TEXT_DIM, anchor="mm")
        return
    counts = rh["counts"]
    n = len(counts)
    mx = max(counts) or 1
    ax0, ax1 = x + 28, x + w - 28
    top, bot = y + 84, y + h - 78
    slot = (ax1 - ax0) / n
    bw = min(slot * 0.62, 26)
    pad = s(14)
    X0, Y0 = s(ax0) - pad, s(top) - pad
    X1, Y1 = s(ax1) + pad, s(bot) + pad
    layer = Image.new("RGBA", (X1 - X0, Y1 - Y0), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    peak_i = counts.index(mx)
    peak_cx = None
    for i, c in enumerate(counts):
        t = c / mx
        bh = max(s(4), int((s(bot) - s(top)) * t)) if c > 0 else s(3)
        bx = s(ax0 + i * slot + (slot - bw) / 2) - X0
        by1 = s(bot) - Y0
        col = rk.mix(rk.NEON, rk.C_PINK, t ** 1.4) if c > 0 else (70, 44, 125)
        d.rounded_rectangle([bx, by1 - bh, bx + s(bw), by1], radius=max(min(s(bw) // 2, bh // 2), 1), fill=(*col, 255))
        if i == peak_i:
            peak_cx = ax0 + i * slot + slot / 2
    canvas.alpha_composite(layer.filter(ImageFilter.GaussianBlur(s(6))), (X0, Y0))
    canvas.alpha_composite(layer, (X0, Y0))
    ImageDraw.Draw(canvas).line([(s(ax0), s(bot) + s(3)), (s(ax1), s(bot) + s(3))], fill=(70, 50, 120, 255), width=max(s(1), 2))
    rk.text(canvas, (s(ax0), s(bot + 18)), rh.get("start", ""), 10.5, rk.TEXT_DIM, anchor="lm")
    rk.text(canvas, (s(ax1), s(bot + 18)), rh.get("end", ""), 10.5, rk.TEXT_DIM, anchor="rm")
    if peak_cx is not None and mx > 0:
        lx = min(max(peak_cx, ax0 + 52), ax1 - 52)
        rk.text(canvas, (s(lx), s(top - 14)), f"пик: {mx} в {rh.get('peak_time', '')}".strip(), 10.5,
                rk.lighten(rk.C_PINK, 0.2), weight="semibold", anchor="mm")
    # три мини-показателя снизу
    stats = [("ДЛИТЕЛЬНОСТЬ", rh.get("duration", "—")), ("ТЕМП", rh.get("speed", "—")), ("ВСЕГО СКАНОВ", str(rh.get("total", "—")))]
    sx = x + 28
    for label, val in stats:
        rk.tracked_text(canvas, (s(sx), s(y + h - 24)), label, 8, rk.TEXT_DIM, tracking=1.6, anchor="lm")
        rk.text(canvas, (s(sx + rk.text_w(label, 8, weight="semibold", tracking=1.6) / rk.SCALE + 10), s(y + h - 24)), val, 13,
                rk.WHITE, weight="bold", anchor="lm")
        sx += (w - 56) / 3


def _achievements_panel(canvas, x, y, w, h, items):
    """Достижения: полученные подсвечены неоном, нет — тусклые."""
    _card(canvas, x, y, w, h, glow=rk.C_PINK, glow_alpha=26)
    got = sum(1 for _, ok in items if ok)
    rk.tracked_text(canvas, (s(x + 28), s(y + 34)), "ДОСТИЖЕНИЯ", 10.5, rk.TEXT_DIM, tracking=2.0, anchor="lm")
    rk.text(canvas, (s(x + w - 28), s(y + 34)), f"{got} из {len(items)}", 13, rk.WHITE, weight="extrabold", anchor="rm")
    cols, chip_h, gap = 2, 46, 12
    chip_w = (w - 56 - gap) / cols
    for i, (title, ok) in enumerate(items[:6]):
        r, c = divmod(i, cols)
        cx0 = x + 28 + c * (chip_w + gap)
        cy0 = y + 64 + r * (chip_h + gap)
        if ok:
            rk.glass_panel(canvas, (s(cx0), s(cy0), s(chip_w), s(chip_h)), radius=s(14), fill=(112, 0, 255, 80),
                           border_top=(*rk.NEON, 220), border_bottom=(*rk.NEON, 120), shadow=False, sheen=False)
            tile = rk.duotone_tile(rk.icon_check, s(28), rk.WHITE, rk.C_GREEN, radius=s(9), solid=True)
            tcol = rk.WHITE
        else:
            rk.glass_panel(canvas, (s(cx0), s(cy0), s(chip_w), s(chip_h)), radius=s(14), fill=(255, 255, 255, 10),
                           border_top=(255, 255, 255, 40), border_bottom=(255, 255, 255, 20), shadow=False, sheen=False)
            tile = rk.duotone_tile(rk.icon_minus, s(28), rk.TEXT_DIM, (60, 44, 100), radius=s(9), solid=True)
            tcol = rk.TEXT_DIM
        canvas.alpha_composite(tile, (s(cx0 + 12), s(cy0 + (chip_h - 28) / 2)))
        rk.text(canvas, (s(cx0 + 12 + 28 + 10), s(cy0 + chip_h / 2)), _fit(title, 11.5, chip_w - 12 - 28 - 10 - 10),
                11.5, tcol, weight="semibold", anchor="lm")


CELL_SEVERITY = ["Неверная ячейка", "Излишек", "Задвоенный", "Недостача"]
TILE_W, TILE_H, TILE_GAP = 64, 46, 8
MAX_TILES = 160


def _tiles_per_row():
    return int((W - 2 * PAD - 56 + TILE_GAP) // (TILE_W + TILE_GAP))


def _map_height(n_cells):
    if n_cells <= 0:
        return 0
    rows = math.ceil(min(n_cells, MAX_TILES) / _tiles_per_row())
    return 64 + rows * (TILE_H + TILE_GAP) + 46


def _cell_map(canvas, y, cells):
    """Карта ячеек: плитка на ячейку, цвет = самая серьёзная проблема, точка в углу = вторая проблема."""
    h = _map_height(len(cells))
    _card(canvas, PAD, y, W - 2 * PAD, h)
    rk.tracked_text(canvas, (s(PAD + 28), s(y + 34)), "КАРТА ЯЧЕЕК", 10.5, rk.TEXT_DIM, tracking=2.0, anchor="lm")
    bad = sum(1 for _, cnt in cells if any(cnt.get(k) for k in CELL_SEVERITY))
    rk.text(canvas, (s(W - PAD - 28), s(y + 34)),
            f"ячеек всего {len(cells)}  ·  с проблемами {bad}", 11.5, rk.TEXT_DIM, anchor="rm")
    per_row = _tiles_per_row()
    for i, (cell, cnt) in enumerate(cells[:MAX_TILES]):
        r, c = divmod(i, per_row)
        x0 = PAD + 28 + c * (TILE_W + TILE_GAP)
        y0 = y + 56 + r * (TILE_H + TILE_GAP)
        kinds = [k for k in CELL_SEVERITY if cnt.get(k)]
        col = PROBLEM_COLOR[kinds[0]] if kinds else rk.C_GREEN
        strong = bool(kinds)
        rk.glass_panel(canvas, (s(x0), s(y0), s(TILE_W), s(TILE_H)), radius=s(12),
                       fill=(*col, 92 if strong else 34), border_top=(*col, 215 if strong else 130),
                       border_bottom=(*col, 120 if strong else 70), shadow=False, sheen=False)
        n_prob = sum(cnt.get(k, 0) for k in kinds)
        rk.text(canvas, (s(x0 + TILE_W / 2), s(y0 + (18 if strong else TILE_H / 2))), _fit(cell, 13.5, TILE_W - 10, "bold"),
                13.5, rk.lighten(col, 0.28), weight="bold", anchor="mm")
        if strong:
            rk.text(canvas, (s(x0 + TILE_W / 2), s(y0 + 34)), f"×{n_prob}", 9.5, rk.WHITE, weight="semibold", anchor="mm")
        if len(kinds) > 1:
            c2 = PROBLEM_COLOR[kinds[1]]
            ImageDraw.Draw(canvas).ellipse([s(x0 + TILE_W - 13), s(y0 + 6), s(x0 + TILE_W - 6), s(y0 + 13)], fill=(*c2, 255))
    if len(cells) > MAX_TILES:
        rk.text(canvas, (s(W - PAD - 28), s(y + h - 24)), f"+ ещё {len(cells) - MAX_TILES} ячеек", 10.5, rk.TEXT_DIM, anchor="rm")
    # легенда
    lx, ly = PAD + 28, y + h - 24
    d_ = ImageDraw.Draw(canvas)
    for name, color in [("Всё верно", rk.C_GREEN)] + [(k, PROBLEM_COLOR[k]) for k in CELL_SEVERITY]:
        lw = rk.text_w(name, 10.5, weight="semibold") / rk.SCALE
        d_.ellipse([s(lx), s(ly - 3.5), s(lx + 7), s(ly + 3.5)], fill=(*color, 255))
        rk.text(canvas, (s(lx + 12), s(ly)), name, 10.5, rk.TEXT_MUTED, weight="semibold", anchor="lm")
        lx += 12 + lw + 20
    rk.text(canvas, (s(lx + 6), s(ly)), "·  точка в углу — вторая проблема в ячейке", 10.5, rk.TEXT_DIM, anchor="lm")
    return y + h


def _edge_fade(board, fade_px):
    """Плавно уводит края картинки в точный цвет листа (#030008), чтобы на тёмном листе Excel
    не было видно «прямоугольника» картинки: свечения и градиент раньше упирались в край."""
    w, h = board.size
    ramp_h = Image.new("L", (w, h), 255)
    ramp_v = Image.new("L", (w, h), 255)
    dh, dv = ImageDraw.Draw(ramp_h), ImageDraw.Draw(ramp_v)
    for i in range(fade_px):
        t = i / fade_px
        v = int(255 * (t * t * (3 - 2 * t)))
        dh.line([(0, i), (w, i)], fill=v)
        dh.line([(0, h - 1 - i), (w, h - 1 - i)], fill=v)
        dv.line([(i, 0), (i, h)], fill=v)
        dv.line([(w - 1 - i, 0), (w - 1 - i, h)], fill=v)
    mask = ImageChops.darker(ramp_h, ramp_v)
    bg = Image.new("RGBA", board.size, (*rk.BG_BASE, 255))
    return Image.composite(board, bg, mask)



def _footer(canvas, y, assets_dir):
    h = 52
    line = Image.new("RGBA", (s(W - 2 * PAD), s(3)), (0, 0, 0, 0))
    ld = ImageDraw.Draw(line)
    n = line.width
    for xx in range(n):
        t = xx / max(n - 1, 1)
        col = rk.mix(rk.mix((112, 0, 255), rk.C_PINK, min(t * 2, 1)), (112, 0, 255), max(t * 2 - 1, 0))
        a = int(230 * (1 - abs(t - 0.5) * 0.9))
        ld.line([(xx, 0), (xx, s(3))], fill=(*col, a))
    canvas.paste(line, (s(PAD), s(y + 6)), rk.rounded_mask(line.size, s(2)))
    rk.tracked_text(canvas, (s(W / 2), s(y + 32)), "СФОРМИРОВАНО АВТОМАТИЧЕСКИ  ·  UZUM INVENT", 8.5,
                    rk.TEXT_DIM, tracking=2.0, anchor="mm")
    wm_path = assets_dir / "logo_watermark.png"
    if wm_path.exists():
        wm = Image.open(wm_path).convert("RGBA").resize((s(56), s(56)), Image.LANCZOS)
        canvas.alpha_composite(wm, (s(W - PAD - 56), s(y - 4)))
    return y + h


def render_dashboard(profile: dict, kpis: dict, timestamp: str, assets_dir: Path, problem_cells=None, extras=None):
    """kpis: total, correct, shortage, wrong, dup, surplus.
    problem_cells: [(ячейка, Counter({статус: n})), ...] — необязателен (без него панель покажет «проблем нет»).
    extras (необязателен): {'cells': [(ячейка, Counter)], 'rhythm': {...}, 'achievements': [(текст, bool)]} —
    карта ячеек, «эквалайзер» ритма сканирования и достижения."""
    profile = dict(profile)
    extras = extras or {}
    cells = list(extras.get("cells") or [])
    achievements = list(extras.get("achievements") or [])
    map_h = _map_height(len(cells))
    show_mid = bool(extras)
    heights = 104 + 84 + 236 + 216 + (MID_H if show_mid else 0) + map_h + (70 + 3 * 46 + 16) + 52
    n_gaps = 5 + (1 if show_mid else 0) + (1 if map_h else 0)
    total_h = PAD + heights + GAP * n_gaps + PAD // 2 + 8

    board = rk.stage_background(W, total_h)
    # фон: почти чёрный фиолетовый + «волны» как #mesh на сайте
    base = Image.new("RGBA", board.size, (*rk.BG_BASE, 255))
    board = Image.blend(base, board, 0.55)
    rk.blob_glow(board, int(s(W) * 0.50), int(s(total_h) * 0.40), int(s(W) * 0.20), (200, 90, 255), 70)
    rk.blob_glow(board, int(s(W) * 0.05), int(s(total_h) * 0.30), int(s(W) * 0.16), (112, 0, 255), 90)
    rk.blob_glow(board, int(s(W) * 0.97), int(s(total_h) * 0.72), int(s(W) * 0.16), (157, 77, 255), 80)
    rk.blob_glow(board, int(s(W) * 0.15), int(s(total_h) * 0.96), int(s(W) * 0.16), (52, 199, 123), 38)

    y = PAD
    y = _header(board, y, profile, timestamp, assets_dir / "logo_solid.png") + GAP
    y = _info_bar(board, y, profile, timestamp) + GAP
    y = _hero_row(board, y, kpis, profile) + GAP
    y = _kpi_grid(board, y, kpis) + GAP
    if show_mid:
        rw = 700
        _rhythm_panel(board, PAD, y, rw, MID_H, extras.get("rhythm"))
        _achievements_panel(board, PAD + rw + GAP, y, W - 2 * PAD - rw - GAP, MID_H, achievements)
        y += MID_H + GAP
    if map_h:
        y = _cell_map(board, y, cells) + GAP
    y = _problem_panel(board, y, problem_cells) + GAP
    _footer(board, y, assets_dir)

    board = _edge_fade(board, s(26))
    img = rk.finalize(board, W, total_h)
    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="PNG", optimize=True)
    return buf.getvalue(), W, total_h


_CHIP_LABELS = {   # подписи чипов шапки: (дата, администратор, ПВЗ)
    "ru": ("ЗАВЕРШЕНО", "АДМИНИСТРАТОР", "ПВЗ"),
    "uz": ("YAKUNLANDI", "ADMINISTRATOR", "PYZ"),
}


def render_banner(profile: dict, timestamp: str, width_px: int, assets_dir: Path,
                  title: str = "Инвентаризация ПВЗ", subtitle: str = "UZUM MARKET  ·  UZUM INVENT",
                  byline: bool = True, lang: str = "ru"):
    """Шапка над таблицей «Инвентаризация»: логотип, заголовок, чипы ПВЗ / админ / дата.
    Фон прозрачный по краям — картинка ложится на тёмный лист без швов."""
    Wb, Hb = int(width_px), 80
    canvas = rk.new_canvas(Wb, Hb)
    _card(canvas, 0, 4, Wb, Hb - 8, radius=20, glow=rk.NEON, glow_alpha=38)
    _logo(canvas, assets_dir / "logo_solid.png", 16, 14, 52)
    tx = s(16 + 52 + 16)
    rk.text(canvas, (tx, s(31)), title, 19, rk.WHITE, weight="extrabold", anchor="lm")
    rk.tracked_text(canvas, (tx, s(54)), subtitle, 8.5, rk.TEXT_DIM, tracking=2.0, anchor="lm")

    # чипы справа налево: дата, админ, ПВЗ
    l_done, l_admin, l_pvz = _CHIP_LABELS.get(lang, _CHIP_LABELS["ru"])
    chips = [
        (l_done, timestamp),
        (l_admin, profile.get("admin_name", "—")),
        (l_pvz, profile.get("pvz", "—")),
    ]
    right = Wb - 18
    for label, value in chips:
        val = _fit(value, 12, 190, "semibold")
        cw_ = int(max(rk.text_w(val, 12, weight="semibold") / rk.SCALE, rk.text_w(label, 7.5, weight="semibold", tracking=1.6) / rk.SCALE)) + 32
        x0 = right - cw_
        if x0 < s(0) + 16 + 52 + 16 + 230:
            break
        rk.glass_panel(canvas, (s(x0), s(18), s(cw_), s(44)), radius=s(14), fill=(112, 0, 255, 52),
                       border_top=(*rk.NEON, 150), border_bottom=(*rk.NEON, 80), shadow=False, sheen=False)
        rk.tracked_text(canvas, (s(x0 + 16), s(30)), label, 7.5, rk.TEXT_DIM, tracking=1.6, anchor="lm")
        rk.text(canvas, (s(x0 + 16), s(48)), val, 12, rk.WHITE, weight="semibold", anchor="lm")
        right = x0 - 10

    # подпись автора: маленькая «таблетка» справа от подзаголовка (если хватает места до чипов)
    if byline:
        sub_w = rk.text_w(subtitle, 8.5, weight="semibold", tracking=2.0) / rk.SCALE
        w_by = rk.text_w("by", 8.5, weight="semibold") / rk.SCALE
        w_nm = rk.text_w("DAMIR", 9, weight="extrabold", tracking=2.0) / rk.SCALE
        pw = int(12 + w_by + 6 + w_nm + 12)
        px = int(16 + 52 + 16 + sub_w + 16)
        if px + pw < right - 6:
            rk.glass_panel(canvas, (s(px), s(44), s(pw), s(20)), radius=s(10), fill=(157, 77, 255, 40),
                           border_top=(*rk.NEON_SOFT, 120), border_bottom=(*rk.NEON, 70), shadow=False, sheen=False)
            rk.text(canvas, (s(px + 12), s(54)), "by", 8.5, rk.TEXT_DIM, weight="semibold", anchor="lm")
            rk.tracked_text(canvas, (s(px + 12 + w_by + 6), s(54)), "DAMIR", 9, rk.NEON_SOFT, tracking=2.0,
                            weight="extrabold", anchor="lm")
    img = rk.finalize(canvas, Wb, Hb)
    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return buf.getvalue(), Wb, Hb
