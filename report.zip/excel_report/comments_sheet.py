"""
Лист «Комменты» — автоматическая разбивка расхождений для отчёта начальнику.

Бот сам раскладывает по четырём блокам всё, что требует объяснения (как во вкладке «коменты» у коллег):
  1. Не найденные заказы  — статус «Недостача»
  2. Лишние заказы        — статус «Излишек»
  3. Ячейка не совпала    — статус «Неверная ячейка»  (скан-ячейка ↔ ячейка по WMS)
  4. Дубликаты скана      — статус «Задвоенный»       (заказ + сколько раз отсканирован)

У каждой строки три поля для сотрудника: «Комментарий» (выпадающий список причин), «Фото»
(выпадающий список) и «Примечание» (свободный текст). Списки причин взяты из рабочего файла КЕЛ-1.
Лист нативный (ячейки, а не картинки), в тёмной теме остальных листов. Работает на ru и uz.
"""
from collections import Counter

from openpyxl.styles import Alignment, Border, Font, Side
from openpyxl.worksheet.datavalidation import DataValidation

from . import dashboard_render
from . import render_kit as rk
from . import xlsx_report as X
from .live_report import fx

SHEET = "Комменты"

ST_SHORT, ST_SUR, ST_WRONG, ST_DUP = "Недостача", "Излишек", "Неверная ячейка", "Задвоенный"

COLS = {'A': 2, 'B': 6, 'C': 28, 'D': 15, 'E': 15, 'F': 36, 'G': 19, 'H': 34, 'I': 2, 'J': 6}
HELPER_COL = 10          # «J» — скрытая колонка со счётчиком заполненных комментариев
FIRST_COL, LAST_COL = 2, 8   # B..H
ROW_H = 24
PROGRESS_ROW = 6
FIRST_SECTION_ROW = 9

# ---- списки причин (взяты из КЕЛ-1.xlsx; «Потеренный» исправлено на «Потерянный»)
REASONS = {
    "ru": {
        "short": ["Выдан во время ивента", "Выдан после ивента", "Не просканированный (Заказ на ПВЗ)",
                  "Потерянный заказ", "Внесистемная отгрузка на склад", "Ранее выданный", "Прочее"],
        "sur": ["Ранее отменённый", "Не принятый заказ", "Заказ другого ПВЗ", "Ранее выданный заказ",
                "Статус проверяется клиентом", "Прочее"],
        "wrong": ["Переложили по местам", "Поправили ячейку в WMS", "Прочее"],
        "dup": ["Случайно отсканированный", "Прочее"],
        "photo": ["Не требуется", "Фото приложено", "Нужно фото"],
    },
    "uz": {
        "short": ["Tadbir paytida berilgan", "Tadbirdan keyin berilgan", "Skanerlanmagan (PVZdagi buyurtma)",
                  "Yo‘qolgan buyurtma", "Tizimsiz omborga jo‘natish", "Avval berilgan", "Boshqa"],
        "sur": ["Avval bekor qilingan", "Qabul qilinmagan buyurtma", "Boshqa PVZ buyurtmasi",
                "Avval berilgan buyurtma", "Holat mijozda tekshirilmoqda", "Boshqa"],
        "wrong": ["Joylariga qo‘yildi", "WMSda yacheyka tuzatildi", "Boshqa"],
        "dup": ["Tasodifan skanerlangan", "Boshqa"],
        "photo": ["Talab etilmaydi", "Foto biriktirilgan", "Foto kerak"],
    },
}

TXT = {
    "ru": {
        "title": "Комментарии", "sub": "UZUM MARKET  ·  ПРИЧИНЫ РАСХОЖДЕНИЙ",
        "hint": "Выберите причину из списка ▾ — «Фото» и «Примечание» по желанию",
        "progress": "Заполнено комментариев:  {done}  из  {total}",
        "clean": "Расхождений нет — комментарии не нужны",
        "empty": "Нет — всё чисто",
        "hdr": {"no": "№", "order": "ЗАКАЗ", "comment": "КОММЕНТАРИЙ", "photo": "ФОТО", "note": "ПРИМЕЧАНИЕ",
                "wms": "ПО WMS", "scan": "СКАН", "cnt": "СКАНОВ", "cell": "ЯЧЕЙКА"},
        "sec": {"short": "Не найденные заказы", "sur": "Лишние заказы", "wrong": "Ячейка не совпала",
                "dup": "Дубликаты скана"},
        "dv_title": "Выберите из списка", "dv_prompt": "Можно выбрать готовую причину или вписать свою.",
        "nav_summary": "←  СВОДКА", "nav_problems": "РАЗБОР ПРОБЛЕМ", "nav_table": "ТАБЛИЦА  →",
    },
    "uz": {
        "title": "Izohlar", "sub": "UZUM MARKET  ·  NOMUVOFIQLIK SABABLARI",
        "hint": "Sababni ro‘yxatdan tanlang ▾ — «Foto» va «Izoh» ixtiyoriy",
        "progress": "To‘ldirilgan izohlar:  {done}  /  {total}",
        "clean": "Nomuvofiqlik yo‘q — izoh kerak emas",
        "empty": "Yo‘q — hammasi toza",
        "hdr": {"no": "№", "order": "BUYURTMA", "comment": "IZOH", "photo": "FOTO", "note": "ESLATMA",
                "wms": "WMS BO‘YICHA", "scan": "SKAN", "cnt": "SKANLAR", "cell": "YACHEYKA"},
        "sec": {"short": "Topilmagan buyurtmalar", "sur": "Ortiqcha buyurtmalar", "wrong": "Yacheyka mos kelmadi",
                "dup": "Skan dublikatlari"},
        "dv_title": "Ro‘yxatdan tanlang", "dv_prompt": "Tayyor sababni tanlang yoki o‘zingiznikini yozing.",
        "nav_summary": "←  XULOSA", "nav_problems": "MUAMMOLAR TAHLILI", "nav_table": "JADVAL  →",
    },
}


def collect(full_rows: list[dict]) -> dict[str, list[dict]]:
    """Раскладывает строки отчёта по четырём блокам. Порядок внутри блока — как в таблице «Инвентаризация»."""
    out = {"short": [], "sur": [], "wrong": [], "dup": []}
    dup_count: Counter = Counter()
    dup_first: dict = {}
    for r in full_rows:
        st = r.get("status")
        code = str(r.get("full_code") or r.get("wms_id") or "")
        exp = str(r.get("expected_cell") or "—")
        scan = str(r.get("scanned_cell") or "—")
        if st == ST_SHORT:
            out["short"].append({"order": str(r.get("wms_id") or code), "wms": exp, "scan": "—"})
        elif st == ST_SUR:
            out["sur"].append({"order": code, "wms": "—", "scan": scan})
        elif st == ST_WRONG:
            out["wrong"].append({"order": code, "wms": exp, "scan": scan})
        elif st == ST_DUP:
            dup_count[code] += 1
            dup_first.setdefault(code, scan)
    for code, n in dup_count.items():           # в БД повтор — отдельная строка; +1 = первый (принятый) скан
        out["dup"].append({"order": code, "cnt": n + 1, "scan": dup_first[code]})
    return out


def _accent(status: str) -> str:
    return X.STATUS_ACCENT[status]


def build(ws, full_rows, ident, timestamp, language, cache, *, nav):
    """Заполняет лист. nav: {"summary": (лист, ссылка), "problems": (...), "table": (...)}.
    Возвращает номер последней занятой строки."""
    lang = language if language in TXT else "ru"
    tx, rs = TXT[lang], REASONS[lang]
    groups = collect(full_rows)
    total = sum(len(v) for v in groups.values())

    X._dark_sheet(ws, len(COLS) + 1, COLS)
    ws.column_dimensions[X.get_column_letter(HELPER_COL)].hidden = True

    # --- шапка: баннер + навигация
    banner_w = sum(X._col_width_to_px(COLS[x]) for x in "BCDEFGH")
    png, bw, bh = dashboard_render.render_banner(ident, timestamp, banner_w, X.ASSETS_DIR,
                                                 title=tx["title"], subtitle=tx["sub"], lang=lang)
    for r in (1, 2, 3):
        ws.row_dimensions[r].height = 20
    X._place_image(ws, png, 2, 1, bw, bh, alt=tx["title"])
    ws.row_dimensions[4].height = 24
    X._nav_chip(ws, 4, 2, 3, tx["nav_summary"], *nav["summary"])
    X._nav_chip(ws, 4, 4, 5, tx["nav_problems"], *nav["problems"])
    X._nav_chip(ws, 4, 6, 6, tx["nav_table"], *nav["table"])
    ws.row_dimensions[5].height = 8

    # --- прогресс (формула считает заполненные «Комментарии» и обновляется сама)
    ws.row_dimensions[PROGRESS_ROW].height = 30
    ws.row_dimensions[PROGRESS_ROW + 1].height = 20
    ws.row_dimensions[PROGRESS_ROW + 2].height = 10
    bar = X._merge(ws, PROGRESS_ROW, FIRST_COL, PROGRESS_ROW, LAST_COL, None, fill=X.FILL_HEAD,
                   border=Border(left=Side(style="thick", color=X.NEON)), align=Alignment(horizontal="left", vertical="center", indent=1))
    bar.font = Font(name=X.FONT_NAME, size=13, bold=True, color=X.NEON_SOFT)
    X._merge(ws, PROGRESS_ROW + 1, FIRST_COL, PROGRESS_ROW + 1, LAST_COL, tx["hint"], fill=X.FILL_BG,
             font=Font(name=X.FONT_NAME, size=8.5, color=X.TEXT_DIM, italic=True),
             align=Alignment(horizontal="left", vertical="center", indent=1))

    # --- блоки
    dv_comment, dv_photo = {}, []
    comment_ranges = []
    row = FIRST_SECTION_ROW
    layout = [("short", ST_SHORT, "wms", "scan"), ("sur", ST_SUR, "wms", "scan"),
              ("wrong", ST_WRONG, "wms", "scan"), ("dup", ST_DUP, "cnt", "cell")]
    h = tx["hdr"]
    for key, status, d_lbl, e_lbl in layout:
        items = groups[key]
        accent = _accent(status)
        light = X._mixhex(accent, "FFFFFF", 0.35)
        side = Side(style="thick", color=accent)
        ws.row_dimensions[row].height = 28
        head = X._merge(ws, row, FIRST_COL, row, LAST_COL, None, fill=X.FILL_HEAD, border=Border(left=side),
                        align=Alignment(horizontal="left", vertical="center", indent=1))
        head.value = f"{tx['sec'][key]}   ·   {len(items)}"
        head.font = Font(name=X.FONT_NAME, size=12, bold=True, color=light)
        row += 1
        if not items:
            ws.row_dimensions[row].height = ROW_H
            X._merge(ws, row, FIRST_COL, row, LAST_COL, "✓  " + tx["empty"], fill=X.FILL_A,
                     font=Font(name=X.FONT_NAME, size=9.5, color=X.TEXT_DIM, italic=True),
                     align=Alignment(horizontal="left", vertical="center", indent=1))
            row += 2
            continue
        # заголовки колонок
        ws.row_dimensions[row].height = 20
        hb = Border(bottom=Side(style="thin", color=accent))
        for col, text in zip(range(FIRST_COL, LAST_COL + 1),
                             (h["no"], h["order"], h[d_lbl], h[e_lbl], h["comment"], h["photo"], h["note"])):
            c = ws.cell(row=row, column=col, value=text)
            c.font = Font(name=X.FONT_NAME, size=8.5, bold=True, color=X.TEXT_DIM)
            c.fill, c.border = X.FILL_A, hb
            c.alignment = Alignment(horizontal="center" if col != 3 else "left", vertical="center", indent=1 if col == 3 else 0)
        row += 1
        first = row
        for i, it in enumerate(items, start=1):
            ws.row_dimensions[row].height = ROW_H
            base = X.ROW_A if i % 2 else X.ROW_B
            inp = X._mixhex(base, X.NEON, 0.10)
            vals = {2: i, 3: it["order"],
                    4: it["cnt"] if key == "dup" else it["wms"],
                    5: it["scan"]}
            for col in range(FIRST_COL, LAST_COL + 1):
                c = ws.cell(row=row, column=col, value=vals.get(col))
                editable = col >= 6
                c.fill = X._fill(inp if editable else base)
                c.border = Border(bottom=Side(style="thin", color=X.LINE))
                c.font = Font(name=X.FONT_NAME, size=10, color=X.TEXT if editable else X.TEXT_SOFT,
                              bold=(col == 3))
                c.alignment = Alignment(horizontal="left" if col in (3, 6, 8) else "center", vertical="center",
                                        indent=1 if col in (3, 6, 8) else 0, wrap_text=(col == 8))
            ws.cell(row=row, column=2).fill = X._fill(X._mixhex(X.ROW_A, accent, 0.45))
            ws.cell(row=row, column=2).font = Font(name=X.FONT_NAME, size=9, bold=True, color="FFFFFF")
            if key == "dup":
                ws.cell(row=row, column=4).number_format = '"×"0'
                ws.cell(row=row, column=4).font = Font(name=X.FONT_NAME, size=10, bold=True, color=light)
            row += 1
        last = row - 1
        comment_ranges.append(f"F{first}:F{last}")
        dv_comment[key] = f"F{first}:F{last}"
        dv_photo.append(f"G{first}:G{last}")
        row += 1                                            # воздух между блоками

    # --- выпадающие списки (можно и вписать своё: жёсткой проверки нет)
    def dv_for(items):
        formula = '"' + ",".join(items) + '"'
        assert len(formula) <= 255, "список причин длиннее лимита Excel (255 символов)"
        d = DataValidation(type="list", formula1=formula, allow_blank=True, showErrorMessage=False,
                           showInputMessage=True, promptTitle=tx["dv_title"], prompt=tx["dv_prompt"])
        ws.add_data_validation(d)
        return d
    for key, rng in dv_comment.items():
        dv_for(rs[key]).add(rng)
    if dv_photo:
        d = dv_for(rs["photo"])
        for rng in dv_photo:
            d.add(rng)

    # --- прогресс: формулы + кэш значений (чтобы цифры были видны и в превью без пересчёта)
    last_row = row
    if total == 0:
        bar.value = tx["clean"]
        bar.font = Font(name=X.FONT_NAME, size=13, bold=True, color=_green())
    else:
        counted = "+".join(f'COUNTIF({r},"?*")' for r in comment_ranges)
        fx(ws, cache, PROGRESS_ROW, HELPER_COL, counted, 0)
        done_ref = f"${X.get_column_letter(HELPER_COL)}${PROGRESS_ROW}"
        pre, post = tx["progress"].split("{done}")
        mid, tail = post.split("{total}")
        bar.value = f'="{pre}"&{done_ref}&"{mid}{total}{tail}"'
        cache[(ws.title, f"B{PROGRESS_ROW}")] = tx["progress"].format(done=0, total=total)
        X._cf(ws, f"B{PROGRESS_ROW}:H{PROGRESS_ROW}", f"{done_ref}>={total}",
              font=Font(color=_green(), bold=True), border=Border(left=Side(style="thick", color=_green())))
        X._cf(ws, f"B{PROGRESS_ROW}:H{PROGRESS_ROW}", f"{done_ref}<{total}",
              font=Font(color=_amber(), bold=True), border=Border(left=Side(style="thick", color=_amber())))
        for rng in comment_ranges:                          # заполнено — подсветка зелёным
            top = rng.split(":")[0]
            X._cf(ws, rng, f'{top}<>""', font=Font(color=_green(), bold=True))
    ws.sheet_view.zoomScale = 100
    return last_row


def _green():
    return X._hex(rk.C_GREEN)


def _amber():
    return X._hex(rk.C_AMBER)
